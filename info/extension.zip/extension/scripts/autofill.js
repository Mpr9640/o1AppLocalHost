//===Global caches
//Config ======
console.log(
  '[JobAid] contentscript running on',
  location.href,
  'frame?', window.top !== window.self
);
window.addEventListener('error', (e) => console.error('[JA window.error]', e.error || e.message));
window.addEventListener('unhandledrejection', (e) => console.error('[JA unhandledrejection]', e.reason));
const API_BASE_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8000';
//Styles ======
//import { waitForResumeParseNetworkFirst } from'./resumechecking.js';
const style = document.createElement('style');
style.textContent = `
  .autofill-highlight{ outline:2px solid gold !important; transition: outline .3s ease-out; }
  .autofill-drop-indicator{ outline:2px dashed #8aa; }
`;
document.head.appendChild(style);
const fieldNameCache = new WeakMap();
const groupCache = new WeakMap();
//const delay = (ms)=>new Promise(r=>setTimeout(r,ms));s
// Visibility / Normalization
function isElementVisible(el){
  if (!el || !el.getBoundingClientRect) return false;
  const rect = el.getBoundingClientRect();
  if (!rect || rect.width === 0 || rect.height === 0) return false;

  const cs = getComputedStyle(el);
  if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;

  if ((rect.bottom < 0 && rect.top < 0) || (rect.right < 0 && rect.left < 0)) return false;

  for (let n = el; n; n = n.parentElement){
    if (n.hidden) return false;
    if (n.getAttribute && n.getAttribute('aria-hidden') === 'true') return false;
    if ('inert' in n && n.inert) return false;
  }
  return true;
}
function normalizeFieldName(s){
  return (s||'').toString().toLowerCase().replace(/\s/g,'').replace(/[^a-z0-9]/g,'').trim();
}
function normalizeFieldNameWithSpace(s){
  return (s||'').toString()
    .replace(/([a-z])([A-Z])/g,'$1 $2')
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g,' ')
    .replace(/\s+/g, ' ')
    .trim();
}
// Booleans / Options =====
const BOOL_TRUE = new Set(['yes','y','true','t','1','accept','agree','iagree','optin','on','currentlyworking','currentlystudying']);
const BOOL_FALSE = new Set(['no','n','false','f','0','decline','disagree','i do not agree','optout','off','notcurrentlyworking','notcurrentlystudying']);

function normalizeOptionText(text) {
  return (text||'').split('-')[0].replace(/\(.*?\)/g, '').replace(/\s+/g, ' ').trim().toLowerCase();
} 
//Function for normalization ob booleans
function normalizeToBooleanLike(v){
  const s = normalizeOptionText(String(v));
  if (BOOL_TRUE.has(s)) return 'yes';
  if (BOOL_FALSE.has(s)) return 'no';
  return s;
}
function waitForDomStable({ timeoutMs = 2500, quietMs = 180 } = {}) {
  return new Promise(resolve => {
    let timer = setTimeout(done, timeoutMs);
    let idle;
    const mo = new MutationObserver(() => {
      clearTimeout(idle);
      idle = setTimeout(done, quietMs);
    });
    mo.observe(document.documentElement, { subtree: true, childList: true, attributes: true });
    function done(){
      mo.disconnect();
      clearTimeout(timer);
      resolve();
    }
  });
}

// Finding nearest label fallback
function textNodeCenterRect(node) {
  const range = node.ownerDocument.createRange();
  range.selectNodeContents(node);
  const rects = range.getClientRects();
  range.detach?.();
  if (!rects || rects.length === 0) return null;
  let best = rects[0];
  for (let i = 1; i < rects.length; i++) {
    const r = rects[i];
    if (r.width * r.height > best.width * best.height) best = r;
  }
  return best;
}
function getExplicitLabels(el) {
  const doc = el.ownerDocument;
  const out = [];
  if (el.labels && el.labels.length) {
    for (const lab of el.labels) {
      const t = (lab.textContent || '').trim();
      if (t) out.push(t);
    }
  } else {
    let p = el.parentElement;
    while (p) {
      if (p.tagName === 'LABEL') {
        const t = (p.textContent || '').trim();
        if (t) out.push(t);
        break;
      }
      p = p.parentElement;
    }
  }
  const addByIds = (attr) => {
    const ids = (el.getAttribute(attr) || '').split(/\s+/).filter(Boolean);
    for (const id of ids) {
      const n = doc.getElementById(id);
      if (n) {
        const t = (n.textContent || '').trim();
        if (t) out.push(t);
      }
    }
  };
  addByIds('aria-labelledby');
  addByIds('aria-describedby');

  if (el.placeholder) out.push(el.placeholder);
  if (el.title) out.push(el.title);

  return out;
}
function nearestTextAround(el, px = 220, { includeIframes = false } = {}) {
  if (!el) return '';

  const explicit = getExplicitLabels(el)
    .map(normalizeFieldNameWithSpace)
    .find(Boolean);
  if (explicit) return explicit;

  const root = el.getRootNode?.() || el.ownerDocument || document;
  const doc = root.nodeType === 9 ? root : (root.ownerDocument || document);

  const er = el.getBoundingClientRect();
  const ecx = er.left + er.width / 2;
  const ecy = er.top + er.height / 2;

  const walker = doc.createTreeWalker(
    root,
    NodeFilter.SHOW_TEXT,
    {
      acceptNode(node) {
        const raw = node.nodeValue || '';
        if (!raw.trim()) return NodeFilter.FILTER_REJECT;
        const parent = node.parentElement;
        if (!parent) return NodeFilter.FILTER_REJECT;
        const tag = parent.tagName;
        if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
        if (!isElementVisible(parent)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    },
    false
  );

  let bestTxt = '';
  let bestScore = Infinity;

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const rect = textNodeCenterRect(node);
    if (!rect) continue;

    const cx = rect.left + rect.width / 2;
    const cy = rect.top + rect.height / 2;

    const dx = cx - ecx;
    const dy = cy - ecy;
    const dist = Math.hypot(dx, dy);
    if (dist > px) continue;

    let bias = 0;
    if (cx > ecx) bias += 18;
    if (cy > ecy) bias += 9;
    if (Math.abs(dy) < 10) bias -= 6;

    const score = dist + bias;
    if (score < bestScore) {
      bestScore = score;
      bestTxt = (node.nodeValue || '').trim();
    }
  }

  if (!bestTxt && includeIframes) {
    for (const iframe of doc.querySelectorAll('iframe')) {
      try {
        const idoc = iframe.contentDocument;
        if (!idoc) continue;
        const walker2 = idoc.createTreeWalker(
          idoc,
          NodeFilter.SHOW_TEXT,
          {
            acceptNode(node) {
              const raw = node.nodeValue || '';
              if (!raw.trim()) return NodeFilter.FILTER_REJECT;
              const parent = node.parentElement;
              if (!parent) return NodeFilter.FILTER_REJECT;
              const tag = parent.tagName;
              if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'NOSCRIPT') return NodeFilter.FILTER_REJECT;
              if (!isElementVisible(parent)) return NodeFilter.FILTER_REJECT;
              return NodeFilter.FILTER_ACCEPT;
            }
          },
          false
        );

        let best2 = Infinity, txt2 = '';
        while (walker2.nextNode()) {
          const node = walker2.currentNode;
          const rect = textNodeCenterRect(node);
          if (!rect) continue;
          const cx = rect.left + rect.width / 2;
          const cy = rect.top + rect.height / 2;
          const dx = cx - ecx;
          const dy = cy - ecy;
          const dist = Math.hypot(dx, dy);
          if (dist > px) continue;
          let bias = 0;
          if (cx > ecx) bias += 18;
          if (cy > ecy) bias += 9;
          if (Math.abs(dy) < 10) bias -= 6;
          const score = dist + bias;
          if (score < best2) {
            best2 = score;
            txt2 = (node.nodeValue || '').trim();
          }
        }
        if (txt2) bestTxt = txt2;
      } catch (e) {}
    }
  }

  const norm = normalizeFieldNameWithSpace(bestTxt);
  //console.log('[nearestTextAround]', norm);
  return norm;
}
function findAssociatedLabel(el){
  if (!el) return '';
  if (el.id){
    const lab = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
    if (lab?.textContent) return lab.textContent.trim();
  }
  return '';
}
///====Hosts
// OPTIONAL: Workday hints
function isWorkdayHost() {
  const h = location.hostname;
  return /\.myworkdayjobs\.com$/i.test(h) || /\.wd\d+\.myworkdayjobs\.com$/i.test(h);
}
const isAshbyHost = /(?:^|\.)ashbyhq\.com$/i.test(location.hostname);
const isSuccessHost = /(?:^|\.)successfactors\.com$/i.test(location.hostname);
const isGreenhouseHost = /(?:^|\.)greenhouse\.io$/i.test(location.hostname);
const isPowerHost = /(?:^|\.)powerhrg\.com$/i.test(location.hostname);
const isApexApplyHost = /(?:^|\.)itcareersapply\.apexsystems\.com$/i.test(location.hostname);
///ICIMS host related 
const isIcimsHost = /(?:^|\.)icims\.(?:com|co)$/i.test(location.hostname);
const isMetaHost = /(^|\.)metacareers\.com$/i.test(location.hostname);
const isJobCaseHost = /^([a-z0-9-]+\.)*jobcase\.com$/i.test(location.hostname);
const isWorkableJobsHost = /(?:^|\.)jobs\.workable\.com$/i.test(location.hostname);
function getIcimsFormRoot() {
  return document.querySelector(
    '#iCIMS_ApplicantProfile, form#cp_form, form[action*="Profile"], form[action*="Candidate"], .iCIMS_ContentPane'
  ) || document;
}
function stableKeyFor(el) {
  const id = el.id || '';
  const name = el.getAttribute?.('name') || '';
  const type = el.getAttribute?.('type') || '';
  const formAct = el.form?.getAttribute?.('action') || '';
  // short DOM path fingerprint
  let n = el, path = [];
  for (let i=0; n && i<4; i++) {
    let ix = 0, sib = n;
    while ((sib = sib.previousElementSibling)) ix++;
    path.push(`${n.tagName}:${ix}`);
    n = n.parentElement;
  }
  return [id, name, type, formAct, path.join('>')].join('|');
}



const fieldMappings = [
  // ==== PERSONAL INFO ====
  { keywords: [/\bfirst\s*name\b/i, /\bgiven\s*name\b/i], dataKey: 'firstname' },
  { keywords: [/\bmiddle\s*name\b/i, /\binitial\b/i], dataKey: 'middlename' },
  { keywords: [/\blast\s*name\b/i, /\bsurname\b/i, /\bfamily\s*name\b/i], dataKey: 'lastname' },
  { keywords: [/\bfull\s*name\b/i, /\blegal\s*name\b/i,/^name$/i], dataKey: 'fullname' },
  // ==== CONTACT INFO ====
  { keywords: [/\bemail\b/i, /\bemail\s*address\b/i], dataKey: 'email' },
  { keywords: [/\b(?:phone|mobile|telephone|contact\s*number)\b(?!\s*(extension|type)\b)/i], dataKey: 'phonenumber' },
  { keywords: [/\b(country\s*code|phone\s*code)\b/i], dataKey: 'residencecountry', handleCountryCode: true },
  { keywords: [/\bdate\s*of\s*birth\b/i, /\bdob\b/i, /\bbirth\s*date\b/i], dataKey: 'dateofbirth', type:'date' },

  // ==== SOCIAL / LINKS ====
  { keywords: [/\blinked\s?in\b/i, /\blinked\s*in\s*profile\b/i], dataKey: 'linkedin' },
  { keywords: [/\bgit\s?hub\b/i, /\bgithub\s*profile\b/i], dataKey: 'github' },
  { keywords: [/\bportfolio\b/i, /\bpersonal\s*site\b/i], dataKey: 'portfolio' },
  { keywords: [/\bskills\b/i], dataKey: 'skills'},

  // ==== FILE UPLOADS ====
  { keywords: [/\bresume\b/i, /\bcv\b/i, /\bcurriculum\s*vitae\b/i], dataKey: 'resume' },
  { keywords: [/\bcover\s*letter\b/i, /\bsupporting\s*document\b/i], dataKey: 'coverletter' },

  // ==== DEMOGRAPHIC INFO ====
  { keywords: [/\bgender\b/i, /\bsex\b/i], dataKey: 'gender' },
  { keywords: [/\brace\b/i, /\bethnicity\b/i, /\bethnic\s*group\b/i], dataKey: 'race' },
  { keywords: [/\bdisab(?:ility|led)?\b/i, /\bdisclosure of disability\b/i], dataKey: 'disability' },
  { keywords: [/\bveteran\b/i, /\bmilitary\b/i, /\barmed\s*forces\b/i], dataKey: 'veteran' },
  { keywords: [/\bsponsor|spsorship|sponsorship/i, /\bvisa\s*sponsor\b/i, /\bwork\s*authorization\b/i], dataKey: 'needsponsorship' },

  // residence address / address line 1 / address number / street number — prefix required
  {keywords: [/\b(?:residence|residential|street|postal|permanent|home)[-\s]*address\b(?!\s*line\s*2\b)(?:\s*(?:line\s*1|number(?:\s*\d+)?))?/i,/\b(?:residence|residential|permanent|present|current|home)[-\s]*street[-\s]*number\b/i],dataKey: 'residenceaddress'},
  {keywords: [/\b(?:residence|residential|permanent|present|current|home)[-\s]*(?:city|town)\b/i],dataKey: 'residencecity'},
  {keywords: [/\b(?:residence|residential|permanent|present|current|home)[-\s]*state\b(?!\s*of\b)/i],dataKey: 'residencestate'},
  {keywords: [/\b(?:residence|residential|permanent|present|current|home)[-\s]*country\b(?!\s*(?:code|dial|calling)\b)/i],dataKey: 'residencecountry'},
  {keywords: [/\b(?:residence|residential|permanent|present|current|home)[-\s]*(?:zip|postal|area)[-\s]*code\b/i],dataKey: 'residencezipcode'},
  {keywords: [/\b(?:residence|residential|permanent|present|current|home|currently)[-\s]*(location|located)\b/i],dataKey: 'residencelocation'}
];

//=== Date related codes:
function parseISOish(dateStr){
  // accepts "YYYY", "YYYY-MM", "YYYY-MM-DD"
  if (!dateStr) return null;
  const m = String(dateStr).match(/^(\d{4})(?:[-/](\d{1,2}))?(?:[-/](\d{1,2}))?$/);
  if (!m) return null;
  const year  = +m[1];
  const month = m[2] ? +m[2] : null;
  const day   = m[3] ? +m[3] : null;
  //console.log('parseisoish ymd',year,month,day);
  return { year, month, day };
}
const p2 = (n)=> String(n).padStart(2,'0');

function detectSingleDateGranularity(el){
  // For single field date controls (not split month/year)
  const t   = (el.type||'').toLowerCase();
  const ph  = (el.getAttribute('placeholder')||'').toLowerCase();
  const idn = ((el.id||'') + ' ' + (el.name||'')).toLowerCase();

  if (t === 'month') return 'month-year-single';    // native <input type="month"> expects "YYYY-MM"
  if (t === 'date')  return 'date-single';          // native "YYYY-MM-DD"
  if( t==='year') return 'year-single';

  // Placeholder/ID heuristics
  if (/\bmm[\/\-]yyyy\b/.test(ph) || /\bmm[\/\-]yyyy\b/.test(idn))  return 'month-year-single';
  if (/\byyyy\b/.test(ph) || /\byear\b/.test(idn))                  return 'year-single';
  if (/\bdate\b/.test(idn) || /\bmm[\/\-]dd[\/\-]yyyy\b/.test(ph))  return 'date-single';

  return null;
}

// turn a parsed {year,month,day} into the string the field expects
function formatForGranularity(granularity, parts){
  if (!parts) return '';
  const {year, month, day} = parts;

  switch (granularity){
    case 'year-single':
      return year ? String(year) : '';
    case 'month-year-single':
      // Prefer native input[type=month] "YYYY-MM"; if the site wants "MM/YYYY" we’ll rewrite later if needed.
      if (year && month) return `${year}-${p2(month)}`;
      // If month missing, degrade to just year to avoid junk
      return year ? String(year) : '';
    case 'date-single':
      // Use safe fallback day=01 if missing
      if (year && month) return `${year}-${p2(month)}-${p2(day||1)}`;
      return year ? `${year}-01-01` : '';
    default:
      return '';
  }
}

function refineDateHumanNameAndGroup(obj){
  const el   = obj.element;
  const id   = el.id   || '';
  const name = el.name || '';
  const key  = (id + ' ' + name).toLowerCase();

  const isStart = /\b(startdate|start_date|fromdate|from_date|from|firstyearattended)\b/.test(key);
  const isEnd   = /\b(enddate|end_date|todate|to_date|to|lastyearattended)\b/.test(key);
  const side    = isStart ? 'from' : (isEnd ? 'to' : null);

  const mentionsMonth = /\bmonth\b|datesectionmonth|\bmm\b/.test(key);
  const mentionsYear  = /\byear\b|datesectionyear|\byyyy\b/.test(key);
  const mentionsDay   = /\bday\b|datesectionday|\bdd\b/.test(key);   // ⬅️ new

  const singleGran = detectSingleDateGranularity(el);
  if (side && (mentionsMonth || mentionsYear || mentionsDay)){
    const part = mentionsMonth ? 'month' : mentionsYear ? 'year' : 'day';
    obj.humanName = `${side} ${part}`;
    obj.groupId   = obj.groupId || `date:${side}`;
    obj._dateMeta = { mode: 'split', side, part };
    return;
  }

  if (side && singleGran){
    obj.humanName = `${side} ${singleGran}`;
    obj.groupId   = obj.groupId || `date:${side}`;
    obj._dateMeta = { mode: 'single', side, granularity: singleGran };
    return;
  }

  if (!side && /start|begin|from/i.test(obj.humanName||'')){
    obj._dateMeta = { mode: singleGran ? 'single':'unknown', side: 'from', granularity: singleGran||null };
    obj.groupId   = obj.groupId || `date:from`;
    return;
  }
  if (!side && /\bend|finish|to\b/i.test(obj.humanName||'')){
    obj._dateMeta = { mode: singleGran ? 'single':'unknown', side: 'to', granularity: singleGran||null };
    obj.groupId   = obj.groupId || `date:to`;
    return;
  }

  if (singleGran){
    obj._dateMeta = { mode: 'single', side: null, granularity: singleGran };
  }
}
function adaptMonthYearToPlaceholder(el, val, parts){
  const ph = (el.getAttribute('placeholder')||'').toLowerCase();
  if (!parts || !parts.year || !parts.month) return val;
  if (/\bmm[\/\-]yyyy\b/.test(ph)) return `${p2(parts.month)}/${parts.year}`;
  return val; // keep "YYYY-MM"
}
const MONTH_NAMES = ['january','february','march','april','may','june','july','august','september','october','november','december'];

function optionText(el){
  return (el.textContent || el.label || '').trim().toLowerCase();
}

function findOptionIndex(el, candidates){
  const opts = Array.from(el.options || []);
  // exact first, then contains
  for (const c of candidates){
    const idx = opts.findIndex(o => optionText(o) === c);
    if (idx >= 0) return idx;
  }
  for (const c of candidates){
    const idx = opts.findIndex(o => optionText(o).includes(c));
    if (idx >= 0) return idx;
  }
  return -1;
}

function monthCandidates(m){
  const n = Number(m);
  if (!n || n < 1 || n > 12) return [];
  const name = MONTH_NAMES[n-1];
  return [
    String(n),                     // "3"
    String(n).padStart(2,'0'),     // "03"
    name,                          // "march"
    name.slice(0,3)                // "mar"
  ];
}
function resolveDateSource(obj){ // entry = one experience/education item
  // Prefer the metadata side, fall back to humanName hints
  const side = obj._dateMeta?.side
    || (/\b(from|start)\b/i.test(obj.humanName || '') ? 'from'
        : /\b(to|end)\b/i.test(obj.humanName || '') ? 'to' : null);

  return side;
}
async function fillDate(el, obj,value,{currentlyWorkHere=false}={}){
  //console.log('filldate datemeta',obj._dateMeta);
  // 1) Resolve ISO source
  const side = resolveDateSource(obj);
  //const iso = value;
  //console.log('filldate side and iso:',side,iso);
  if (side === 'to' && currentlyWorkHere) {
    //console.log('filDate, skipping to.. because of currently working');
    // Many pages disable/ignore end date if "currently work here" is checked
    return;
  }

  // 2) Parse parts
  //const parts = parseISOish(iso); //returns the data with split(year,month and day)
  const parts = value;
  //console.log('fillDate, splitting ymd:',parts.year,parts.month,parts.day);
  const tag = (el.tagName || '').toUpperCase();
  //const type = (el.type || '').toLowerCase();

  // 3) If we have explicit split meta (month/year pieces)
  if (obj._dateMeta?.mode === 'split'){
    if (!parts) return;
    if (obj._dateMeta.part === 'year'){
      const val = parts; //parts.year ? String(parts.year) : '';
      if (tag === 'SELECT') {
        //console.log('filldate year select tag val:',val)
        const idx = findOptionIndex(el, [String(val)]);// [String(parts.year)]);
        if (idx >= 0) { el.selectedIndex = idx; el.dispatchEvent(new Event('change', {bubbles:true})); }
        else{//console.log('fillDate skipping tag and entering regular type fill');
          await fillInput(el, val);}
      } else {
        //console.log('fillDate 2.year skipping tag and entering regular type fill');
        await fillInput(el, val);
      }
      return;
    }
    if (obj._dateMeta.part === 'month'){
      console.log('In fillDate func,Entered into the month part with value',value);
      //if (!parts.month){ /* degrade quietly if month unknown */ console.log('fillDate skipping month fill because off no value:',val); return; }
      if (tag === 'SELECT'){
        //console.log('filldate month select tag val:',val)
        const idx = findOptionIndex(el, monthCandidates(value));//monthCandidates(parts.month));
        if (idx >= 0){
          el.selectedIndex = idx;
          el.dispatchEvent(new Event('change', {bubbles:true}));
        }else{
          //console.log('fillDate 1.skipping month tag and entering regular type fill');
          await fillInput(el,String(parts).padStart(2,'0')); //String(parts.month).padStart(2,'0'));
        }
      }else{
        //console.log('fillDate 2.month skipping tag and entering regular type fill');
        await fillInput(el, String(parts).padStart(2,'0'));//String(parts.month).padStart(2,'0'));
      }
      return;
    }
    if (obj._dateMeta.part === 'day'){
      if (!parts.month){ /* degrade quietly if month unknown */ console.log('fillDate skipping day fill because off no value:',val); return; }
      if (tag === 'SELECT'){
        //console.log('filldate day select tag val:',val)
        const idx = findOptionIndex(el,parts);// parts.day);
        if (idx >= 0){
          el.selectedIndex = idx;
          el.dispatchEvent(new Event('change', {bubbles:true}));
        }else{
          //console.log('fillDate 1.skipping day tag and entering regular type fill');
          await fillInput(el, tring(parts).padStart(2,'0'));//String(parts.day).padStart(2,'0'));
        }
      }else{
        //console.log('fillDate 2.month skipping tag and entering regular type fill');
        await fillInput(el,tring(parts).padStart(2,'0')); //String(parts.day).padStart(2,'0'));
      }
      return;
    }
    

    

  }
  // 4) Single-field date
  // Detect granularity if metadata missing (defensive)
  const gran = obj._dateMeta?.granularity || detectSingleDateGranularity(el);
  let val = formatForGranularity(gran, parts);
  //console.log('filldate,gran value:',val);
  // adapt to "MM/YYYY" placeholders when it's a month-year control
  if (gran === 'month-year-single'){
    val = adaptMonthYearToPlaceholder(el, val, parts);
    //console.log('filldate,gran month-year-single value:',val);
  }

  // For <select> style "single" fields (rare), try options too
  if (tag === 'SELECT'){
    const candidates =
      gran === 'year-single'       ? [String(parts?.year || '')]
    : gran === 'month-year-single' ? (parts?.month ? monthCandidates(parts.month).map(c=>/\d{2}/.test(c)? `${c}/${parts.year}`: c) : [])
    : gran === 'date-single'       ? [val, val.replace(/-/g,'/')]
    : [val];

    const idx = findOptionIndex(el, candidates.map(s => String(s).toLowerCase()));
    if (idx >= 0){
      el.selectedIndex = idx;
      el.dispatchEvent(new Event('change', {bubbles:true}));
      return;
    }
  }

  // 5) Default to input fill
  console.log('filldate final going for fill input with value:',val);
  await fillInput(el, val);
}
const processedDateBatches = new Set(); // separate from your processedGroups for radios/checkboxes

function batchKeyForDate(decision, obj){
  const side = obj._dateMeta?.side || 'na';
  // decision has { kind, index } like 'experience' / 2  or 'education' / 1
  if(decision.kind && decision.index){
    return `${decision.kind}:${decision.index}:${side}`
  }
  else{
    return `${decision.dataKey}:${side}`
  }
}

// gather up to 3 nearby split-date peers (day/month/year) with same groupId & side
function collectLocalSplitDatePeers(inputs, startIdx, obj){
  const side    = obj._dateMeta?.side || '';
  const groupId = obj.groupId;
  const peers = new Map(); // part -> {obj, idx}

  // scan up to 2 back and 3 forward to capture day/month/year even if order varies
  const lo = Math.max(0, startIdx - 2);
  const hi = Math.min(inputs.length - 1, startIdx + 3);

  for (let i = lo; i <= hi; i++){
    const p = inputs[i];
    if (!p || p._dateMeta?.mode !== 'split') continue;
    if (p.groupId !== groupId) continue;
    if ((p._dateMeta?.side || '') !== side) continue;

    const part = p._dateMeta.part; // 'day' | 'month' | 'year'
    if (part && !peers.has(part)) peers.set(part, { obj: p, idx: i });
    if (peers.size >= 3) break;
  }

  // order month -> year -> day (month first helps some validators)
  const order = ['month', 'year', 'day'];
  const final = order.map(k => peers.get(k)?.obj).filter(Boolean);
  print("in collectlocalsplitdatepeeres func the final value",final);
  return final;
}

//===select helpers
function splitMultiValues(val) {
  return val.split(/[,;/|]+/).map(v => v.trim()).filter(Boolean);
}
function isComplexDropdown(el) {
  return (
    el.getAttribute('role') === 'combobox' ||
    el.closest('.MuiAutocomplete-root, .ant-select, .rc-select')
  );
}
//Step-  , New helpers for select semantic analysis, 


//Step-12, for filling select elements
async function bestOptionMatch(labels, answer, { humanName = '', min = 0.62 } = {}) {
  const clean = s => normalizeFieldNameWithSpace(String(s || ''));

  // 1) quick local rules first
  const a = clean(answer);
  const L = labels.map(x => ({ raw: x, c: clean(x) })).filter(x => x.c);

  // exact / contains
  for (const x of L) {
    if (x.c === a) return { ok:true, label:x.raw, score:1, why:'exact' };
  }
  for (const x of L) {
    if (x.c.includes(a) || a.includes(x.c)) return { ok:true, label:x.raw, score:0.92, why:'contains' };
  }

  // degree-aware alias rules (cheap, super effective)
  const alias = degreeAlias(a);
  if (alias) {
    // try match alias tokens
    const best = pickByTokenScore(L, alias);
    if (best && best.score >= 0.78) return { ok:true, label:best.raw, score:best.score, why:'alias-token' };
  }

  // 2) local fuzzy
  const bestFuzzy = pickByFuzzy(L, a);
  if (bestFuzzy && bestFuzzy.score >= 0.78) {
    return { ok:true, label:bestFuzzy.raw, score:bestFuzzy.score, why:'fuzzy' };
  }

  // 3) embeddings via background/offscreen
  const r = await chrome.runtime.sendMessage({
    action: 'bestMatch',
    labels: labels.slice(0, 400), // safety cap
    answer,
    ctx : {humanName}
  });
  // Expect: {ok:true, label:"...", labelIndex:n, score:0.xx, method:"embed|exact|contains"}
  if (r?.ok && typeof r.label === 'string' && (r.score ?? 0) >= min) {
    console.log('checking label given by best match',r.label);
    return { ok:true, label: r.label, score: r.score, why: r.method || 'embed' };
  }
  
  // If embeddings were weak, fall back to best fuzzy anyway (but mark low)
  if (bestFuzzy) return { ok:true, label:bestFuzzy.raw, score:bestFuzzy.score, why:'fuzzy-low' };

  return { ok:false, reason:'no-match' };
}

function degreeAlias(a) {
  // normalize + collapse
  const t = a.toLowerCase();

  // common exact patterns
  if (/\b(bachelor|bachelors|b\.?s\.?|bsc|b\.?sc)\b/.test(t)) return 'bachelor';
  if (/\b(master|masters|m\.?s\.?|msc|m\.?sc)\b/.test(t)) return 'master';
  if (/\b(phd|ph\.?d|doctorate)\b/.test(t)) return 'phd';

  if (/\bb\.?tech\b|\bbachelor of technology\b/.test(t)) return 'bachelor technology';
  if (/\bb\.?e\b|\bbachelor of engineering\b/.test(t)) return 'bachelor engineering';
  if (/\bm\.?tech\b|\bmaster of technology\b/.test(t)) return 'master technology';
  if (/\bmba\b|\bmaster of business\b/.test(t)) return 'mba';

  return null;
}

function pickByTokenScore(L, aliasText) {
  const want = new Set(aliasText.split(/\s+/).filter(Boolean));
  let best = null;

  for (const x of L) {
    const tokens = new Set(x.c.split(/\s+/).filter(Boolean));
    let hit = 0;
    for (const w of want) if (tokens.has(w)) hit++;
    const score = hit / Math.max(1, want.size);
    if (!best || score > best.score) best = { raw: x.raw, score };
  }

  if (!best) return null;
  // scale into same range as other scores
  best.score = 0.6 + 0.4 * best.score;
  return best;
}

function pickByFuzzy(L, a) {
  let best = null;
  for (const x of L) {
    const s = fuzzyScore(x.c, a); // you already have fuzzyScore
    if (!best || s > best.score) best = { raw: x.raw, score: s };
  }
  return best;
}


async function fillSelectElement(el, value, opts={}) {
  if (!el || el.disabled || el.readOnly) return;
  const {
    mapped = false,
    humanName = "",
    timeout,
    exactFirst,
    radius
  } = opts;

  const tag = el.tagName?.toUpperCase?.();
  const valStr = (value ?? '').toString().trim();
  if (!valStr) return;
  // Scroll to make it visible
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  simulateMouse(el);
  await delay(50);
  /*
  // ----- Case 1: Native <select> (single)
  if (tag === 'SELECT' && !el.multiple) {
    console.log('1. fillselectelement func,select but not multiple');
    const match = [...el.options].find(opt =>
      normalizeFieldNameWithSpace(opt.textContent || '').includes(
        normalizeFieldNameWithSpace(valStr)
      )
    );
    if (match) {
      el.value = match.value;
      el.selectedIndex = match.index;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return true;
    }
  }*/
  if (tag === 'SELECT' && !el.multiple) {
    const labels = [...el.options].map(o => o.textContent || '');
    const sem = await bestOptionMatch(labels, valStr, { humanName: opts.humanName, min: semanticMinThreshold(opts.humanName) });

    if (sem?.ok) {
      const match = [...el.options].find(o => (o.textContent || '').trim() === sem.label.trim());
      if (match) {
        el.value = match.value;
        el.selectedIndex = match.index;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      }
    }
  }

  // ----- Case 2: Native <select multiple>
  if (tag === 'SELECT' && el.multiple) {
    console.log('2. Fillselectelement func select and multiple');
    const vals = splitMultiValues(valStr);
    let changed = false;
    for (const opt of el.options) {
      const shouldSelect = vals.some(v =>
        normalizeFieldNameWithSpace(opt.textContent || '').includes(
          normalizeFieldNameWithSpace(v)
        )
      );
      if (opt.selected !== shouldSelect) {
        opt.selected = shouldSelect;
        changed = true;
      }
    }
    if (changed) {
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }
    return true;
  }

  // ----- Case 3: Custom dropdown (MUI / Ant / React-Select / Ashby)
  //Ashby selects
  if (isComplexDropdown(el) && (isAshbyHost || isGreenhouseHost)) {
    console.log('3. fillselectelement func select and complexdropdown');
    const timeout = opts.timeout ?? 1500;
    const radius  = opts.radius ?? 700;
    const exactFirst = opts.exactFirst ?? true;
    /*const btn = findNearestDropdownButton(el);
    console.log('btn found in fillworkday:',btn);
    //if (!btn) return false;
    // 1) Open the popup
    //simulatePointerClick(btn);
    */
    const findComboTextInput = (root) => {
      if (root.tagName === 'INPUT') return root;
      return (
        root.querySelector('input[type="text"]') ||
        root.querySelector('input:not([type])') ||
        root.querySelector('[role="textbox"]') ||
        root
      );
    };
    const textBox = findComboTextInput(el);
    if (!textBox) return false;
    // 3.2 set the value with native setter + input events so React sees it
    const setNative = (input, val) => {
      const proto = Object.getPrototypeOf(input);
      const desc  = Object.getOwnPropertyDescriptor(proto, 'value');
      const setter = desc && desc.set;
      if (setter) setter.call(input, val);
      else input.value = val;

      try { input.dispatchEvent(new InputEvent('beforeinput', { bubbles:true, inputType:'insertText', data:String(val) })); } catch {}
      input.dispatchEvent(new Event('input',  { bubbles:true, composed:true }));
      input.dispatchEvent(new Event('change', { bubbles:true, composed:true }));
    };

    // 3.3 focus, put the text, nudge with a key to trigger filtering
    textBox.focus();
    simulateMouse(textBox);
    setNative(textBox, valStr);
    textBox.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', bubbles: true }));
    textBox.dispatchEvent(new KeyboardEvent('keyup',   { key: 'ArrowDown', bubbles: true }));
    await waitUntil(() => textBox.getAttribute('aria-expanded') === 'true', 350);
    // 2) Find nearest listbox to this button
    let listbox = await waitForNearestListbox(textBox, timeout, radius);
    console.log('list box found:',listbox);
    if (!listbox) {
      console.log('list box not found, so trying one more time')
      // one retry: click again then re-scan
      simulatePointerClick(textBox);
      await delay(120);
      listbox = await waitForNearestListbox(textBox, timeout, radius);
      console.log('fter trying 2nd time listbox',listbox);
      if (!listbox) return false;
    }
    // 3) Try to select the option by scanning (handles virtualized lists via scrolling)
    //const picked = await scanAndSelectOption(listbox, value, { exactFirst, timeout });
    const picked = await scanAndSelectOption(listbox, value, {
      exactFirst,
      timeout,
      humanName: opts.humanName
    });

    if (!picked) {
      // fallback: send ESC to close if still open
      console.log('No picked options')
      tryClosePopup(textBox, listbox);
      return false;
    }
    // 4) Close the popup (many WD lists auto-close on selection; but ensure)
    tryClosePopup(textBox, listbox);
    return true;
  }
  // Case 3: Custom dropdown (MUI/Ant/React-Select etc.) 
  if (isComplexDropdown(el)) { 
    console.log('4. fillselectelement func select and complexdropdown2') 
    try { 
      el.click(); 
      await delay(200); 
      const list = document.querySelector('[role="listbox"], ul[role="menu"], .MuiAutocomplete-popper, .ant-select-dropdown, .rc-virtual-list-holder'); 
      if (!list) return false; 
      const options = [...list.querySelectorAll('[role="option"], li, div')]; 
      const target = options.find(opt => normalizeFieldNameWithSpace(opt.textContent || '').includes( normalizeFieldNameWithSpace(valStr) ) );
       if (target) { 
        clickOptionLike(target); return true; 
      } 
      // fallback: close if not found 
      document.body.click(); 
    } 
    catch (err) { 
      console.warn('5.fillSelectElement func custom dropdown failed', err); 
    } 
    return true;
  }
  return false;

}

//In workday, For choosing the option when theu use button(arrow)/instead of select
function isWorkdayCombo(el){ 
  // Prefer the nearest WD-ish container if present, else fall back to a div
  const root = el.closest(
    '[data-automation-id*="select"],' +                 // e.g., multiSelectContainer, selectDropdown, etc.
    '[data-uxi-widget-type="selectinput"],' +          // WD select input widget
    '[data-automation-id*="multiSelect"],' +           // multiSelectContainer
    '[data-automation-id*="prompt"],' +                // promptIcon / promptOption
    'div'
  );
  if (!root) return false;

  // Base signals (your originals)
  const hasButton = !!root.querySelector('button[aria-haspopup="listbox"], button[aria-expanded]');
  const hasText   = !!root.querySelector('input[type="text"], input:not([type]), input[role="combobox"], [role="combobox"]');
  const hasArrow  = !!root.querySelector('[data-automation-id="promptIcon"], [class*="promptIcon"], span, svg, i');

  // Workday-specific strong signals (seen in your screenshot)
  const hasWDAtt = (
    root.matches('[data-automation-id], [data-uxi-widget-type]') ||
    !!root.querySelector(
      '[data-automation-id*="select"],' +
      '[data-automation-id*="multiSelect"],' +
      '[data-automation-id*="prompt"],' +
      '[data-uxi-widget-type="selectinput"]'
    )
  );

  // Nearby listbox cues (often rendered/telegraphed even if virtualized)
  const hasListboxHints = !!root.querySelector(
    '[role="listbox"], [aria-controls*="listbox"], [id*="listbox"], [data-automation-id*="selectDropdown"]'
  );

  // Two ways to declare "combo":
  // 1) Your original triad (button + text + arrow)
  // 2) WD multiselect variant (text + WD signals + (arrow OR listbox hints))
  const classicCombo = hasButton && hasText && hasArrow;
  const wdCombo = hasText && hasWDAtt && (hasArrow || hasListboxHints);

  const result = classicCombo || wdCombo;
  // Optional debug
  // console.log({ classicCombo, wdCombo, hasButton, hasText, hasArrow, hasWDAtt, hasListboxHints });
  return result;
}

function tryClosePopup(btn, listbox) {
  // If still expanded, try ESC first (less intrusive than body click)
  if (btn?.getAttribute('aria-expanded') === 'true') {
    listbox?.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
    listbox?.dispatchEvent(new KeyboardEvent('keyup',   { key: 'Escape', bubbles: true }));
  }
  // If stubborn, click outside once
  if (btn?.getAttribute('aria-expanded') === 'true') {
    document.body.click();
  }
}

function simulatePointerClick(el) {
  const r = el.getBoundingClientRect();
  const x = r.left + r.width / 2, y = r.top + Math.min(r.height / 2, 16);
  el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, clientX: x, clientY: y }));
  el.dispatchEvent(new MouseEvent('mousedown',    { bubbles: true, clientX: x, clientY: y }));
  el.dispatchEvent(new MouseEvent('mouseup',      { bubbles: true, clientX: x, clientY: y }));
  el.click();
  el.dispatchEvent(new PointerEvent('pointerup',  { bubbles: true, clientX: x, clientY: y }));
}

function isClickableVisible(el){
  if (!isVisible(el)) return false;
  const cs = getComputedStyle(el);
  return cs.pointerEvents !== 'none';
}


function getCenter(el){
  const r = el.getBoundingClientRect();
  return { x: r.left + r.width/2, y: r.top + r.height/2 };
}

function distance(a,b){ return Math.hypot(a.x - b.x, a.y - b.y); }

//Step defingin a best way to seelct the semantic option related to degree.
function norm(s){
  return (s ?? '')
    .toString()
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')   // strip accents
    .replace(/[\u2019']/g,'')
    .replace(/[^a-z0-9+%&().,\-\/\s]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function fuzzyScore(txt, want){
  if (!txt || !want) return 0;
  if (txt === want) return 1;
  if (txt.startsWith(want)) return 0.9;
  if (txt.includes(want)) return Math.min(0.88, want.length / Math.max(txt.length, 1));
  // token overlap
  const A = new Set(txt.split(' ')), B = new Set(want.split(' '));
  let hit = 0; B.forEach(t => { if (A.has(t)) hit++; });
  return hit / Math.max(B.size, 1) * 0.7;
}

function clickOptionLike(opt){
  opt.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true }));
  opt.dispatchEvent(new MouseEvent('mousedown',    { bubbles: true }));
  opt.dispatchEvent(new MouseEvent('mouseup',      { bubbles: true }));
  opt.click();
  opt.dispatchEvent(new PointerEvent('pointerup',  { bubbles: true }));
}

function delay(ms){ return new Promise(r => setTimeout(r, ms)); }

async function waitUntil(fn, ms = 1200, step = 50) {
  const t0 = performance.now();
  while (performance.now() - t0 < ms) {
    try { if (await fn()) return true; } catch {}
    await new Promise(r => setTimeout(r, step));
  }
  return false;
}
//Find the nearest visible listbox/menu to the anchor (button) within a radius.
async function waitForNearestListbox(anchor, timeout = 1200, radius = 700) {
  const start = performance.now();
  const anchorCenter = getCenter(anchor);

  const pick = () => {
    // Common WD portals: role=listbox/menu, sometimes data-automation-id=listbox
    const candidates = [
      ...document.querySelectorAll('[role="listbox"], [role="menu"], [data-automation-id="listbox"]')
    ].filter(isVisible);

    let best = null, bestD = Infinity;
    for (const c of candidates) {
      const d = distance(anchorCenter, getCenter(c));
      if (d < bestD && d <= radius) { best = c; bestD = d; }
    }
    return best;
  };

  while (performance.now() - start < timeout) {
    const lb = pick();
    if (lb) return lb;
    await delay(40);
  }
  return null;
}
async function collectListboxLabelsSample(listbox, { steps = 6 } = {}) {
  const labels = new Set();
  listbox.scrollTop = 0;
  await delay(30);

  for (let i = 0; i < steps; i++) {
    for (const opt of collectOptionNodes(listbox)) {
      const t = (opt.textContent || '').trim();
      if (t) labels.add(t);
    }
    const atBottom = Math.ceil(listbox.scrollTop + listbox.clientHeight) >= listbox.scrollHeight;
    if (atBottom) break;
    listbox.scrollTop = Math.min(listbox.scrollTop + Math.floor(listbox.clientHeight * 0.9), listbox.scrollHeight);
    await delay(60);
  }
  return [...labels];
}

function semanticMinThreshold(humanName='') {
  const h = humanName.toLowerCase();
  if (h.includes('degree') || h.includes('education')) return 0.62;
  if (h.includes('country') || h.includes('state')) return 0.78;
  if (h.includes('gender')) return 0.85;
  return 0.70;
}


//step-13, for scanning,typing the value and selecting the option

 // Scrolls a (possibly virtualized) listbox to find and click the best option.
async function scanAndSelectOption(
  listbox,
  targetText,
  {
    humanName = "",
    exactFirst = true,
    timeout = 1500,
    typeFallback = true,
    typeFallbackTimeout = 700,
    typeEl = null, // <-- pass the combobox input here if you have it
  } = {}
) {
  const start = performance.now();
  const want = norm(targetText);

  // Ensure we start from the top
  listbox.scrollTop = 0;

  const seen = new Map(); // text -> element (last seen)
  let bestLoose = null;   // { el, score, txt }

  while (performance.now() - start < timeout) {
    const options = collectOptionNodes(listbox);

    for (const opt of options) {
      const txt = norm(opt.textContent);
      //console.log('In Scan and selection option func, the options are ',txt);
      if (!txt) continue;

      // Dedup by text; keep the *currently visible* element so clicks work
      seen.set(txt, opt);
      //console.log('In scanandselectoption func,the exactfirst:',exactFirst);
      if (exactFirst && (txt === want || txt.includes(want) || want.includes(txt))) {
        console.log('In scanandselectoption func, the option ready to select:',txt)
        clickOptionLike(opt);
        return true;
      }
      const score = fuzzyScore(txt, want);
      //console.log('In scanandselectoption func, the option score was',score)
      if (!bestLoose || score > bestLoose.score) bestLoose = { el: opt, score, txt };
    }

    // If we’re at the bottom, break
    const atBottom = Math.ceil(listbox.scrollTop + listbox.clientHeight) >= listbox.scrollHeight;
    if (atBottom) break;

    // Scroll further down to trigger virtualization
    listbox.scrollTop = Math.min(
      listbox.scrollTop + Math.max(40, Math.floor(listbox.clientHeight * 0.9)),
      listbox.scrollHeight
    );
    await delay(80);
  }

  // If exact/contains not found, try best fuzzy match (threshold keeps it sane)
  if (bestLoose ){//&& bestLoose.score >= 0.30) {
    // DON'T click yet if this is a select-like field where semantics matter
    // We'll attempt semantic resolve using the currently seen labels.
    const labels = [...seen.keys()];
    console.log('In scanandselectoption func,Inside bestloose the labels using to find matching option',labels);
    const sem = await bestOptionMatch(labels, targetText, { min: 0.62 });
    if (sem?.ok) {
      const key = norm(sem.label);
      const el = seen.get(key) || [...seen.values()].find(o => norm(o.textContent) === key);
      if (el) {
        console.log('in scan and select func the option it is going to check with fuzzy matching',el)
        clickOptionLike(el);
        return true;
      }
    }
    // fallback: click best fuzzy
    clickOptionLike(bestLoose.el);
    return true;
  }

  /*
  if (bestLoose && bestLoose.score >= 0.30) {
    clickOptionLike(bestLoose.el);
    return true;
  }*/

  // ------------------------------------------------------------
  // NEW FALLBACK: type value -> select from visible options only
  // ------------------------------------------------------------
  if (typeFallback && want) {
    const input = typeEl || findComboInputForListbox(listbox);

    if (input) {
      // type and let react-select re-filter options
      await typeIntoComboInput(input, targetText);
      await delay(80);

      const start2 = performance.now();
      while (performance.now() - start2 < typeFallbackTimeout) {
        const visibleOpts = collectVisibleOptionNodes(listbox);

        // exact / contains first from visible
        let pick =
          visibleOpts.find(o => norm(o.textContent) === want) ||
          visibleOpts.find(o => norm(o.textContent).includes(want)) ||
          visibleOpts.find(o => want.includes(norm(o.textContent)));

        if (!pick && visibleOpts.length) {
          // else best fuzzy from visible
          let best = null;
          for (const o of visibleOpts) {
            const t = norm(o.textContent);
            if (!t) continue;
            const s = fuzzyScore(t, want);
            if (!best || s > best.s) best = { o, s };
          }
          if (best && best.s >= 0.25) pick = best.o;
        }

        if (pick) {
          clickOptionLike(pick);
          return true;
        }

        // options might still be rendering
        await delay(60);
      }
    }
  }
  //New fallback
  const sampleLabels = await collectListboxLabelsSample(listbox, { steps: 6 });
  const sem = await bestOptionMatch(sampleLabels, targetText, { min: 0.62 });
  /*
  if (sem?.ok) {
    // Now re-scan + click the matched label (may require scrolling until it's visible)
    const ok = await scrollUntilOptionVisibleAndClick(listbox, sem.label, { timeout: 1200 });
    if (ok) return true;
  }
   */

  return false;
}

/* ---------------- helpers for select typing fallback ---------------- */

function findComboInputForListbox(listbox) {
  // React-select pattern: input[aria-controls="<listbox.id>"]
  const doc = listbox?.ownerDocument || document;
  const id = listbox?.id;
  if (!id) return null;

  return doc.querySelector(`input[aria-controls="${CSS.escape(id)}"]`);
}

async function typeIntoComboInput(input, text) {
  input.scrollIntoView({ block: 'center' });
  input.focus();
  input.click();

  // clear
  setValueWithNativeSetter(input, '');
  try { input.dispatchEvent(new InputEvent('beforeinput', { bubbles:true, inputType:'deleteContentBackward', data:null })); } catch {}
  input.dispatchEvent(new Event('input', { bubbles:true, composed:true }));

  // type
  setValueWithNativeSetter(input, String(text));
  try { input.dispatchEvent(new InputEvent('beforeinput', { bubbles:true, inputType:'insertText', data:String(text) })); } catch {}
  input.dispatchEvent(new Event('input', { bubbles:true, composed:true }));
  input.dispatchEvent(new Event('change', { bubbles:true, composed:true }));

  // nudge menu
  input.dispatchEvent(new KeyboardEvent('keydown', { key:'ArrowDown', bubbles:true }));
  input.dispatchEvent(new KeyboardEvent('keyup',   { key:'ArrowDown', bubbles:true }));

  await delay(40);
}

function collectVisibleOptionNodes(listbox) {
  const opts = collectOptionNodes(listbox);
  const lbRect = listbox.getBoundingClientRect();

  // Only keep ones actually visible in the viewport of the listbox
  return opts.filter(o => {
    if (!o || !o.getBoundingClientRect) return false;
    const r = o.getBoundingClientRect();
    const verticallyVisible = r.bottom > lbRect.top + 2 && r.top < lbRect.bottom - 2;
    const notHidden = r.width > 0 && r.height > 0;
    return verticallyVisible && notHidden;
  });
}
/*
async function scanAndSelectOption(listbox, targetText, { exactFirst = true, timeout = 1500 } = {}) {
  const start = performance.now();
  const want = norm(targetText);

  // Ensure we start from the top
  listbox.scrollTop = 0;

  const seen = new Map(); // text -> element (last seen)
  let bestLoose = null;   // { el, score, txt }

  while (performance.now() - start < timeout) {
    const options = collectOptionNodes(listbox);
    //console.log('options collected',options);

    for (const opt of options) {
      const txt = norm(opt.textContent);
      if (!txt) continue;

      // Dedup by text; keep the *currently visible* element so clicks work
      seen.set(txt, opt);

      if (exactFirst && (txt === want || txt.includes(want) || want.includes(txt))) {
        clickOptionLike(opt);
        return true;
      }

      const score = fuzzyScore(txt, want);
      if (!bestLoose || score > bestLoose.score) bestLoose = { el: opt, score, txt };
    }

    // If we’re at the bottom, break
    const atBottom = Math.ceil(listbox.scrollTop + listbox.clientHeight) >= listbox.scrollHeight;
    if (atBottom) break;

    // Scroll further down to trigger virtualization
    listbox.scrollTop = Math.min(listbox.scrollTop + Math.max(40, Math.floor(listbox.clientHeight * 0.9)), listbox.scrollHeight);
    await delay(80);
  }

  // If exact/contains not found, try best fuzzy match (threshold keeps it sane)
  if (bestLoose && bestLoose.score >= 0.30) {
    clickOptionLike(bestLoose.el);
    return true;
  }

  return false;
}
  */
function isToggleButton(n){
  if (!n || n.nodeType !== 1) return false;
  const tag = n.tagName?.toLowerCase();
  if (tag === 'button') {
    return n.hasAttribute('aria-haspopup') || n.hasAttribute('aria-expanded');
  }
  // Some UIs use div/span with role=button
  if ((n.getAttribute('role') === 'button') && n.hasAttribute('aria-haspopup')) return true;
  return false;
}

/**
 * Finds the nearest dropdown toggle button for a Workday-like combo.
 * Looks at self, then scans container & a few ancestors for a matching button.
 */
function findNearestDropdownButton(el, maxHops = 3){
  if (!el) return null;
  if (isToggleButton(el)) return el; // if caller passed the button itself

  // Prefer a semantic container first
  let container = el.closest('[data-automation-id], [role="group"], .wd-select, .wd-input, .MuiAutocomplete-root, .ant-select, div');

  // Walk up a few levels; within each, query for a proper toggle button
  let node = container || el;
  for (let i = 0; node && i <= maxHops; i++, node = node.parentElement) {
    const btn = node.querySelector(
      'button[aria-haspopup="listbox"], button[aria-expanded], [role="button"][aria-haspopup="listbox"]'
    );
    if (isToggleButton(btn)) return btn;
  }
  return null;
}

function collectOptionNodes(listbox) {
  // Workday variants + fallbacks (role=option most common)
  const sel = [
    '[role="option"]',
    '[data-automation-id="option"]',
    '[role="menuitem"]',
    'li',
    '.wd-option' // rare custom class; harmless if absent
  ].join(',');

  // Only return clickable/visible ones
  return [...listbox.querySelectorAll(sel)].filter(isClickableVisible);
}
/**
 * Open a Workday-style dropdown via its button, find the nearest popup listbox,
 * scroll through all options (even virtualized), select the best match, and close.
 *
 * @param {HTMLElement} el - the toggle button itself OR any descendant of the WD combo
 * @param {string} value  - visible text you want to pick
 * @param {object} opts   - { timeout?: number, radius?: number, exactFirst?: boolean }
 * @returns {Promise<boolean>}
 */
//workday selects
async function fillWorkdayByButton(el, value, opts = {}) {
  const {
    humanName = "",
    timeout = 1500,
    radius = 700,
    exactFirst = true
  } = opts;
  //const timeout = opts.timeout ?? 1500;
  //const exactFirst = opts.exactFirst ?? true;
  //const humanName = opts.humanName?? "";
  const btn = findNearestDropdownButton(el);
  console.log('btn found in fillworkday:',btn);
  if (!btn) return false;
  // 1) Open the popup
  simulatePointerClick(btn);
  await waitUntil(() => btn.getAttribute('aria-expanded') === 'true', 350);
  // 2) Find nearest listbox to this button
  let listbox = await waitForNearestListbox(btn, timeout, radius);
  console.log('list box found:',listbox);
  if (!listbox) {
    console.log('list box not found, so trying one more time')
    // one retry: click again then re-scan
    simulatePointerClick(btn);
    await delay(120);
    listbox = await waitForNearestListbox(btn, timeout, radius);
    console.log('fter trying 2nd time listbox',listbox);
    if (!listbox) return false;
  }
  // 3) Try to select the option by scanning (handles virtualized lists via scrolling)
  const picked = await scanAndSelectOption(listbox, value, {...opts,timeout,radius, exactFirst, humanName });
  if (!picked) {
    // fallback: send ESC to close if still open
    console.log('No picked options')
    tryClosePopup(btn, listbox);
    return false;
  }
  // 4) Close the popup (many WD lists auto-close on selection; but ensure)
  tryClosePopup(btn, listbox);
  return true;
}


// ========= RESUME HELPERS (unchanged except for minor hygiene) =========
const FILE_POS_KW_RE = /\b(resume|cv|curriculum\s*vitae|cover\s*letter)\b/i;
const FILE_NEG_KW_RE = /\b(attach|upload|choose|select|browse|drag|drop|click|tap|select\s+one)\b/i;
const FILE_SIZE_HINT_RE = /\b(?:max(?:imum)?\s*size|size\s*limit)\b.*|\(\s*\d+(?:\.\d+)?\s*(kb|mb|gb)\s*max\)/i;
function isFileField(el){ return (el?.type||'').toLowerCase() === 'file'; }
function stripFileCtas(s){
  if(!s) return '';
  return s.replace(FILE_SIZE_HINT_RE,' ').replace(/\b(or)\b/ig,' ').replace(/\s+/g,' ').trim();
}
function findFileFieldName(field, maxHops = 6){
  if(!isFileField(field)) return '';
  const HEADING_SEL = 'h1,h2,h3,h4,h5,h6,span,strong,[role="heading"],legend,[data-automation-id],label';//,[data-automation-id*="Heading"],[data-automation-id*="title"],label';
  if(field.id){
    const lab = document.querySelector(`label[for="${CSS.escape(field.id)}"]`);
    const t = stripFileCtas(lab?.textContent || '');
    if(FILE_POS_KW_RE.test(t)) return normalizeFieldNameWithSpace(t);
  }
  let el = field;
  for(let hop=0; el && el!==document.body && hop<=maxHops; hop++, el = el.parentElement){
    const h = el.querySelector(HEADING_SEL)
    if(h?.textContent){
      const t = stripFileCtas(h.textContent);
      if(FILE_POS_KW_RE.test(t)) return normalizeFieldNameWithSpace(t);
    }
    const selfTxt = stripFileCtas(el.textContent || '');
    if(FILE_POS_KW_RE.test(selfTxt) && selfTxt.split(/\s+/).length > 2)
      return normalizeFieldNameWithSpace(selfTxt);

    let prev = el.previousElementSibling;
    if(prev){
      const prevTxt = stripFileCtas(prev.textContent || '');
      if(FILE_POS_KW_RE.test(prevTxt)) return normalizeFieldNameWithSpace(prevTxt);
      const prevHead = prev.matches(HEADING_SEL) ? prev : prev.querySelector(HEADING_SEL);
      if(prevHead?.textContent){
        const t = stripFileCtas(prevHead.textContent);
        if(FILE_POS_KW_RE.test(t)) return normalizeFieldNameWithSpace(t);
      }
    }
    el = el.parentElement;
  }
  return '';
}
/*************************************************
 * Host gating
 *************************************************/
const SET1_HOSTS = new Set([
  'icims.com',              // <- add more later
]);

const SET2_HOSTS = new Set([
  'ashbyhq.com',
  'myworkdayjobs.com',
  'greenhouse.io',
  'boards.greenhouse.io',
]);

function hostIn(set) {
  const h = (location.hostname || '').toLowerCase();
  for (const d of set) {
    if (h === d || h.endsWith(`.${d}`)) return true;
  }
  return false;
}

const IS_SET1 = hostIn(SET1_HOSTS); // needs all the special checks (icims)
const IS_SET2 = hostIn(SET2_HOSTS); // no special checks (plain resume fields)

/*************************************************
 * Existing helpers (unchanged except where noted)
 *************************************************/
// autofill.js (or your bundle)

// ----- Messaging-based session helpers -----
async function sessSet(obj) {
  const res = await chrome.runtime.sendMessage({ type: 'SESSION_SET', payload: obj });
  if (!res?.ok) throw new Error(res?.error || 'SESSION_SET failed');
  return true;
}
async function sessGet(keyOrNull) {
  const res = await chrome.runtime.sendMessage({ type: 'SESSION_GET', payload: keyOrNull ?? null });
  if (!res?.ok) throw new Error(res?.error || 'SESSION_GET failed');
  return res.data || {};
}
async function sessRemove(keyOrKeys) {
  const res = await chrome.runtime.sendMessage({ type: 'SESSION_REMOVE', payload: keyOrKeys });
  if (!res?.ok) throw new Error(res?.error || 'SESSION_REMOVE failed');
  return true;
}
async function sessClear() {
  const res = await chrome.runtime.sendMessage({ type: 'SESSION_CLEAR' });
  if (!res?.ok) throw new Error(res?.error || 'SESSION_CLEAR failed');
  return true;
}

// ----- Your pending flag helpers now just call sess* -----
const PENDING_KEY = 'ja_resume_pending_v1';
function pageKey() {
  try { return `${location.origin}${location.pathname}`; }
  catch { return location.href; }
}
async function setPendingResumeUpload(resumeSrc) {
  if (!IS_SET1) return;
  await sessSet({ [PENDING_KEY]: { page: pageKey(), t: Date.now(), resumeSrc } });
}
async function getPendingResumeUpload() {
  if (!IS_SET1) return null;
  const o = await sessGet(PENDING_KEY);
  return o?.[PENDING_KEY] || null;
}
async function clearPendingResumeUpload() {
  if (!IS_SET1) return;
  await sessRemove(PENDING_KEY);
}

const parsedFileInputs = new WeakSet();
function markAutofilled(el, source='resume') {
  try { el.setAttribute('data-autofilled', 'true'); } catch {}
  try { el.setAttribute('data-resume-parsed', 'true'); } catch {}
  try { el.dataset.afSource = source; } catch {}
  parsedFileInputs.add(el);
}
function setFilesWithNativeSetter(input, fileList) {
  try {
    // 1) Try the element's own descriptor (rare)
    const own = Object.getOwnPropertyDescriptor(input, 'files');
    if (own?.set) {
      own.set.call(input, fileList);
      return;
    }
    // 2) Try HTMLInputElement prototype
    const proto = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'files');
    if (proto?.set) {
      proto.set.call(input, fileList);
      return;
    }
    // 3) As a last resort, define then assign (some sites lock it)
    Object.defineProperty(input, 'files', { configurable: true, writable: true, value: fileList });
  } catch (e) {
    console.warn('[resume] native setter failed, will attempt direct assign', e);
    try { input.files = fileList; } catch (e2) { console.error('[resume] direct assign failed', e2); }
  }
}

function dataURLtoBlob(dataurl){
  try{
    const [meta, data] = dataurl.split(',');
    const mime = ((meta || '').match(/:(.*?);/) || [])[1] || 'application/octet-stream';
    const bstr = atob((data || ''));
    const u8 = new Uint8Array(bstr.length);
    for (let i = 0; i < bstr.length; i++) u8[i] = bstr.charCodeAt(i);
    return new Blob([u8], { type: mime });
  }catch(e){
    console.error('[resume] dataURLtoBlob failed', e);
    return new Blob([], { type: 'application/octet-stream' });
  }
}

function fetchResumeFromBackground(fileUrl){
  return new Promise((resolve, reject)=>{
    try{
      chrome.runtime.sendMessage({ action:'fetchResume', fileUrl }, (resp)=>{
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError?.message || 'runtime error');
          return;
        }
        if (resp && resp.success && resp.fileData) resolve(resp);
        else reject(resp?.error || 'background fetch failed');
      });
    }catch(e){ reject(e); }
  });
}
// Some ATS require a user gesture before file assignment
async function withUserGesture(input, fn){
  try {
    input.focus();
    // A short, real click tends to satisfy most defenses
    //input.click?.();
    await new Promise(r => setTimeout(r, 30));
  } catch {}
  return await fn();
}
async function simulateFileSelectionFromBackground(inputElement, fileUrl){
  console.log('1. entered into simulate function');
  const src = fileUrl.startsWith('http') ? fileUrl : `${API_BASE_URL}${fileUrl}`;
  const { fileData, filename } = await fetchResumeFromBackground(src);
  const blob = dataURLtoBlob(fileData);
  const file = new File([blob], filename || (src.split('/').pop() || 'resume.pdf'), { type: blob.type || 'application/pdf' });
  const dt = new DataTransfer();
  dt.items.add(file);
  console.log('2.. In simulatefileselection func before ensure visible')
  console.log('3.. In simulatefileselection func going to set the file')
  return withUserGesture(inputElement, async () => {
    inputElement.dispatchEvent(new Event('focus', { bubbles: true }));
    // Emit an innocuous input event pre-assignment to wake frameworks
    inputElement.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    setFilesWithNativeSetter(inputElement, dt.files);
    // Many frameworks listen to 'change' only
    inputElement.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
    // Some also react to a second input after change
    inputElement.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
    inputElement.blur();
    inputElement.dispatchEvent(new Event('blur', { bubbles: true }));
    return true;
  });
}
async function tryAttachToDropzones(fileUrl){
  const zones = document.querySelectorAll('.dropzone, [data-dropzone], .file-drop, .upload-drop, [role="button"].drop, .upload-area, .dz-clickable, .dz-default, .attachment-drop, .file-uploader');
  if(!zones.length) return false;

  const src = fileUrl.startsWith('http') ? fileUrl : `${API_BASE_URL}${fileUrl}`;
  const { fileData, filename } = await fetchResumeFromBackground(src);
  const blob = dataURLtoBlob(fileData);
  const file = new File([blob], filename || (src.split('/').pop() || 'resume.pdf'), { type: blob.type || 'application/pdf' });

  for(const z of zones){
    try{
      z.classList.add('autofill-drop-indicator');
      const dt = new DataTransfer();
      dt.items.add(file);

      const enter = new DragEvent('dragenter',{bubbles:true,dataTransfer:dt});
      const over  = new DragEvent('dragover', {bubbles:true,dataTransfer:dt});
      const drop  = new DragEvent('drop',     {bubbles:true,dataTransfer:dt});
      z.dispatchEvent(enter); await delay(60);
      z.dispatchEvent(over);  await delay(60);
      z.dispatchEvent(drop);
      await delay(400);
      z.classList.remove('autofill-drop-indicator');
      return true;
    }catch(e){
      z.classList?.remove('autofill-drop-indicator');
    }
  }
  return false;
}
const RESUME_POS = [/\bresume\b/i, /\bcv\b/i, /\bcurriculum\s*vitae\b/i, /\brésumé\b/i];
const RESUME_NEG = [/\bcover\s*letter\b/i, /\btranscript\b/i, /\breferences?\b/i];
function isResumeHumanName(name=''){
  const t = String(name || '').trim();
  if (!t) return false;
  if (RESUME_NEG.some(r => r.test(t))) return false;
  return RESUME_POS.some(r => r.test(t));
}

/*************************************************
 * Wait for ATS parsers to finish — used only on SET1
 *************************************************/
async function waitForResumeParseToFinish({
  timeoutMs = 15000,
  quietMs   = 1200,
  pollMs    = 200
} = {}) {
  if (!IS_SET1) return { navigated:false }; // <-- gate: skip for set2/others

  const startKey = pageKey();

  const spinnerSel = [
    '.spinner', '.loading', '[aria-busy="true"]',
    '.wd-loading', '.icims-loading', '.ashby-loading',
    '.sr-loading', '.gh-loading', '[data-test="loading"]'
  ].join(',');

  const snapshotInputs = () => {
    const arr = [];
    document.querySelectorAll('input, textarea, select').forEach(el => {
      if (!el || !(el instanceof HTMLElement)) return;
      const type = (el.type || '').toLowerCase();
      if (type === 'password' || type === 'hidden') return;
      arr.push({ el, val: ('value' in el ? el.value : ''), disabled: !!el.disabled });
    });
    return arr;
  };
  const hasValuesChanged = (b, a) => {
    if (a.length !== b.length) return true;
    for (let i=0; i<b.length; i++){
      const x=b[i], y=a[i];
      if (x.el !== y.el) return true;
      if (x.val !== y.val) return true;
      if (x.disabled !== y.disabled) return true;
    }
    return false;
  };

  const before = snapshotInputs();
  let lastDomChange = performance.now();
  const mo = new MutationObserver(() => { lastDomChange = performance.now(); });
  try { mo.observe(document.documentElement, { childList:true, subtree:true, attributes:true, characterData:true }); } catch {}

  const hasSpinner = () => !!document.querySelector(spinnerSel);
  const urlChanged = () => pageKey() !== startKey;

  const t0 = performance.now();
  while (performance.now() - t0 < timeoutMs) {
    const after = snapshotInputs();
    const valueChurn = hasValuesChanged(before, after);

    if (urlChanged() || (valueChurn && !hasSpinner())) break;
    await delay(pollMs);
  }

  const quietStart = performance.now();
  while (performance.now() - quietStart < quietMs) {
    if (performance.now() - lastDomChange < quietMs/2) {
      await delay(pollMs);
      continue;
    }
    await delay(pollMs);
  }

  try { mo.disconnect(); } catch {}
  return { navigated: urlChanged() };
}
async function handleFileInput(input, fileUrl){
  const t = (input?.type || '').toLowerCase();
  if (t !== 'file' || input.disabled || input.readOnly) return false;
  console.log('1.handlefileinput func entered')
  // If a file already present, skip
  if (input.files && input.files.length > 0) {
    console.log('2. handlefileinput func file already present on this input — skipping upload');
    markAutofilled(input, 'resume');
    return true;
  }

  // --- SET1 (icims): full pending + wait + re-entry support ---
  if (IS_SET1) {
    try { await setPendingResumeUpload(fileUrl); } catch {}
    try {
      const ok = await simulateFileSelectionFromBackground(input, fileUrl);
      if (ok) {
        const res = await waitForResumeParseToFinish();
        markAutofilled(input, 'resume');
        // Log pending state safely (no storage.session direct from CS)
        try {
          const pending = await getPendingResumeUpload();
          console.log('[resume] pending (after native set):', pending);
          if (pending && !res?.navigated && pending.page === pageKey()) {
            await clearPendingResumeUpload();
          }
        } catch {}
        return true;
      }
    } catch (e) {
      console.log('[resume] native set failed, trying dropzone', e);
    }

    try {
      const ok2 = await tryAttachToDropzones(fileUrl);
      if (ok2) {
        const res = await waitForResumeParseToFinish();
        markAutofilled(input, 'resume');
        try {
          const pending = await getPendingResumeUpload();
          console.log('[resume] pending (after drop):', pending);
          if (pending && !res?.navigated && pending.page === pageKey()) {
            await clearPendingResumeUpload();
          }
        } catch {}
        return true;
      }
    } catch (e) {
      console.log('[resume] dropzone failed', e);
    }
    return false;
  }

  // --- SET2 (ashby/workday/greenhouse) & others: simple upload, no waits/flags ---
  try {
    const ok = await simulateFileSelectionFromBackground(input, fileUrl);
    if (ok) { markAutofilled(input, 'resume'); return true; }
  } catch (e) {
    console.log('[resume] simple upload failed, trying dropzone (set2/others)', e);
  try {
    const ok2 = await tryAttachToDropzones(fileUrl);
    if (ok2) { markAutofilled(input, 'resume'); return true; }
  } catch { console.log('[resume] trying dropzone  failed', e);}
  }
  return false;
}
async function newResumeFirstFromFinalGrouped(finalGrouped, autofillData = null, watchMs = 1000) {
  if (!Array.isArray(finalGrouped) || !finalGrouped.length) {
    return { ok: false, reason: 'no-inputs' };
  }

  console.log('1 resumefirst func parsing started');

  // 1) Collect candidate resume file <input type="file"> fields from finalGrouped
  const candidates = finalGrouped
    .filter(it => it && it.kind === 'nonGroup' && it.field && it.field.element)
    .map(it => it.field)
    .filter(f => {
      const el = f?.element;
      if (!el) return false;
      const t = (el.type || '').toLowerCase();
      if (t !== 'file') return false;
      if (!f.humanName) return false;
      return isResumeHumanName?.(f.humanName);
    });

  if (candidates.length === 0) return { ok: false, reason: 'no-resume-file-input' };

  // 2) Prefer resume source from field.value (new pipeline), fallback to autofillData["resume"]
  let resumeFile =
    candidates.find(f => f.value !== undefined && f.value !== null && f.value !== '')?.value ??
    autofillData?.['resume'];

  if (!resumeFile) {
    console.log('[resume] no resume file/url found on candidates[].value or autofillData["resume"]');
    return { ok: false, reason: 'no-resume-data' };
  }

  let anySuccess = false;

  for (const r of candidates) {
    const el = r.element;
    const label = String(r.humanName || '');

    // Skip ATS-wide "autofill" slots
    if (label.toLowerCase().includes('autofill')) {
      console.log('2.resumefirst func skipping autofill-slot:', label);
      continue;
    }

    // input already has a file (e.g., after refresh)
    if (el.files && el.files.length > 0) {
      console.log('3.resume first func input already has file, skipping:', label);
      markAutofilled?.(el, 'resume');
      anySuccess = true;
      continue;
    }

    console.log('4.resume first func uploading into:', label);
    try {
      const ok = await handleFileInput(el, resumeFile);
      if (ok) {
        anySuccess = true;
        markAutofilled?.(el, 'resume');

        // keep your special wait behavior (Set1 hosts)
        if (typeof IS_SET1 !== 'undefined' && IS_SET1) {
          await new Promise(res => setTimeout(res, Math.max(500, watchMs)));
        }
      }
    } catch (e) {
      console.log('[resume] file handle error', e);
    }
  }

  return anySuccess ? { ok: true } : { ok: false, reason: 'resume-upload-failed' };
}

async function resumeFirstFromInputs(inputs, autofillData, watchMs = 1000) {
  if (!Array.isArray(inputs) || !inputs.length) return { ok:false, reason:'no-inputs' };
  console.log('1 resumefirst func parsing started');

  const resumeFile = autofillData?.['resume'];
  if (!resumeFile) {
    console.log('[resume] no resume file/url on autofillData["resume"]');
    return { ok:false, reason:'no-resume-data' };
  }

  const candidates = inputs.filter(o => {
    const el = o?.element;
    if (!el) return false;
    const t = (el.type || '').toLowerCase();
    if (t !== 'file') return false;
    if (!o.humanName) return false;
    return isResumeHumanName(o.humanName);
  });

  if (candidates.length === 0) return { ok:false, reason:'no-resume-file-input' };

  let anySuccess = false;

  for (const r of candidates) {
    const el = r.element;
    const label = String(r.humanName || '');

    // Skip ATS-wide "autofill" slots
    if (label.toLowerCase().includes('autofill')) {
      console.log('2.resumefirst func skipping autofill-slot:', label);
      continue;
    }

    // input already has a file (e.g., after refresh)
    if (el.files && el.files.length > 0) {
      console.log('3.resume first func input already has file, skipping:', label);
      markAutofilled(el, 'resume');
      anySuccess = true;
      continue;
    }

    console.log('4.resume frist func uploading into:', label);
    try {
      const ok = await handleFileInput(el, resumeFile);
      if (ok) {
        anySuccess = true;
        if (IS_SET1) await new Promise(r => setTimeout(r, Math.max(500, watchMs)));
      }
    } catch (e) {
      console.log('[resume] file handle error', e);
    }
  }

  return anySuccess ? { ok:true } : { ok:false, reason:'resume-upload-failed' };
}
const isLeverHost = /(?:^|\.)lever\.co$/i.test(location.hostname);
function stripRequiredAsterisk(s){ return s.replace(/\s*[:*]\s*$/, ''); }
// kill live-status & helper text that leaks into container text on many hosts
const CONTAINER_NOISE_RE =
/\b(required|optional|characters?\s*remaining|drag\s*(?:and|&)\s*drop|click to upload|upload(?: a)? file|choose file|attach(?:ment)?|file size.*|max(?:imum)? size.*|no location found|try entering a different location|loading|analyzing resume|couldn'?t auto read resume|success|error|warning|info)\b.*$/i;

function dropContainerNoise(s){
  return (s || '')
    .replace(CONTAINER_NOISE_RE, '')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

// treat very machiney `name=` values as last resort
function looksMachineName(s){
  if(!s) return false;
  if(/cards?\[/.test(s)) return true;                          // Lever custom questions
  if(/[a-f0-9]{8}-[a-f0-9-]{13,}/i.test(s)) return true;       // UUID-ish
  if(/\b(field|input|question)\d+\b/i.test(s)) return true;
  // accept obvious good keys
  if (/\b(email|phone|name|first|last|company|location|address|city|state|zip|linkedin|github|portfolio|website)\b/i.test(s)) {
    return false;
  }
  return /^[a-z0-9_\[\]\-]+$/i.test(s);                        // no spaces ⇒ likely a key
}

// =====================
// Lever-specific: pull the visible question text
// =====================
const leverQuestionCache = new WeakMap();
function leverQuestionTextFor(field){
  if(!isLeverHost || !field) return '';
  const li = field.closest('li.application-question');
  if(!li) return '';
  if(leverQuestionCache.has(li)) return leverQuestionCache.get(li);

  const txtEl = li.querySelector('.application-label .text, .application-label');
  let txt = txtEl?.textContent || '';
  txt = stripRequiredAsterisk(txt).trim();

  // cache per <li> to avoid re-walking
  leverQuestionCache.set(li, txt);
  return txt;
}

// =====================
// Name extraction (UPDATED)
// =====================
/*
function inputFieldSelection(field){
  if(!field) return '';
  if(fieldNameCache.has(field)) return fieldNameCache.get(field);

  // local cleaner that also strips the field's own value/placeholder
  const clean = (s)=>{
    if(!s) return '';
    let t = (s || '').trim();
    if(field.value) t = t.replace(field.value, '').trim();
    if(field.placeholder) t = t.replace(field.placeholder, '').trim();
    t = stripRequiredAsterisk(t);
    t = dropContainerNoise(t);
    return normalizeFieldNameWithSpace(t);
  };

  const inFieldset = ()=>{
    const fs = field.closest('fieldset');
    if(!fs) return '';
    const legend = fs.querySelector('legend');
    if(legend?.textContent) return clean(legend.textContent);
    const lab = fs.querySelector(':scope > label');
    if(lab?.textContent) return clean(lab.textContent);
    return '';
  };

  const labelAssoc = ()=>{
    if (field.id){
      const lab = document.querySelector(`label[for="${CSS.escape(field.id)}"]`);
      if (lab?.textContent) return clean(lab.textContent);
    }
    let el = field;
    while(el && el!==document.body){
      if(el.tagName==='LABEL') return clean(el.textContent);
      if(el.parentNode?.tagName==='LABEL') return clean(el.parentNode.textContent);
      let prev = el.previousElementSibling;
      while(prev){
        if(prev.tagName==='LABEL') return clean(prev.textContent);
        prev = prev.previousElementSibling;
      }
      el = el.parentNode;
    }
    return '';
  };

  const ariaLabels = ()=>{
    if(field.hasAttribute('aria-label')) return clean(field.getAttribute('aria-label'));
    if(field.hasAttribute('aria-labelledby')){
      const ids = field.getAttribute('aria-labelledby').split(/\s+/);
      const txt = ids.map(id => document.getElementById(id)?.textContent || '').join(' ');
      if (txt.trim()) return clean(txt);
    }
    return '';
  };

  const inContainers = ()=>{
    // Prefer Lever's explicit question text when available
    if(isLeverHost){
      const q = leverQuestionTextFor(field);
      if(q) return clean(q);
    }
    let el = field;
    while(el && el!==document.body){
      const p = el.parentNode;
      if(p && ['DIV','SECTION','SPAN','TD','TH','LI','P'].includes(p.tagName)){
        const txt = dropContainerNoise((p.textContent||'').trim());
        if(txt) return clean(txt);
      }
      let prev = el.previousElementSibling;
      while(prev){
        if(['DIV','SECTION','SPAN','TD','TH','LI','P'].includes(prev.tagName)){
          const txt = dropContainerNoise((prev.textContent||'').trim());
          if(txt) return clean(txt);
        }
        prev = prev.previousElementSibling;
      }
      el = el.parentNode;
    }
    return '';
  };

  // ---------- resolution order ----------
  let name = '';

  // radios/checkboxes: fieldset or label are strongest
  const t = (field.type||'').toLowerCase();
  if (t === 'checkbox' || t === 'radio') {
    name = inFieldset() || labelAssoc() || inContainers();
  }

  if(!name && isLeverHost){
    // hard prefer the Lever question text early
    const leverQ = leverQuestionTextFor(field);
    if(leverQ) name = clean(leverQ);
  }

  if(!name) name = labelAssoc();
  if(!name) name = ariaLabels();

  // de-prioritize ugly machine names
  if(!name && field.name && !looksMachineName(field.name)) {
    name = clean(field.name);
  }

  if(!name && field.title) name = clean(field.title);
  if(!name) name = inFieldset() || inContainers();
  if(!name && field.placeholder) name = clean(field.placeholder);
  if(!name) name = nearestTextAround(field);

  // ---------- file input post-processing (uses your existing helpers/regexes) ----------
  if(isFileField(field)){
    const cleaned = stripFileCtas ? stripFileCtas(name) : name;
    if (FILE_POS_KW_RE?.test?.(cleaned)) {
      const finalName = normalizeFieldNameWithSpace(cleaned);
      fieldNameCache.set(field, finalName);
      return finalName;
    }
    if (!cleaned || FILE_NEG_KW_RE?.test?.(cleaned) || FILE_SIZE_HINT_RE?.test?.(cleaned)) {
      const hopName = findFileFieldName ? findFileFieldName(field, 6) : '';
      if (hopName) {
        fieldNameCache.set(field, hopName);
        return hopName;
      }
    }
    name = cleaned || name;
    console.log('1. inputfieldselection func humanname for file:',name);
  }

  const out = name || '';
  fieldNameCache.set(field, out);
  return out;
}
*/
function njoynOptionTextAfterInput(input) {
  const doc = input.ownerDocument || document;
  const parts = [];
  let node = input.nextSibling;

  while (node) {
    if (node.nodeType === Node.ELEMENT_NODE) {
      const tag = node.tagName;
      // stop at next input or line break
      if (tag === 'INPUT' || tag === 'BR') break;
      const txt = (node.textContent || '').replace(/\u00a0/g, ' ').trim();
      if (txt) parts.push(txt);
    } else if (node.nodeType === Node.TEXT_NODE) {
      const txt = (node.textContent || '').replace(/\u00a0/g, ' ').trim();
      if (txt) parts.push(txt);
    }
    node = node.nextSibling;
  }

  return parts.join(' ').trim();
}

 // Step-2, HumanName extraction

function inputFieldSelection(field){
  if (!field) return '';
  if (fieldNameCache.has(field)) return fieldNameCache.get(field);

  const doc = field.ownerDocument || document;
  const isWorkable = typeof isWorkableJobsHost !== 'undefined' && isWorkableJobsHost;
  const isSmartRecruiters = typeof isSmartRecruitersHost !== 'undefined' && isSmartRecruitersHost;

  const clean = (s) => {
    if (!s) return '';
    let t = (s || '').trim();
    if (field.value) t = t.replace(field.value, '').trim();
    //if (field.placeholder) t = t.replace(field.placeholder, '').trim();
    //Chaning the syntax to make it convinient for power host domain
    const ph = (field.placeholder || '').trim();
    if (ph && (!isPowerHost || (s || '').trim() !== ph)) {
      t = t.replace(field.placeholder, '').trim();
    }
    t = stripRequiredAsterisk(t);
    t = dropContainerNoise(t);
    return normalizeFieldNameWithSpace(t);
  };

  const inFieldset = () => {
    const fs = field.closest('fieldset');
    if (!fs) return '';
    const legend = fs.querySelector('legend');
    if (legend?.textContent) return clean(legend.textContent);
    const lab = fs.querySelector(':scope > label');
    if (lab?.textContent) return clean(lab.textContent);
    return '';
  };

  const labelAssoc = () => {
    if (field.id) {
      const lab = doc.querySelector(`label[for="${CSS.escape(field.id)}"]`);
      if (lab?.textContent) return clean(lab.textContent);
    }
    let el = field;
    while (el && el !== doc.body) {
      if (el.tagName === 'LABEL') return clean(el.textContent);
      if (el.parentNode?.tagName === 'LABEL') return clean(el.parentNode.textContent);
      let prev = el.previousElementSibling;
      while (prev) {
        if (prev.tagName === 'LABEL') return clean(prev.textContent);
        prev = prev.previousElementSibling;
      }
      el = el.parentNode;
    }
    return '';
  };

  const ariaLabels = () => {
    if (field.hasAttribute('aria-label')) return clean(field.getAttribute('aria-label'));
    if (field.hasAttribute('aria-labelledby')) {
      const ids = field.getAttribute('aria-labelledby').split(/\s+/);
      const txt = ids
        .map(id => doc.getElementById(id)?.textContent || '')
        .join(' ');
      if (txt.trim()) return clean(txt);
    }
    return '';
  };

  const inContainers = () => {
    if (isLeverHost) {
      const q = leverQuestionTextFor(field);
      if (q) return clean(q);
    }
    let el = field;
    while (el && el !== doc.body) {
      const p = el.parentNode;
      if (p && ['DIV','SECTION','SPAN','TD','TH','LI','P'].includes(p.tagName)) {
        const txt = dropContainerNoise((p.textContent || '').trim());
        if (txt) return clean(txt);
      }
      let prev = el.previousElementSibling;
      while (prev) {
        if (['DIV','SECTION','SPAN','TD','TH','LI','P'].includes(prev.tagName)) {
          const txt = dropContainerNoise((prev.textContent || '').trim());
          if (txt) return clean(txt);
        }
        prev = prev.previousElementSibling;
      }
      el = el.parentNode;
    }
    return '';
  };

  // iCIMS <select> helper (Q6/Q9…)
  const icimsSelectQuestionText = () => {
    if (!(typeof isIcimsHost !== 'undefined' && isIcimsHost)) return '';
    if (field.tagName !== 'SELECT') return '';
    const id = field.id;
    if (!id) return '';

    const qRoot = doc.querySelector(`#${CSS.escape(id)}_questionText`);
    if (!qRoot) return '';
    const labelEl =
      qRoot.querySelector('label') ||
      qRoot.querySelector('.iCIMS_LabelText') ||
      qRoot;
    const txt = labelEl?.textContent || '';
    return clean(txt);
  };

  // ===== Workable: radio / checkbox question text =====
  const workableQuestionTextFor = () => {
    if (!isWorkable) return '';
    const fs = field.closest('fieldset[role="radiogroup"], fieldset');
    if (!fs) return '';

    let txt = '';
    const ariaId = fs.getAttribute('aria-labelledby');
    if (ariaId) {
      const labelEl = doc.getElementById(ariaId);
      if (labelEl) txt = labelEl.textContent || '';
    }

    // Fallback: look in parent container for label-ish text
    if (!txt) {
      const container = fs.parentElement;
      if (container) {
        const labelLike =
          container.querySelector('[data-ui="label"]') ||
          container.querySelector('[id$="_label"]') ||
          container.querySelector('[class*="label"]');
        if (labelLike) txt = labelLike.textContent || '';
      }
    }

    return clean(txt);
  };

  // ===== SmartRecruiters: checkbox label text =====
  const smartRecruitersCheckboxLabelFor = () => {
    if (!isSmartRecruiters) return '';

    // Field is inside a shadow root; climb to the host (oc-checkbox / spl-checkbox)
    let host = null;
    const rootNode = field.getRootNode && field.getRootNode();
    if (rootNode && rootNode.host) host = rootNode.host;

    let scope =
      (host && host.closest && host.closest('label')) ||
      host ||
      (field.closest && field.closest('label')) ||
      (field.closest && field.closest('[data-test*="checkbox"]'));

    if (!scope) scope = doc;

    let labelSpan =
      scope.querySelector('[data-test="checkbox-label"]') ||
      scope.querySelector('[slot="label-content"]') ||
      scope.querySelector('[data-test="label"]');

    let txt = labelSpan?.textContent || '';

    if (!txt && field.hasAttribute('aria-labelledby')) {
      const ariaId = field.getAttribute('aria-labelledby');
      const el = ariaId ? doc.getElementById(ariaId) : null;
      if (el) txt = el.textContent || '';
    }

    return clean(txt);
  };

  // ---------- resolution order ----------
  let name = '';
  const t = (field.type || '').toLowerCase();
  const tag = field.tagName;

  // --- HOST-SPECIFIC FIRST ---

  // Workable radios/checkboxes → use radiogroup question text
  if (!name && isWorkable && (t === 'checkbox' || t === 'radio')) {
    name = workableQuestionTextFor();
  }

  // SmartRecruiters checkboxes → use checkbox label slot/content
  if (!name && isSmartRecruiters && t === 'checkbox') {
    name = smartRecruitersCheckboxLabelFor();
  }

  // Generic radios/checkboxes (fieldset/label/container)
  if (!name && (t === 'checkbox' || t === 'radio')) {
    name = inFieldset() || labelAssoc() || inContainers();
  }

  // Lever hard preference
  if (!name && isLeverHost) {
    const leverQ = leverQuestionTextFor(field);
    if (leverQ) name = clean(leverQ);
  }

  // iCIMS <select> BEFORE generic label/aria
  if (!name &&
      typeof isIcimsHost !== 'undefined' &&
      isIcimsHost &&
      tag === 'SELECT') {
    name = icimsSelectQuestionText();
  }
    //POwerhost is mostly using placeholders except checkbox,files
  if(isPowerHost && field.placeholder){
    name = clean(field.placeholder);
  }
  if (!name) name = labelAssoc();
  if (!name) name = ariaLabels();

  // de-prioritize ugly machine names
  if (!name && field.name && !looksMachineName(field.name)) {
    name = clean(field.name);
  }

  if (!name && field.title) name = clean(field.title);
  if (!name) name = inFieldset() || inContainers();
  if (!name && field.placeholder) name = clean(field.placeholder);
  if (!name) name = nearestTextAround(field);  // if this uses document, you may also adapt it to use `doc`.

  // ---------- file input post-processing ----------
  if (isFileField(field)) {
    const cleaned = stripFileCtas ? stripFileCtas(name) : name;
    if (FILE_POS_KW_RE?.test?.(cleaned)) {
      const finalName = normalizeFieldNameWithSpace(cleaned);
      fieldNameCache.set(field, finalName);
      return finalName;
    }
    if (!cleaned || FILE_NEG_KW_RE?.test?.(cleaned) || FILE_SIZE_HINT_RE?.test?.(cleaned)) {
      const hopName = findFileFieldName ? findFileFieldName(field, 6) : '';
      if (hopName) {
        fieldNameCache.set(field, hopName);
        return hopName;
      }
    }
    name = cleaned || name;
    console.log('1. inputfieldselection func humanname for file:', name);
  }

  const out = name || '';
  fieldNameCache.set(field, out);
  return out;
}


//===ashby helpers

function isAshbyButtonEntry(obj){
  return !!(obj && obj.ashbyLinked && obj.optionText && obj.element?.tagName === 'BUTTON');
}

// --- helpers (Ashby only) ---
function ashbyQuestionTextFor(node){
  if (!isAshbyHost || !node) return '';
  const entry = node.closest('[class*="application-form-field-entry"]') || node.closest('div');
  const lab = entry?.querySelector('label[class*="application-form-question-title"], label[for]');
  return (lab?.textContent || '').replace(/\s*[:*]\s*$/, '').trim();
}

function ashbyFindYesNoButtonsNear(input){
  if (!isAshbyHost || !input) return [];
  const entry = input.closest('[class*="application-form-field-entry"]') || input.closest('div');
  if (!entry) return [];
  // Ashby wraps the two buttons in a container with "yesno" in the class
  const yesNo = entry.querySelector('div[class*="yesno"]');
  if (!yesNo) return [];
  const btns = [...yesNo.querySelectorAll('button')].filter(b => b && b.offsetParent !== null);
  // keep only obvious yes/no
  return btns
    .map(b => ({ el: b, text: (b.textContent || '').trim().toLowerCase() }))
    .filter(b => b.text === 'yes' || b.text === 'no');
}


//STEP1: Inputs extraction

// Robust visibility check: element must be rendered and not in a hidden ancestor
function isEffectivelyVisible(el) {
  if (!el || !el.ownerDocument) return false;

  const doc = el.ownerDocument;
  const view = doc.defaultView || window;

  let node = el;
  while (node && node.nodeType === 1) {
    // Guard: if getComputedStyle blows up, treat as not visible
    let style;
    try {
      style = view.getComputedStyle(node);
    } catch (e) {
      return false;
    }

    if (!style) return false;

    // CSS hidden
    if (style.display === 'none' || style.visibility === 'hidden' ) { //|| style.opacity === '0'
      return false;
    }

    // Attribute / ARIA hidden
    if (
      node.hasAttribute('hidden') ||
      node.getAttribute('aria-hidden') === 'true' ||
      node.hasAttribute('inert')
    ) {
      return false;
    }

    node = node.parentElement;
  }

  // Geometry visibility (non-zero box)
  try {
    const rect = el.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return false;
  } catch (e) {
    // If we can't compute rect, assume not visible
    return false;
  }

  return true;
}

// Check if element lives in a cookie/consent / OneTrust overlay
function isCookieOrConsentControl(el) {
  const id = (el.id || '').toLowerCase();
  const cls = (el.className || '').toString().toLowerCase();
  const name = (el.name || '').toLowerCase();

  // Common OneTrust / consent containers
  const inCookieContainer = !!el.closest(
    '#onetrust-banner-sdk, #onetrust-pc-sdk, #onetrust-consent-sdk, ' +
    '.ot-sdk-container, .ot-sdk-row, .onetrust-pc-dark-filter, ' +
    '[data-testid*="cookie"], [aria-label*="cookie"], [aria-label*="Cookie"]'
  );

  if (inCookieContainer) return true;

  // Heuristic: cookie/consent/tracking in id/class/name
  const blob = `${id} ${cls} ${name}`;
  if (/\bcookie\b|\bconsent\b|\btracking\b|\bprivacy\b/.test(blob)) {
    return true;
  }

  return false;
}

// Skip obvious non-form regions: navigation, header, footer, toolbars, menus
function isInNonFormChrome(el) {
  if (
    el.closest(
      'header, footer, nav, [role="banner"], [role="navigation"], ' +
      '[role="menubar"], [role="toolbar"], [data-testid*="toolbar"], ' +
      '[class*="toolbar"], [class*="nav"], [class*="navbar"]'
    )
  ) {
    return true;
  }
  return false;
}

// Additional "junk" patterns (site keepalive, recaptcha, etc.)
function isJunkInput(el) {
  const id = (el.id || '').toLowerCase();
  const cls = (el.className || '').toString().toLowerCase();

  // iCIMS / others: keep-alive, nav triggers, captcha
  if (
    id === 'keepmealivebutton' ||
    id === 'nav-trigger' ||
    cls.includes('recaptcha') ||
    id.startsWith('h-captcha-response') ||
    id.startsWith('g-recaptcha-response')
  ) {
    return true;
  }

  // OneTrust cookie toggles (shown in your sample)
  if (
    id.startsWith('ot-group-id-') ||
    cls.includes('category-switch-handler') ||
    id === 'chkbox-id' ||
    id.startsWith('select-all-')
  ) {
    if (el.closest('#onetrust-banner-sdk, #onetrust-pc-sdk, #onetrust-consent-sdk')) {
      return true;
    }
  }

  return false;
}

// Detect "Upload resume/CV" style button that is clearly a file trigger.
function isFileTriggerButton(btn) {
  if (!btn || btn.tagName !== 'BUTTON') return false;
  const text = (btn.textContent || '').toLowerCase().trim();

  if (!text) return false;
  // ✅ CHANGE: simpler regex, matches "select files", "select file", etc.
  if (!/upload|attach|choose file|select file|select files|browse|resume|cv/.test(text)) {
    return false;
  }
  // Look nearby for an <input type="file">
  const container = btn.closest('form, [role="form"], div, section') || btn.parentElement;
  if (!container) return false;

  const fileInput = container.querySelector('input[type="file"]');
  if (!fileInput) return false;

  return true;
}

// Toolbar-ish detection (refined)
function isToolbarish(el) {
  return !!el.closest(
    '[role="toolbar"], [role="menu"], header, ' +
    '[data-testid*="toolbar"], [class*="toolbar"], [class*="editor"], ' +
    '[contenteditable="true"][data-slate-editor="true"]'
  );
}

// =============================
//  ROOT COLLECTION (DOC + SHADOW + IFRAMES)
// =============================

function allShadowHosts(root = document) {
  return [...root.querySelectorAll('*')].filter(el => el.shadowRoot);
}

function collectAllRoots() {
  const roots = [document];
  const stack = [...allShadowHosts(document)];

  // Include all same-origin iframes; visibility will be decided per-input.
  document.querySelectorAll('iframe').forEach(fr => {
    try {
      if (fr.contentDocument) {
        roots.push(fr.contentDocument);
        stack.push(...allShadowHosts(fr.contentDocument));
      }
    } catch (e) {
      // cross-origin, ignore
    }
  });

  while (stack.length) {
    const host = stack.pop();
    if (host.shadowRoot) {
      roots.push(host.shadowRoot);
      stack.push(...allShadowHosts(host.shadowRoot));
    }
  }
  return roots;
}

// =============================
//  MAIN INPUT COLLECTION
// =============================
const isNjoynHost = /(^|\.)njoyn\.com$/i.test(location.hostname);
// ClearCompany ATS (e.g. addus.clearcompany.com)
const isClearCompanyHost = /(^|\.)clearcompany\.com$/i.test(location.hostname);


// NOTE: groupCache should be defined somewhere globally if not already
//const groupCache = new WeakMap();
function collectInputsIn(root) {
  let sel = `
    input:not([disabled]):not([readonly]):not([type="hidden"]),
    select:not([disabled]):not([readonly]),
    textarea:not([disabled]):not([readonly]),
    [contenteditable="true"]:not([aria-disabled="true"]),
    [role="textbox"]:not([aria-disabled="true"]),
    [role="combobox"]:not([aria-disabled="true"]),
    button[aria-haspopup="listbox"]:not([disabled]),         
    [role="button"][aria-haspopup="listbox"]:not([aria-disabled="true"])
  `;
  // 🟦 SUCCESSFACTORS EXTENSIONS
  if (isSuccessHost) {
    sel += `,
      [role="button"]:not([aria-disabled="true"]),   /* captures custom clickable DIV/SPAN buttons */
      a[role="button"]:not([aria-disabled="true"]),  /* if they use <a role="button"> */
      a[href^="javascript:void"]                     /* captures the resume upload A tag */
    `;
  }
  const nodes = [...root.querySelectorAll(sel)];
  //console.log('Total Inputs collected before filtering',nodes.slice(0,30));
  const results = [];
  let groupCounter = 0;

  for (const input of nodes){
    const tag = input.tagName;
    const type = (input.type || '').toLowerCase();
    const doc = input.ownerDocument || document;
    if (isToolbarish(input)) continue;
    // Visibility exception for workday file inputs and Meta domain
    if ((!isJobCaseHost) && (!isMetaHost) && (!isWorkableJobsHost) && !(isWorkdayHost() && input.type === 'file')) {
      if (!(isApexApplyHost && isFileField(input))) {
        if (!isEffectivelyVisible(input)) continue;
      }
    }
    if (isCookieOrConsentControl(input)) continue;
    if (isInNonFormChrome(input)) continue;
    if (isJunkInput(input)) continue;
    // ----- TAG / TYPE filtering -----
    // We need to know ahead of time if this is a select-like trigger / file trigger
    let isSelectTriggerButton = false;  // ✅ CHANGE
    let isFileTrigger = false;          // ✅ CHANGE
    if (tag === 'BUTTON') {
      const role = input.getAttribute('role');
      const hasPopup = (input.getAttribute('aria-haspopup') || '').toLowerCase();
      // Treat Workday-style country dropdowns as select-like:
      //  <button aria-haspopup="listbox" ...>Selected text</button>
      const looksLikeSelect =
        role === 'combobox' ||
        hasPopup === 'listbox' ||
        hasPopup === 'dialog' ||
        // Workday often uses data-automation-id for select controls
        (input.getAttribute('data-automation-id') || '').toLowerCase().includes('select');
      if (isFileTriggerButton(input)) {
        // upload / select files button
        isFileTrigger = true;
      } else if (looksLikeSelect) {
        // keep this as a select-like trigger
        isSelectTriggerButton = true;
      } else {
        // all other buttons are not data fields
        continue;
      }
    }

    if (tag === 'INPUT') {
      if (['button', 'submit', 'reset', 'image'].includes(type)) {
        // Submit/etc aren’t data fields; upload handled above
        continue;
      }
    }

    const style = input.ownerDocument.defaultView.getComputedStyle(input);
    const inFloatingPanel =
      !!input.closest('[role="listbox"], [role="dialog"], [role="menu"]') &&
      (style.position === 'fixed' || style.position === 'absolute');

    if (inFloatingPanel && tag === 'INPUT' && type === 'text' && !isFileTrigger) {
      // skip overlay search boxes, but don't skip file trigger buttons
      continue;
    }

    // ---- iCIMS specific handling ----
    if (typeof isIcimsHost !== 'undefined' && isIcimsHost) {
      if (input.closest('[role="listbox"], [role="dialog"], [role="menu"]')) {
        if (
          tag === 'INPUT' &&
          (type === 'text' || input.classList.contains('dropdown-search'))
        ) {
          continue;
        }
      }

      if (
        input.matches(
          '#nav-trigger, ' +
          'textarea[id^="h-captcha-response"], ' +
          'textarea.g-recaptcha-response'
        )
      ) {
        continue;
      }
    }
    // GROUPING / HUMAN NAME LOGIC
    let groupId = null;
    let humanName = null;
    // Container-based fallback if we STILL don't have a key
    let container =input.closest('fieldset, section, div, form, ul, ol, table, tbody, tr') || root;
    if (type === 'checkbox' || type === 'radio') {
      // This becomes `humanName` for choice inputs.
      let optionLabel = '';

      // 1) normal associated <label for="...">
      if (typeof findAssociatedLabel === 'function') {
        optionLabel = findAssociatedLabel(input) || '';
      }

      // 2) fallback: aria-label / aria-labelledby for the option itself
      if (!optionLabel && input.hasAttribute('aria-label')) {
        optionLabel = input.getAttribute('aria-label') || '';
      }

      if (!optionLabel && input.hasAttribute('aria-labelledby')) {
        const ids = input.getAttribute('aria-labelledby').split(/\s+/).filter(Boolean);
        const txt = ids
          .map(id => doc.getElementById(id)?.textContent || '')
          .join(' ')
          .trim();
        if (txt) optionLabel = txt;
      }
      // 🔹 NJOYN SPECIAL CASE:
      // radios are like:
      //   <input value="1"> Yes, I have a disability...
      //   <input value="2"> No, I do not...
      //   <input value="3"> I do not want to answer
      if (isNjoynHost) {
        const after = njoynOptionTextAfterInput(input);
        if (after) {
          optionLabel = after; // prefer visible text over "1/2/3"
        }
      }
        // 🔹 CLEARCOMPANY: option label is inside <label> ... <span>Yes/No</span>
      if (isClearCompanyHost) {
        const optLabelEl = input.closest('label');
        if (optLabelEl) {
          const span = optLabelEl.querySelector('span');
          const txt = (span?.textContent || optLabelEl.textContent || '').trim();
          if (txt) {
            optionLabel = txt; // "Yes" / "No"
          }
        }
      }

      // 3) fallback: use raw value
      if (!optionLabel && input.value) {
        optionLabel = input.value;
      }

      humanName = normalizeFieldNameWithSpace(optionLabel || '');
            // ---------- QUESTION TEXT (shared groupId) ----------
      let questionText = '';

      // A. host-specific: Ashby – we already have a helper
      //if (isAshbyHost && typeof ashbyQuestionTextFor === 'function') {
        //questionText = ashbyQuestionTextFor(input) || '';
      //}

      // B. host-specific: Meta careers (multi-location etc)
      if (!questionText && isMetaHost) {
        // listitem -> list -> blockRoot
        const listItem = input.closest('[role="listitem"]');
        const list = listItem ? listItem.parentElement : input.closest('[role="list"]');
        const blockRoot = list?.parentElement || list || container;

        if (blockRoot) {
          container = blockRoot;
          let labelText = '';
          let scanNode = blockRoot;
          let hops = 0;

          while (scanNode && hops < 3 && !labelText) {
            let prev = scanNode.previousElementSibling;
            while (prev && !labelText) {
              const t = (prev.textContent || '').trim();
              if (t) {
                labelText = t;
                break;
              }
              prev = prev.previousElementSibling;
            }
            scanNode = scanNode.parentElement;
            hops++;
          }

          if (labelText) {
            questionText = labelText;
          }
        }
      }
      // 🔹 C. host-specific: njoyn (clients.njoyn.com etc.)
      if (!questionText && (isNjoynHost || isSuccessHost)) {
        // Radios live inside a <td> that also contains an <h3> question
        let cell = input.closest('td,th');
        if (!cell && container) {
          cell = container.closest?.('td,th') || null;
        }
        if (cell && isSuccessHost) {
          let label = null;
          // If we’re in a table row, the question is usually in the TH before this TD
          const headerCell = cell.previousElementSibling;
          if (headerCell && headerCell.matches('th')) {
            label = headerCell.querySelector('label') || headerCell;
          }

          // Fallbacks: label[for="id"] or old behavior
          if (!label && input.id) {
            label = input.ownerDocument.querySelector(`label[for="${CSS.escape(input.id)}"]`);
          }
          if (!label) {
            label = cell.closest('div');
          }

          if (label && label.textContent) {
            questionText = label.textContent.trim();   // → "Gender"
          }
        }
        if (cell) {
          // prefer heading inside this cell
          let heading =
            cell.querySelector('h1,h2,h3,h4,h5,h6');

          // if none, try earlier sibling cells in the same row
          if (!heading) {
            let prevCell = cell.previousElementSibling;
            while (prevCell && !heading) {
              heading = prevCell.querySelector('h1,h2,h3,h4,h5,h6');
              if (heading) break;
              prevCell = prevCell.previousElementSibling;
            }
          }
          if (heading && heading.textContent.trim()) {
            questionText = heading.textContent.trim();
          }
        }
      }
      // 🔹 CLEARCOMPANY: question text in <label class="radio-label ...">
      if (!questionText && isClearCompanyHost) {
        // climb to the form-group that wraps the question + radios
        let group = input.closest('.form-group.radio-group') ||
                    container.closest?.('.form-group.radio-group');

        if (group) {
          const qLabel =
            group.querySelector('label.radio-label') ||
            group.querySelector('label');

          if (qLabel && qLabel.textContent.trim()) {
            questionText = qLabel.textContent.trim();
          }
        }
      }
      // 🔹 POWERHRG: question is usually in a label above the radio button group
      if (!questionText && isPowerHost) {
        const group =
          input.closest('.form-group, .radio-group, .pjl-field, .pjl-row') || container;

        // Prefer a label that is NOT the option button label and NOT an error label
        const qLabel = group.querySelector('label:not(.btn):not(.error)');
        const txt = (qLabel?.textContent || '').trim();
        if (txt) questionText = txt;
      }


      if (!questionText){
         questionText = inputFieldSelection(input) || input.name || '';

      }
      const normQuestion = questionText
        ? normalizeFieldNameWithSpace(questionText)
        : '';

      if (normQuestion) {
        groupId = normQuestion;
        if (!container._humanName) {
          // store question text on container for debugging / other logic
          container._humanName = normQuestion;
        }
      } else {
        // If we truly couldn't find a readable question, fall back
        // to a stable but opaque key (keeps groups working).
        let key = '';
        if (input.name) key = `name:${input.name}`;
        if (!key && input.getAttribute('aria-labelledby')) {
          key = `aria:${input.getAttribute('aria-labelledby')}`;
        }
        if (!key) {
          if (!groupCache.has(container)) {
            groupCache.set(container, `group-${groupCounter++}`);
          }
          key = groupCache.get(container);
        }
        groupId = key;
      }

      // ---------- Ashby Yes/No buttons (unchanged) ----------
      if (typeof isAshbyHost !== 'undefined' && isAshbyHost && type === 'checkbox') {
        const yesNoBtns = ashbyFindYesNoButtonsNear(input);
        if (yesNoBtns && yesNoBtns.length) {
          const q = ashbyQuestionTextFor(input);
          const qNorm = q ? normalizeFieldNameWithSpace(q) : groupId;

          for (const b of yesNoBtns) {
            results.push({
              element: b.el,
              elementType: type,
              groupId: qNorm,
              humanName: normalizeFieldNameWithSpace(b.text),
              ashbyLinked: true,
              optionText: b.text,
            });
          }
        }
      }
    } else {
      // === non-choice fields (text, select, date, etc.) ===
      humanName =
        inputFieldSelection(input) ||
        input.name ||
        input.getAttribute?.('aria-label') ||
        '';
    }

    const obj = {
      element: input,
      elementType: type,
      groupId,
      humanName,
    };

    // Tag special button types for filler
    if (isFileTrigger) {
      obj.isFileTriggerButton = true;
    }
    if (isSelectTriggerButton || input.matches('[aria-haspopup="listbox"]')) {
      obj.isSelectLikeTrigger = true;
    }

    if (
      typeof isWorkdayHost === 'function' &&
      isWorkdayHost() &&
      typeof refineDateHumanNameAndGroup === 'function'
    ) {
      refineDateHumanNameAndGroup(obj);
    }

    results.push(obj);
  }

  // Keep group ordering stable: inputs first, then any buttons we added
  results.sort((a, b) => {
    if (a.groupId && a.groupId === b.groupId) {
      const aIsBtn = a.element?.tagName === 'BUTTON';
      const bIsBtn = b.element?.tagName === 'BUTTON';
      if (aIsBtn !== bIsBtn) return aIsBtn ? 1 : -1;
    }
    return 0;
  });

  return results;
}

function normalizeName(str) {
  return (str || '').toLowerCase().trim();
}
/**
 * Takes the flat fields array from inputSelection() and groups only
 * consecutive radio/checkbox fields that share the same groupId.
 *
 * Output groups are shaped for your model:
 *  - kind: "group"
 *  - question: groupId
 *  - options: [{ label, elementType, element }]
 */

// Step-4: Grouping 
/*
export function groupConsecutiveByGroupId(fields) {
  const grouped = [];
  let i = 0;

  const isChoice = (f) => f && (f.elementType === 'radio' || f.elementType === 'checkbox') && !!f.groupId;

  while (i < fields.length) {
    const f = fields[i];

    // Non-choice fields pass through as-is
    if (!isChoice(f)) {
      grouped.push({ kind: "nonGroup", field: f });
      i++;
      continue;
    }

    // Start a new group for this groupId (consecutive only)
    const gid = f.groupId;
    const options = [];
    let j = i;

    while (j < fields.length && isChoice(fields[j]) && fields[j].groupId === gid) {
      const opt = fields[j];
      options.push({
        label: (opt.humanName || '').trim(),
        elementType: opt.elementType, // radio|checkbox
        element: opt.element
      });
      j++;
    }

    // If a "group" accidentally has just 1 option, treat it like normal field
    if (options.length <= 1) {
      grouped.push({ kind: "nonGroup", field: f });
    } else {
      grouped.push({
        kind: "group",
        question: gid,
        elementType: options[0].elementType, // usually consistent
        options
      });
    }

    i = j;
  }

  return grouped;
} */
export function groupConsecutiveByGroupId(fields) {
  const grouped = [];
  let i = 0;

  // single global counter
  let inputCounter = 0;

  const isChoice = (f) =>
    f && (f.elementType === 'radio' || f.elementType === 'checkbox') && !!f.groupId;

  const nextId = () => ++inputCounter;

  while (i < fields.length) {
    const f = fields[i];

    // -----------------------------
    // Non-choice field
    // -----------------------------
    if (!isChoice(f)) {
      grouped.push({
        kind: "nonGroup",
        field: {
          ...f,
          input_number: nextId(),
        },
      });
      i++;
      continue;
    }

    // -----------------------------
    // Choice group (radio / checkbox)
    // -----------------------------
    const gid = f.groupId;
    const options = [];
    let j = i;

    while (j < fields.length && isChoice(fields[j]) && fields[j].groupId === gid) {
      const opt = fields[j];
      options.push({
        label: (opt.humanName || '').trim(),
        elementType: opt.elementType, // radio | checkbox
        element: opt.element,
      });
      j++;
    }

    // If only one option, treat as nonGroup
    if (options.length <= 1) {
      grouped.push({
        kind: "nonGroup",
        field: {
          ...f,
          input_number: nextId(),
        },
      });
    } else {
      grouped.push({
        kind: "group",
        question: gid,
        elementType: options[0].elementType,
        options,
        input_number: nextId(), // ✅ only here
      });
    }

    i = j;
  }

  return grouped;
}

const normQ = (s) =>
  (s || '')
    .toLowerCase()
    .replace(/[\u2019']/g, "'")
    .replace(/[^a-z0-9\s?]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

function parseModelAnswer(answer) {
  // model gives answer like '["full_time"]' or '"yes"' or '[]' or null
  if (answer == null) return null;

  if (typeof answer !== 'string') {
    // already structured
    if (Array.isArray(answer)) return answer;
    return String(answer);
  }

  const s = answer.trim();

  // try JSON parse (handles '["x"]', '"x"', 'null', '[]')
  try {
    const v = JSON.parse(s);
    return v;
  } catch {
    // fallback: raw string
    return s;
  }
}

function toStringArray(v) {
  if (v == null) return [];
  if (Array.isArray(v)) return v.map(x => String(x));
  if (typeof v === 'string') return [v];
  return [String(v)];
}
function buildAnswerMap(modelOutputArray) {
  const map = new Map(); // normQuestion -> parsedAnswer
  for (const row of (modelOutputArray || [])) {
    const q = normQ(row?.question);
    if (!q) continue;
    map.set(q, parseModelAnswer(row?.answer));
  }
  return map;
}

//Step-7: Attaching gemma Model values to grouped inputs
export function attachModelValuesToGrouped(grouped, modelOutputArray) {
  // modelOutputArray should contain either:
  //  - { input_number: 12, answer: "..." } or
  //  - { input_number: 12, value: "..." }  (we support both)
  //  - for groups: answer/value can be string or array of strings

  const byId = buildAnswerMapByInputNumber(modelOutputArray);

  return grouped.map(item => {
    // -------- nonGroup (text/date/etc) --------
    if (item.kind === 'nonGroup') {
      const id = item.field?.input_number;
      if (id == null) return item;

      const ans = byId.get(String(id));
      const asArr = toStringArray(ans).map(x => x.trim()).filter(Boolean);

      const noValue =
        ans == null ||
        asArr.length === 0 ||
        asArr.some(x => /^(i don'?t know|i do not know|null|unknown|n\/a)$/i.test(x));

      const alreadyHasValue =
        item.field?.value != null && String(item.field.value).trim() !== "";

      // ✅ only set if model has a value AND current value is empty
      if (!noValue && !alreadyHasValue) {
        item.field.value = asArr[0];
      }

      return item;
    }

    // -------- group (checkbox/radio/select options) --------
    if (item.kind === 'group') {
      const id = item.input_number; // <-- group-level id (as you requested)
      if (id == null) return item;

      const ans = byId.get(String(id));
      const chosen = toStringArray(ans).map(normQ).filter(Boolean);

      if (chosen.length === 0) return item; // preserve existing item.value

      const optByNorm = new Map((item.options || []).map(o => [normQ(o.label), o]));

      const matched = [];
      for (const sel of chosen) {
        let hit = optByNorm.get(sel);
        if (!hit) {
          hit = (item.options || []).find(o => {
            const on = normQ(o.label);
            return on.includes(sel) || sel.includes(on);
          });
        }
        if (hit && !matched.includes(hit)) matched.push(hit);
      }

      // ✅ only set if we actually matched something
      if (matched.length > 0) {
        const alreadyHasValue = Array.isArray(item.value) && item.value.length > 0;
        if (!alreadyHasValue) {
          item.value = matched; // keeps your "option objects" format
        }
      }

      return item;
    }

    return item;
  });
}

/** Map input_number -> answer/value */
function buildAnswerMapByInputNumber(modelOutputArray) {
  const m = new Map();

  for (const row of (modelOutputArray || [])) {
    if (!row) continue;

    // tolerate a few shapes:
    const id =
      row.input_number ??
      row.inputNumber ??
      row.id ??
      row.input_id ??
      row.inputId;

    if (id == null) continue;

    const val =
      row.answer ??
      row.value ??
      row.output ??
      row.prediction ??
      row.suggested_answer;

    // store even if val is null; caller handles noValue
    m.set(String(id), val);
  }

  return m;
}

/*
export function attachModelValuesToGrouped(grouped, modelOutputArray) {
  const answers = buildAnswerMap(modelOutputArray);

  return grouped.map(item => {
    // -------- nonGroup (text/date/etc) --------
    if (item.kind === 'nonGroup') {
      const q = normQ(item.field?.humanName);
      const ans = answers.get(q);

      const asArr = toStringArray(ans).map(x => x.trim()).filter(Boolean);
      const noValue =
        ans == null ||
        asArr.length === 0 ||
        asArr.some(x => /^(i don'?t know|i do not know|null|unknown|n\/a)$/i.test(x));

      // ✅ only set if model has a value AND current value is empty
      const alreadyHasValue = item.field?.value != null && String(item.field.value).trim() !== "";
      if (!noValue && !alreadyHasValue) {
        item.field.value = asArr[0];
      }

      return item;
    }

    // -------- group (checkbox/radio/select options) --------
    if (item.kind === 'group') {
      const q = normQ(item.question);
      const ans = answers.get(q);

      const chosen = toStringArray(ans).map(normQ).filter(Boolean);
      if (chosen.length === 0) {
        // ✅ do nothing -> preserves existing item.value
        return item;
      }

      const optByNorm = new Map((item.options || []).map(o => [normQ(o.label), o]));

      const matched = [];
      for (const sel of chosen) {
        let hit = optByNorm.get(sel);
        if (!hit) {
          hit = (item.options || []).find(o => {
            const on = normQ(o.label);
            return on.includes(sel) || sel.includes(on);
          });
        }
        if (hit && !matched.includes(hit)) matched.push(hit);
      }

      // ✅ only set if we actually matched something
      if (matched.length > 0) {
        const alreadyHasValue = Array.isArray(item.value) && item.value.length > 0;
        if (!alreadyHasValue) {
          item.value = matched; // keeps your "option objects" format
        }
      }

      return item;
    }

    return item;
  });
}
*/

//step-8: Collecting unanswer inputs making ready to send to different model.

export function collectUnanswered(enrichedGrouped) {
  const unanswered = [];

  for (const item of enrichedGrouped) {
    if (item.kind === 'nonGroup') {
      if (!item.field?.value) unanswered.push(item);
    } else if (item.kind === 'group') {
      if (!item.value || item.value.length === 0) unanswered.push(item);
    }
  }
  console.log('Unanswered:',unanswered)
  return unanswered;
}

// helper: true only if we have at least one usable {question, answer}
function hasUsableModelOutput(modelOutputArray = []) {
  if (!Array.isArray(modelOutputArray) || modelOutputArray.length === 0) return false;

  for (const row of modelOutputArray) {
    const q = normQ(row?.question);
    if (!q) continue;

    const ans = parseModelAnswer(row?.answer);
    const asArr = toStringArray(ans).map(x => String(x).trim()).filter(Boolean);

    const noValue =
      ans == null ||
      asArr.length === 0 ||
      asArr.some(x => /i don'?t know|i do not know|null|unknown|n\/a/i.test(x));

    if (!noValue) return true; // at least 1 useful answer
  }
  return false;
}

//Step-9 building payload for FieldMappings, active learning. MOde items-Al, label-fieldmapping

export function buildPayloadForMappingAndActiveLearning(unanswered, user_id, mode = "items") {
  const questions = [];

  for (const item of (unanswered || [])) {
    let q = "";

    if (item?.kind === "nonGroup") q = (item?.field?.humanName || "").trim();
    else if (item?.kind === "group") q = (item?.question || "").trim();

    if (q) questions.push(q);
  }

  // de-dupe by normalized question
  const seen = new Set();
  const dedupedQuestions = [];
  for (const q of questions) {
    const k = q.toLowerCase().replace(/\s+/g, " ").trim();
    if (!k || seen.has(k)) continue;
    seen.add(k);
    dedupedQuestions.push(q);
  }

  if (mode === "labels") {
    return dedupedQuestions; // ["First name", "Email", ...]
  }

  // mode === "items"
  return dedupedQuestions.map((question) => ({
    user_id: user_id ?? null,
    question,
  }));
}



// step-5 Building pyaload for gemma

// Build payload again in your model format
export function buildModelPayloadFromGrouped(grouped) {
  return grouped.map(item => {
    if (item.kind === 'nonGroup') {
      const f = item.field;
      return {
        kind: "nonGroup",
        el: f?.element ? f.element.outerHTML : "",
        id: f?.input_number||"",
        label: f?.humanName || "",
        type: f?.elementType || ""
      };
    }

    // group
    return {
      kind: "group",
      el: item.options?.[0]?.element ? item.options[0].element.outerHTML : "",
      id: item.input_number|| "",
      label: item.question || "",
      type: item.elementType || "",
      options: (item.options || []).map(o => ({ value: o.label }))
    };
  });
}

//Step-10  For getting values through Fieldmapping 

// ===================== NEGATIVE / POSITIVE RULES =====================
// NOTE: single-line regex literals (no syntax errors)

const NEG_NAME =
  /\b(employer|company|organization|business|vendor|client|customer|manager|supervisor|recruiter|hr|interviewer|reference|referee|emergency|contact\s*person|parent|guardian|spouse|school|university|college|bank|account|beneficiary)\b/i;
const NEG_EMAIL =
  /\b(employer|company|organization|business|manager|supervisor|recruiter|hr|reference|referee|emergency|contact\s*person)\b/i;

const NEG_PHONE =
  /\b(employer|company|organization|business|work|office|desk|manager|supervisor|recruiter|hr|reference|referee|emergency|contact\s*person|extension|ext\.?)\b/i;

const NEG_DOB =
  /\b(dependent|child|spouse|parent|guardian)\b/i;

// Strict-positive for country code (prevents matching generic "country")
const POS_COUNTRY_CODE =
  /\b(country\s*code|phone\s*code|dial(ing)?\s*code|calling\s*code)\b/i;


// ===================== HELPERS =====================
function hasNegatives(label, dataKey) {
  const t = (label || "").toLowerCase();

  // user-requested simplification: use NEG_NAME for any key containing "name"
  if ((dataKey || "").includes('name')) return NEG_NAME.test(t);

  if (dataKey === 'email') return NEG_EMAIL.test(t);
  if (dataKey === 'phonenumber') return NEG_PHONE.test(t);
  if (dataKey === 'dateofbirth') return NEG_DOB.test(t);

  return false;
}
// ===================== MAIN FUNCTION =====================
// params: (questions, autofillData)
// - questions: array of label strings (many questions)
// - autofillData: object containing values keyed by dataKey
// returns: array of { question, answer } where answer is value or null
function mapQuestionsToAnswers(questions = [], autofillData = {}) {
  const results = [];
  const normalizedData = {};
  for(const key in autofillData){
    normalizedData[normalizeFieldName(key)] = autofillData[key];
  }
  autofillData = normalizedData;
  for (const question of questions) {
    //const label = (question || "").trim();
    const label = normalizeFieldName(question);
    let matchedKey = null;

    // Find first valid mapping (with negative gating)
    for (const mapping of fieldMappings) {
      // ---- Country code: STRICT positive only ----
      if (mapping.handleCountryCode) {
        if (!POS_COUNTRY_CODE.test(label)) continue;
        matchedKey = mapping.dataKey;
        break;
      }

      // ---- Keyword match ----
      const keywordHit = mapping.keywords?.some((rx) => rx.test(label));
      if (!keywordHit) continue;

      // ---- Negative gate ----
      if (hasNegatives(label, mapping.dataKey)) continue;

      matchedKey = mapping.dataKey;
      break;
    }

    const answer =
      matchedKey && Object.prototype.hasOwnProperty.call(autofillData, matchedKey)
        ? autofillData[matchedKey]
        : null;

    results.push({ question, answer });
  }

  return results;
}




//  Used in inputSelection for Deduplicate only *consecutive* fields with the same humanName & no groupId

function filterConsecutiveDuplicates(fields) {
  const result = [];

  for (let i = 0; i < fields.length; i++) {
    const curr = fields[i];
    const prev = result[result.length - 1];

    if (
      !curr.groupId &&
      prev &&
      !prev.groupId &&
      normalizeName(prev.humanName) === normalizeName(curr.humanName)
    ) {
      continue;
    }

    result.push(curr);
  }

  return result;
}

// Main entry: returns all visible, real form fields on the active page
function inputSelection() {
  // If you use section helpers / repeated-section indexing,
  // clear them here each pass.
  // resetSectionHelpers && resetSectionHelpers();

  const roots = collectAllRoots();
  const all = roots.flatMap(r => collectInputsIn(r));

  // Deduplicate by element identity
  const uniq = [];
  const seen = new WeakSet();
  for (const it of all) {
    //we are skipping powerhost domain because it is skipping some input fields ex; lastname.
    if (!isPowerHost && !seen.has(it.element)) {
      seen.add(it.element);
      uniq.push(it);
    }
    else{
      //seen.add(it.element);
      uniq.push(it);
    }
  }

  // Remove only *consecutive* duplicates with same humanName + no groupId
  const finalFields = filterConsecutiveDuplicates(uniq);

  // console.log('InputSelection: total visible fields', finalFields.length, finalFields.slice(0, 50));
  return finalFields;
}


// STEP-1, INPUTS EXTRACTION
/*
// NEW: Robust visibility check for "real" on-page inputs
function isEffectivelyVisible(el) {
  if (!el || !el.ownerDocument) return false;
  // Walk up ancestors and bail if *any* are hidden
  let node = el;
  while (node && node.nodeType === 1) {
    const style = window.getComputedStyle(node);
    // CSS-style hidden
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    // Attribute-style hidden (wizard steps, SR-only sections, etc.)
    if (
      node.hasAttribute('hidden') ||
      node.getAttribute('aria-hidden') === 'true' ||
      node.hasAttribute('inert')
    ) {
      return false;
    }
    node = node.parentElement;
  }
  return true;
}

//function collectInputsIn(root,data, mappingConfig)
function collectInputsIn(root){
  const sel = `
    input:not([disabled]):not([readonly]):not([type="hidden"]),
    select:not([disabled]):not([readonly]),
    textarea:not([disabled]):not([readonly]),
    [contenteditable="true"]:not([aria-disabled="true"]),
    [role="textbox"]:not([aria-disabled="true"]),
    [role="combobox"]:not([aria-disabled="true"])
  `;
  const nodes = [...root.querySelectorAll(sel)];
  // SKIPPING TOOLBAR
  const isToolbarish = (el) =>
    el.closest('[role="toolbar"], [role="menu"], header, [data-testid*="toolbar"], [class*="toolbar"]');

  const results = [];
  let groupCounter = 0;

  for (const input of nodes) {
    // Skip random buttons unless true combobox
    if (input.tagName === 'BUTTON' && input.getAttribute('role') !== 'combobox') continue;
    if (isToolbarish(input)) continue;
    const style = window.getComputedStyle(input);
    //input is a text field and it lives inside one of those floating panels, the code skips
    const inFloatingPanel =
      !!input.closest('[role="listbox"], [role="dialog"], [role="menu"]') &&
      (style.position === 'fixed' || style.position === 'absolute');
    if (inFloatingPanel && input.tagName === 'INPUT' && input.type === 'text') continue;
    //==icims 
    if (isIcimsHost) {
      // iCIMS dropdown search inputs live inside role=listbox but may not be fixed/absolute
      if (input.closest('[role="listbox"], [role="dialog"], [role="menu"]')) {
        // skip overlay search boxes; we’ll drive selects via anchor/search later
        if (input.tagName === 'INPUT' && (input.type === 'text' || input.classList.contains('dropdown-search'))) {
          continue;
        }
      }
      // also skip known non-targets
      if (input.matches('#nav-trigger, textarea[id^="h-captcha-response"],textarea[id^="h-captcha-response"],textarea.g-recaptcha-response')) continue;
    }
    //  skip inputs that are not visually on-page (hidden steps, aria-hidden, etc.)
    // Exception for ashby because unable to extract yes/no buttons
    //if (!isAshbyHost && !isEffectivelyVisible(input)) continue;

    let groupId = null;
    let humanName = null;

    const t = (input.type||'').toLowerCase();
    if (t === 'checkbox' || t === 'radio') {
      // --- your existing grouping logic (unchanged) ---
      let key = '';
      if (input.name) key = `name:${input.name}`;
      if (!key){
        const fs = input.closest('fieldset');
        const legend = fs?.querySelector('legend')?.textContent?.trim();
        if (legend) key = `fieldset:${normalizeFieldNameWithSpace(legend)}`;
      }
      if (!key && input.getAttribute('aria-labelledby')){
        key = `aria:${input.getAttribute('aria-labelledby')}`;
      }
      const container = input.closest('fieldset, section, div, form, ul, ol, table, tbody, tr') || root;
      if (!key){
        if (!groupCache.has(container)) groupCache.set(container, `group-${groupCounter++}`);
        key = groupCache.get(container);
      }
      groupId = key;

      if (!container._humanName) {
        container._humanName = inputFieldSelection(input) || input.name || '';
      }
      humanName = container._humanName;

      // --- NEW: only on Ashby, link nearby Yes/No buttons to this checkbox group ---
      if (isAshbyHost && t === 'checkbox') {
        const yesNoBtns = ashbyFindYesNoButtonsNear(input);
        if (yesNoBtns.length) {
          // Prefer the visible question text if present
          const q = ashbyQuestionTextFor(input);
          const human = q ? normalizeFieldNameWithSpace(q) : humanName;
          for (const b of yesNoBtns) {
            results.push({
              element: b.el,           // use the button as the actionable element
              groupId,
              humanName: human,
              ashbyLinked: true,       // optional hint for your filler
              optionText: b.text,       // "yes" or "no"
              //sectionKind: null,
              //sectionIndex: null,
              //mapping: null,
              //dataKey: null,
              //mappingReason: null,
            });
          }
        }
      }
      // --- end Ashby block ---

    } else {
      humanName = inputFieldSelection(input) || input.name || input.getAttribute?.('aria-label') || '';
    }

    const obj = { 
      element: input, 
      groupId, humanName,
      //sectionKind: null,
      //sectionIndex: null,
      //mapping: null,
      //dataKey: null,//
      //mappingReason: null,
      //isResidenceAddress: false,
    };
    if (isWorkdayHost()&& typeof refineDateHumanNameAndGroup === 'function'){
      refineDateHumanNameAndGroup(obj);
    }
    // === NEW: use existing decideMapping strategy to infer kind + index ===
    /*
    try {
      if (data && mappingConfig && humanName) {
        const inputLabel = (humanName || '').toLowerCase();
        const decision = decideMappingForInput(
          input,
          inputLabel,
          data,
          mappingConfig
        );
        // decision can be null, { skip:true }, or full mapping result
        if (decision && !decision.skip) {
          // Reuse the same strategy: kind/index are the ones your filler already uses
          if (decision.kind && typeof decision.index === 'number') {
            obj.sectionKind = decision.kind;       // 'education' | 'experience'
            obj.sectionIndex = decision.index;     // 0,1,2,...
          }

          obj.mapping = decision.mapping || null;
          obj.dataKey = decision.dataKey || null;
          obj.mappingReason = decision.reason || null;

          // Very important: residence vs repeated-section address
          // We treat "res" reason as pure residence address (no sectionKind/index)
          if (decision.reason === 'res') {
            obj.isResidenceAddress = true;
            obj.sectionKind = null;
            obj.sectionIndex = null;
          }
        }
      }
    } catch(e) {
      console.warn('decideMappingForInput failed during extraction:', e);
    }
    *//*
    results.push(obj);
  }
  
  // after the for-loop, before returning:
  results.sort((a,b) => {
    if (a.groupId && a.groupId === b.groupId) {
      const aIsBtn = a.element?.tagName === 'BUTTON';
      const bIsBtn = b.element?.tagName === 'BUTTON';
      if (aIsBtn !== bIsBtn) return aIsBtn ? 1 : -1; // INPUTs first
    }
    return 0;
  });
  //console.log('All Results with input,label and id:', results.slice(0,70));
  return results;
}
function allShadowHosts(root=document){
  return [...root.querySelectorAll('*')].filter(el=>el.shadowRoot);
}
function collectAllRoots(){
  const roots = [document];
  const stack = [...allShadowHosts(document)];
  // we are making comment as of now because ashybyhq iframe issues
  document.querySelectorAll('iframe').forEach(fr=>{              //, frame
    try{
      if (fr.contentDocument && isEffectivelyVisible(fr)){ // 
        roots.push(fr.contentDocument);
        stack.push(...allShadowHosts(fr.contentDocument));
      }
    }catch{}
  });

  while (stack.length) {
    const host = stack.pop();
    if (host.shadowRoot) {
      roots.push(host.shadowRoot);
      stack.push(...allShadowHosts(host.shadowRoot));
    }
  }
  return roots;
}

//function inputSelection(data, mappingConfig)
function inputSelection(){
  // 🔁 Always start with a fresh section/index state for this pass
  //resetSectionHelpers();
  const roots = collectAllRoots();
  const all = roots.flatMap(r=>collectInputsIn(r))
  //const all = roots.flatMap(r => collectInputsIn(r, data, mappingConfig));
  let uniq = [];
  const seen = new WeakSet();
  for (const it of all) {
    if (!seen.has(it.element)) {
      seen.add(it.element);
      uniq.push(it);
    }
  }
  // usage: Looking for consecutive duplicates.
  uniq = filterConsecutiveDuplicates(uniq);
  //console.log('iN Inputselectionfunction Total inputs collected', uniq.length, uniq.slice(0,70));
  return uniq;
}
function normalizeName(str) {
  return (str || '').toLowerCase().trim();
}

function filterConsecutiveDuplicates(fields) {
  const result = [];

  for (let i = 0; i < fields.length; i++) {
    const curr = fields[i];
    const prev = result[result.length - 1];

    // If both have no groupId and same normalized humanName → skip as duplicate
    if (
      !curr.groupId &&
      prev &&
      !prev.groupId &&
      normalizeName(prev.humanName) === normalizeName(curr.humanName)
    ) {
      // drop the current one
      continue;
    }

    result.push(curr);
  }

  return result;
}

*/


// =====================
// Repeated section discovery (Add buttons, titles)
//EDUCATION =====
export const eduMappings = [
  { keywords:[/\b(school|college|university)\s*(?:name)?\b/i],     dataKey:'educations[x].school' },
  { keywords:[/\bdegree\b/i],                                       dataKey:'educations[x].degree' },
  { keywords:[/\b(major|field\s*of\s*study|discipline|course|course\s*of\s*study)\b/i], dataKey:'educations[x].major' },
  { keywords:[/\b(cgpa|gpa)\b/i],                                   dataKey:'educations[x].cgpa' },
  { keywords:[/\bcurrently\s*studying|present\b/i],                 dataKey:'educations[x].currently_studying' },
];

// ===== EXPERIENCE =====
export const expMappings = [
  { keywords:[/\b(company|employer|organization)\s*(?:name)?\b/i], dataKey:'experiences[x].company_name' },
  { keywords:[/\b(job|role|position)\b(?!(\s*description))\s*(?:(title|name))?\b/i],     dataKey:'experiences[x].job_name' },
  { keywords:[/\bcurrently\s*(work|working)|present\b/i],                 dataKey:'experiences[x].currently_working' },
  { keywords:[/\b(duties|responsibilities|description)\b/i],       dataKey:'experiences[x].job_duties' },
];

// ===== SHARED ADDRESS (dynamic prefix for repeated sections) =====
export const addressMappings = [
  { keywords:[/\b(start\s*date|from|start)\b/i],                    dataKey:'{prefix}[x].start_date', type:'date' },
  { keywords:[/\bend\s*date|graduation\s*date|to|end\b/i],          dataKey:'{prefix}[x].end_date',   type:'date' },
  { keywords:[/(?:(?<!e[-\s]?mail\s*)\b(?:(?:employer|working)\s*)?address\b(?!\s*line\s*2\b)(?:\s*(?:line\s*1|number(?:\s*\d+)?))?|\bstreet\s*number\b)/i], dataKey:'{prefix}[x].address' },
  { keywords:[/\b(?:(?:employer|working|school|university|job|company)\s*)?(city|town)\b/i], dataKey:'{prefix}[x].city' },
  { keywords:[/\b(?:(?:employer|working|school|university|job|company)\s*)?state\b(?!\s*of\b)/i], dataKey:'{prefix}[x].state' },
  { keywords:[/\b(?:(?:employer|working|school|university|job|company)\s*)?zip(?:\s*code)?\b/i], dataKey:'{prefix}[x].zip_code' },
  { keywords:[/\b(?:(?:employer|working|school|university|job|company)\s*)?country\b(?!\s*(?:code|dial|calling)\b)/i], dataKey:'{prefix}[x].country' },
  { keywords:[/\b(?:(?:employer|working|school|university|job|company)\s*)?location\b/i],dataKey:'{prefix}[x].location', type:'combine'},
];

export const resMappings = [
    // ==== CONTACT ADDRESS (root/residence) ====
  { keywords: [/(?:(?<!e[-\s]?mail\s*)\b(?:(?:residence|residential|street|postal|permanent|home)\s*)?address\b(?!\s*line\s*2\b)(?:\s*(?:line\s*1|number(?:\s*\d+)?))?|\bstreet\s*number\b)/i], dataKey: 'residenceaddress' },
  { keywords: [/\b(?:(?:residence|residential|permanent|present|current|home)\s*)?(?:city|town)\b/i], dataKey: 'residencecity' },
  { keywords: [/\b(?:(?:residence|residential|permanent|present|current|home)\s*)?state\b(?!\s*of\b)/i], dataKey: 'residencestate' },
  { keywords: [/\b(?:(?:residence|residential|permanent|present|current|home)\s*)?country\b(?!\s*(?:code|dial|calling)\b)/i], dataKey: 'residencecountry' },
  //{ keywords: [/\b(?:(?:residence|residential|permanent|present|current|home)\s*)(?:zip|postal|area)\s*code\b/i], dataKey: 'residencezipcode'},
  {keywords: [/\b(?:(?:residence|residential|permanent|present|current|home)\s*)?(?:zip|postal|area)\s*code\b/i], dataKey: 'residencezipcode'},
  { keywords: [/\b(?:(?:residence|residential|permanent|present|current|home)\s*)?(?:location)\b/i], dataKey: 'residencelocation' }
]
const TITLE_BUCKETS = {
  education: ['education','school','college','university','degree','qualification'],
  experience: ['experience','employment','employment history','work history','company','job history','work experience'],
  languages: ['language','languages'],
  certifications: ['certification','certifications','license','licenses','credential','credentials'],
};
const SECTION_TO_DATAKEY = {
  education: 'educations',
  experience: 'experiences',
  languages: 'languages',
  certifications: 'certifications',
};
const isSmartRecruitersHost =
  /(^|\.)smartrecruiters\.com$/i.test(location.hostname);
function normalize(s){ return normalizeFieldNameWithSpace(s||''); }
const HEADING_SEL = 'h1,h2,h3,h4,h5,h6,[role="heading"],legend';
const TITLE_HINT_SEL = [
  'label','strong','span',
  '[data-automation-id*="Heading"]',
  '[data-automation-id*="Title"]',
  '[data-automation-id*="header"]',
  '[data-automation-id*="title"]'
].join(',');
//to find forms near fields.
const CONTAINER_UP_SEL = 'section,fieldset,form,article,div';
//function to return the text of an element
function textOf(el){ return (el?.textContent || '').trim(); }
function firstMatch(scope, sel){ try { return scope?.querySelector?.(sel) || null; } catch { return null; } }
function textFromAria(el, doc = document){
  if (!el) return '';
  const label = el.getAttribute('aria-label');
  if (label) return label.trim();
  const labelledBy = el.getAttribute('aria-labelledby');
  if (labelledBy){
    const ids = labelledBy.split(/\s+/).filter(Boolean);
    const txt = ids.map(id => doc.getElementById(id)?.textContent || '').join(' ').trim();
    if (txt) return txt;
  }
  return '';
}
function resolveSectionTitleForAdd(btn, { maxHops = 4 } = {}){
  if (!btn) return '';
  const doc = btn.ownerDocument || document;
  let ariaTxt;
  if(isWorkableJobsHost){
    console.log('Entered');
    ariaTxt = textFromAria(btn, doc);
    if (ariaTxt) return ariaTxt;
  }
  let node = btn.closest(CONTAINER_UP_SEL);
  let hops = 0;

  while (node && hops < maxHops){
    const legend = node.matches('fieldset') ? firstMatch(node, 'legend') : null;
    if (legend && textOf(legend)) return textOf(legend);

    const heading = firstMatch(node, HEADING_SEL);
    if (heading && textOf(heading)) return textOf(heading);

    // 🔹 SmartRecruiters: section titles live in <spl-typography-title data-test="section-title">
    if (isSmartRecruitersHost) {
      const srTitle = firstMatch(node, 'spl-typography-title[data-test="section-title"]');
      if (srTitle && textOf(srTitle)) return textOf(srTitle);
    }

    ariaTxt = textFromAria(node, doc);
    if (ariaTxt) return ariaTxt;

    const wdHint = firstMatch(node, TITLE_HINT_SEL);
    if (wdHint && textOf(wdHint)) return textOf(wdHint);

    // walk previous siblings
    let prev = node.previousElementSibling;
    while (prev){
      const prevHeading = prev.matches(HEADING_SEL) ? prev : firstMatch(prev, HEADING_SEL);
      if (prevHeading && textOf(prevHeading)) return textOf(prevHeading);

      if (isSmartRecruitersHost) {
        const prevSrTitle = prev.matches('spl-typography-title[data-test="section-title"]')
          ? prev
          : firstMatch(prev, 'spl-typography-title[data-test="section-title"]');
        if (prevSrTitle && textOf(prevSrTitle)) return textOf(prevSrTitle);
      }

      const prevLabelish = firstMatch(prev, TITLE_HINT_SEL);
      if (prevLabelish && textOf(prevLabelish)) return textOf(prevLabelish);

      const prevAria = textFromAria(prev, doc);
      if (prevAria) return prevAria;

      prev = prev.previousElementSibling;
    }

    node = node.parentElement?.closest?.(CONTAINER_UP_SEL) || node.parentElement;
    hops++;
  }

  return nearestTextAround(btn, 300) || '';
}

//finding add button with nearest titles.
function findAddButtonsWithTitles(root = document) {
  const CLICKABLE = [
    'button',
    '[role="button"]',
    'a[href]',
    '[tabindex]:not([tabindex="-1"])',
    'oc-button',
    //'spl-button'
  ].join(',');

  const ADD_TEXT_RE = /\b(add|new|\+)\b/i;

  const candidates = [...root.querySelectorAll(CLICKABLE)].filter(el =>  ADD_TEXT_RE.test(el.textContent || el.getAttribute('aria-label') || '')); //isElementVisible(el) &&
  console.log('buttons found',candidates);
  return candidates.map(btn => {
    const titleText = resolveSectionTitleForAdd(btn, { maxHops: 6 }) || '';
    const controlsId = btn.getAttribute('aria-controls');
    const controlled = controlsId ? btn.ownerDocument.getElementById(controlsId) : null;
    const norm = normalize(titleText);
    console.log('findaddbuttonswithtitles,:',btn,norm,controlled);
    return { button: btn, rawTitle: titleText, normTitle: norm, controlled };
  });
}
//function to return add button section title is  edu/exp or none.
function titleToSectionKey(normTitle) {
  if (!normTitle) return null;
  for (const [key, keywords] of Object.entries(TITLE_BUCKETS)) {
    if (keywords.some(k => normTitle.includes(k))) return key;
  }
  return null;
}
async function safeClick(el) {
  if (!el) return false; // || !isElementVisible(el)
  el.scrollIntoView({ behavior: 'smooth', block: 'center' });
  await new Promise(r => setTimeout(r, 120));
  el.dispatchEvent(new MouseEvent('pointerdown', { bubbles: true }));
  el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
  el.click?.();
  el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
  el.dispatchEvent(new MouseEvent('pointerup', { bubbles: true }));
  return true;
}
async function waitAfterExpand() {
  await waitForDomStable({ timeoutMs: 3000, quietMs: 180 });
  await new Promise(r => setTimeout(r, 60));
}
//function to return the opened inputs
function resolveNewContainer(candidate) {
  const modal = document.querySelector('[role="dialog"][aria-modal="true"], [data-automation-id*="promptPanel"], [data-automation-id*="modalDialog"]');
  if (modal && isElementVisible(modal)) return modal;
  if (candidate?.controlled && isElementVisible(candidate.controlled)) return candidate.controlled;
  return widenToInputCluster(candidate?.button || document.body);
}
//Returns new form fields.
function widenToInputCluster(anchor) {
  const containers = [
    anchor?.closest?.('section,fieldset,form,div,article'),
    document
  ].filter(Boolean);

  let best = containers[0] || document;
  let bestScore = -1;

  for (const c of containers) {
    const visibleInputs = [...c.querySelectorAll('input,select,textarea,[contenteditable="true"]')]
      .filter(isElementVisible).length;
    if (visibleInputs > bestScore) {
      bestScore = visibleInputs;
      best = c;
    }
  }
  //console.log('wideninputcluster best contiane for add button:',best);
  return best;
}

// *** NEW: use a real section root instead of document.body
function resolveNearestSectionRoot(input) {
  if (!input) return document.body;
  const root = input.closest(CONTAINER_UP_SEL);
  return root || document.body;
}

// ================== CLASSIFICATION ==================

function classifySectionForInput(input) {
  const root = resolveNearestSectionRoot(input);               // *** UPDATED: per-section root
  const raw  = resolveSectionTitleForAdd(input, { maxHops: 4 }) || '';
  const norm = normalizeFieldNameWithSpace(raw);

  let kindFromTitle = null;
  for (const [key, list] of Object.entries(TITLE_BUCKETS)) {
    if (list.some(k => norm.includes(k))) {
      kindFromTitle = key;     // 'education' | 'experience' | 'languages' | 'certifications'
      break;
    }
  }
  // We only care about education/experience for repeated sections in this logic
  const sectionKind = (kindFromTitle === 'education' || kindFromTitle === 'experience')
    ? kindFromTitle
    : null;
  return {
    kind: sectionKind,  // 'education' | 'experience' | null
    root,
    titleNorm: norm
  };
}
// anchors + blind spots
const EDU_ANCHORS = [/\bdegree\b/i, /\b(school|college|university)\b/i, /\b(discipline|major|field\s*of\s*study)\b/i];
const EXP_ANCHORS = [/\b(company|employer|organization)\b/i, /\b(job|role|position)\s*(?:(title|name))?\b/i];
const ADDRESSISH = [
  /\baddress\b(?!\s*line\s*2\b)/i, /\bcity\b/i, /\bstate\b(?!\s*of\b)/i, /\bzip(?:\s*code)?\b/i,
  /\bcountry\b(?!\s*(?:code|dial|calling)\b)/i
];
//checking the input labels with edu anchors to make sure ot belongs to correct kind
function isAnchorLabel(label, kind){
  const rxs = kind==='education' ? EDU_ANCHORS : kind==='experience' ? EXP_ANCHORS : [];
  return rxs.some(rx=>rx.test(label));
}
//checking belongs to address labels
function isAddressish(label){ return ADDRESSISH.some(rx=>rx.test(label)); }
// per-section states
let sectionState = new WeakMap(); // root -> { kind, locked, index,perIndexFilled: Map<number, Set<string>>}
const usedIndex = { education:new Set(), experience:new Set() };
//map Function storing the kind,index and filledkeys.
function ensureSectionState(root, kind){
  if (!sectionState.has(root)) {
    sectionState.set(root, { kind, locked:false, index:null, perIndexFilled:new Map() });
  }
  const st = sectionState.get(root);
  if (!st.kind && kind) st.kind = kind;
  return st;
}
//to return unused first index in arrays
function nextUnusedIndex(kind, data){
  const arr = (kind==='education') ? (data.educations||[]) : (data.experiences||[]);
  const used = usedIndex[kind];
  for (let i=0;i<arr.length;i++){
    if (!used.has(i)) return i;
  }
  return null;
}
// Consumption ledger: kind -> Map<index, Set<relKey>>
const consumed = {
  education: new Map(),
  experience: new Map()
};
//checking the particular section index datakey is used or not
function isConsumed(kind, index, relKey){
  const m = consumed[kind];
  const s = m.get(index);
  return !!s && s.has(relKey);
}
//Marking as consumed
function markConsumed(kind, index, relKey){
  const m = consumed[kind];
  if (!m.has(index)) m.set(index, new Set());
  m.get(index).add(relKey);
}

// Get next unused index >= startIdx
function nextUnusedIndexFrom(kind, data, startIdx=0){
  const arr = (kind==='education') ? (data.educations||[]) : (data.experiences||[]);
  const used = usedIndex[kind];
  for (let i = startIdx; i < arr.length; i++){
    if (!used.has(i)) return i;
  }
  //return null;
  return null;
}

//to lock which index need to parse for sections.
function lockIndexForSection(st, kind,data){
  const arr = kind==='education' ? (data.educations||[]) : (data.experiences||[]);
  let bestIdx = null//, bestScore = -1;
  for (let i = 0; i < arr.length; i++) {
    // Check if the current index 'i' is NOT in the set of used indices for this 'kind'.
    if (!usedIndex[kind].has(i)) {
      bestIdx = i; // This is the first unused index we found.
      break;       // Stop the loop immediately.
    }
  }
  const fallback = nextUnusedIndex(kind, data);
  st.index = (bestIdx !== null ? bestIdx : (fallback ?? 0));
  // Mark the state as locked and add the chosen index to the used set.
  st.kind    = kind;
  st.locked = true;
  usedIndex[kind].add(st.index);
}
//Code to reset the section state
function resetSectionHelpers() {
  // New WeakMaps so old roots/state are discarded
  sectionState = new WeakMap();

  // Clear per-kind index tracking
  usedIndex.education.clear();
  usedIndex.experience.clear();

  // Clear consumption ledger
  consumed.education.clear();
  consumed.experience.clear();
}

//Updating dynamically section key and index
function resolveDataKey(template, kind, index){
  return template
    .replace('{prefix}', kind==='education' ? 'educations' : 'experiences')
    .replace('[x]', `.${index}`)
    .replace('educations[x]', `educations.${index}`)
    .replace('experiences[x]', `experiences.${index}`);
}
//functio ot return path
function getByPath(obj, path){
  if (!path) return undefined;
  const parts = path.split('.').map(p => /^\d+$/.test(p) ? Number(p) : p);
  return parts.reduce((a,k)=>a?.[k], obj);
}

//Main function for decideing wether it is repeated or non repeated.
function decideMappingForInput(input, inputLabel, data, { 
  fieldMappings, eduMappings, expMappings, addressMappings
}){
  const base = fieldMappings.find(m => m.keywords?.some(rx=>rx.test(inputLabel)));
  if (base) return { mapping: base, dataKey: base.dataKey,reason: 'base' };
  // NOTE: assuming resMappings exists in your scope (as in your code)
  const res = resMappings.find(m=>m.keywords?.some(rx=>rx.test(inputLabel)));
  const eduHit  = eduMappings.find(m => m.keywords?.some(rx=>rx.test(inputLabel)));
  const expHit  = expMappings.find(m => m.keywords?.some(rx=>rx.test(inputLabel)));
  const addrHit = addressMappings.find(m => m.keywords?.some(rx=>rx.test(inputLabel)));
  const { kind, root } = classifySectionForInput(input);
  //console.log('decide functon,inputlabel, root and  kind received for input',inputLabel,root,kind);
  let inferredKind = kind;
  //console.log('decide function, 1st inferredkind',inferredKind);
  if (!inferredKind) inferredKind = eduHit ? 'education' : expHit ? 'experience' : null;

  let st = ensureSectionState(root, inferredKind);
  //console.log('decide functon, section map',st);

  if(res && !st.locked && !inferredKind){
    //console.log('st.locked status:',st.locked);
    return {mapping: res, dataKey:res.dataKey,reason:'res' };
  }

  if (!eduHit && !expHit && !addrHit) return null;

  if(!inferredKind && st.locked){
    inferredKind = st.kind;
   // console.log('decide function,setting kind to use for address labels using st.locked',inferredKind);
  }

  // === UPDATED ①: allow switching the locked kind if current input points to the other kind ===
  // Determine what this input most strongly suggests right now:
  const presentKind = eduHit ? 'education' : (expHit ? 'experience' : inferredKind);
  if (st.locked && presentKind && presentKind !== st.kind) {
    console.log('decide function: switching locked kind from', st.kind, 'to', presentKind);
    st.locked = false;         // drop the old lock
    st.index  = null;          // clear index
    st.kind   = presentKind;   // adopt the new kind
  }
  // === END UPDATED ① ===

  if (presentKind && !st.locked && isAddressish(inputLabel)){
    //console.log('decide skipping because address before lock');
    return { skip:true, reason:'address_before_lock' };
  }

  if (presentKind && !st.locked && isAnchorLabel(inputLabel, presentKind)){
    lockIndexForSection(st, presentKind, data);
    //console.log('decide function,sending new index locked:');
  }

  const hit = eduHit || expHit || addrHit;
  const kindToUse = eduHit ? 'education' : expHit ? 'experience' : presentKind;
  //console.log('decide finla kind to use:',kindToUse);
  if (!kindToUse) return null;

  // === UPDATED ②: respect lock only if it matches the kind we’re about to use ===
  const lockMatchesKind = st.locked && (st.kind === kindToUse);

  let idx = lockMatchesKind ? st.index : (kindToUse ? (nextUnusedIndex(kindToUse, data) ?? 0) : 0);
  if (!lockMatchesKind && !st.locked) {
    // Soft-lock now so subsequent section fields align
    lockIndexForSection(st, kindToUse, data);
    idx = st.index;
  }
  // === END UPDATED ② ===

  //console.log('decide index:',idx);

  // updating dynamic key with correct kind and index
  let tentativeKey = resolveDataKey(hit.dataKey, kindToUse, idx);
  //console.log('decide tenativeKey',tentativeKey);

  // replacing all the dynamic keys with tentative key index related
  let relKey = toRelativeKey(tentativeKey, kindToUse);
  //console.log('decide relKey',relKey);

  // If this relKey for the current index was already consumed, advance index
  while (st.locked && isConsumed(kindToUse, idx, relKey)) {
    const nextIdx = nextUnusedIndexFrom(kindToUse, data, idx + 1);
    if (nextIdx == null) return null; // nothing left to fill
    idx = nextIdx;
    //console.log('decided nextidx due to used idx and datakey',idx);
    tentativeKey = resolveDataKey(hit.dataKey, kindToUse, idx);
    //console.log('decided non conusmed tentativekey',idx);
    relKey = toRelativeKey(tentativeKey, kindToUse);
    //console.log('decided non conusmed relkey',idx);
    // also promote lock to the new index so subsequent fields align
    st.index = idx;
    //console.log('updating st.index because of used index old',st.index);
    usedIndex[kindToUse].add(idx);
    //console.log('decide, if repeated,idx,tentativeKey,relKey:',idx,tentativeKey,relKey);
  }

  //console.log('decide ,finally mapping',hit,'dataKey',tentativeKey,'kind',kindToUse,'index',idx);

  // (Optional improvement you can adopt later: mark with relKey to match the checker)
  markConsumed(kindToUse, idx, tentativeKey);
  console.log("decidemappingfunction Final mapping,kind, index,reason",hit,kindToUse,idx);
  return { mapping: hit, dataKey: tentativeKey, kind: kindToUse, index: idx, reason: 'repeated' };
}

// Count indices we’ve already used for this kind (bounded by data length)
function countExistingByLedger(kind, dataLen){
  const used = usedIndex[kind] || new Set();
  let n = 0;
  for (const idx of used){ if (idx < dataLen) n++; }
  return n;
}
function countExistingByInputs(sectionKey, inputs) {
  if (!inputs || !inputs.length) return 0;
  const indices = new Set();
  for (const obj of inputs) {
    if (obj.sectionKind === sectionKey && typeof obj.sectionIndex === 'number') {
      indices.add(obj.sectionIndex);
    }
  }
  return indices.size;
}
function countExisting(sectionKind, inputs) {
  return new Set(
    inputs
      .filter(i => i.sectionKind === sectionKind)
      .map(i => i.sectionIndex)
  ).size;
}

/*
//=== UPDATED: Add-runner — click only what’s needed
export async function processAddSectionsFromData(autofillData) {
  if (!autofillData || typeof autofillData !== 'object') {
    console.log('[AddRunner] No data to process.');
    return;
  }
  //A funciton to check add buttons with titles and filtering if it is edu/exp/or not.
  let addIndex = findAddButtonsWithTitles(document)
    .map(c => ({ ...c, sectionKey: titleToSectionKey(c.normTitle) }))
    .filter(c => !!c.sectionKey);

  if (!addIndex.length) {
    console.log('[AddRunner] No Add buttons with recognizable titles found.');
    return;
  }

  const plan = [];
  for (const c of addIndex) {
    const dataKey = SECTION_TO_DATAKEY[c.sectionKey]; //ginding key in autofilldata
    const arr = Array.isArray(autofillData[dataKey]) ? autofillData[dataKey] : []; //length and value
    const count = arr.length;
    if (count <= 0) continue;

    plan.push({
      sectionKey: c.sectionKey,
      dataKey,
      count,
      buttonRef: c.button,
      heading: c.rawTitle,
    });
  }
  console.log('processedaddbuttonfinction, plan wher it had buttons with edu/exp',plan);
  if (!plan.length) {
    console.log('[AddRunner] No sections have data; no clicks needed.');
    return;
  }

  const MAX_PER_SECTION = 10;

  for (const item of plan) {
    const { sectionKey, dataKey } = item;
    const arr = autofillData[dataKey];
    const desired = Math.min(arr.length, MAX_PER_SECTION);

    // how many instances already present?

    //const freshBtnInfo = findAddButtonsWithTitles(document)
      //.map(c => ({ ...c, sectionKey: titleToSectionKey(c.normTitle) }))
      //.find(c => c.sectionKey === sectionKey);

    //const btnForCount = freshBtnInfo?.button || item.buttonRef;
    //const existing = btnForCount ? countExistingInstancesNear(btnForCount, sectionKey) : 0;

    const existing = countExistingByLedger(sectionKey, arr.length);

    // We only need to click for the remainder (cap by desired)
    const desiredClicks = Math.max(0, Math.min(desired, arr.length) - existing);

    //const desiredClicks = Math.max(0, desired - existing);
    console.log(`[AddRunner] Section "${sectionKey}" → desired=${desired}, existing=${existing}, clicks=${desiredClicks}`);

    if (desiredClicks === 0) continue;

    let clicks = 0;
    while (clicks < desiredClicks) {
      const fresh = findAddButtonsWithTitles(document)
        .map(c => ({ ...c, sectionKey: titleToSectionKey(c.normTitle) }))
        .find(c => c.sectionKey === sectionKey);

      const btn = fresh?.button || item.buttonRef;
      if (!btn) { //|| !isElementVisible(btn)
        console.warn(`[AddRunner] Add button for "${sectionKey}" not found/visible; stopping at ${clicks}/${desiredClicks}.`);
        break;
      }

      const clicked = await safeClick(btn);
      if (!clicked) {
        console.warn(`[AddRunner] Failed to click Add for "${sectionKey}".`);
        break;
      }
      await waitAfterExpand();

      const container = resolveNewContainer(fresh);
      if (!container) {
        console.warn(`[AddRunner] Could not resolve new container after Add for "${sectionKey}".`);
        break;
      }

      // Existing instances consume arr[0..existing-1]; new click indexes start at existing
      const dataIdx = existing + clicks;
      //const dataItem = arr[dataIdx];
      /*if (!dataItem) {
        console.warn(`[AddRunner] No data item at index ${dataIdx} for "${sectionKey}".`);
        break;
      }*//*
      //console.log('dataItem we are sending at starting is',dataItem);
      try {
        await fillOneBySection(sectionKey, container, autofillData);
      } catch (e) {
        console.error(`[AddRunner] Error filling ${sectionKey} #${dataIdx+1}:`, e);
      }

      clicks += 1;
    }
  }
}*/
export async function processAddSectionsFromData(autofillData, inputsInitial = null) {
  if (!autofillData || typeof autofillData !== 'object') {
    console.log('[AddRunner] No data to process.');
    return;
  }

  let addIndex = findAddButtonsWithTitles(document)
    .map(c => ({ ...c, sectionKey: titleToSectionKey(c.normTitle) }))
    .filter(c => !!c.sectionKey);

  if (!addIndex.length) {
    console.log('[AddRunner] No Add buttons with recognizable titles found.');
    return;
  }

  const plan = [];
  for (const c of addIndex) {
    const dataKey = SECTION_TO_DATAKEY[c.sectionKey];
    const arr = Array.isArray(autofillData[dataKey]) ? autofillData[dataKey] : [];
    const count = arr.length;
    if (count <= 0) continue;

    plan.push({
      sectionKey: c.sectionKey,
      dataKey,
      count,
      buttonRef: c.button,
      heading: c.rawTitle,
    });
  }
  console.log('[AddRunner] Plan:', plan);
  if (!plan.length) {
    console.log('[AddRunner] No sections have data; no clicks needed.');
    return;
  }

  const MAX_PER_SECTION = 10;

  for (const item of plan) {
    const { sectionKey, dataKey } = item;
    const arr = autofillData[dataKey];
    const desired = Math.min(arr.length, MAX_PER_SECTION);

    // NEW: use initial inputs to know how many instances already in DOM
    //const existing = countExistingByInputs(sectionKey, inputsInitial || []);
    const existing = countExisting(sectionKey, inputsInitial||[])

    const desiredClicks = Math.max(0, desired - existing);
    console.log(`[AddRunner] Section "${sectionKey}" → desired=${desired}, existing=${existing}, clicks=${desiredClicks}`);

    if (desiredClicks === 0) continue;

    let clicks = 0;
    while (clicks < desiredClicks) {
      const fresh = findAddButtonsWithTitles(document)
        .map(c => ({ ...c, sectionKey: titleToSectionKey(c.normTitle) }))
        .find(c => c.sectionKey === sectionKey);

      const btn = fresh?.button || item.buttonRef;
      if (!btn) {
        console.warn(`[AddRunner] Add button for "${sectionKey}" not found; stopping at ${clicks}/${desiredClicks}.`);
        break;
      }

      const clicked = await safeClick(btn);
      if (!clicked) {
        console.warn(`[AddRunner] Failed to click Add for "${sectionKey}".`);
        break;
      }
      await waitAfterExpand();

      const container = resolveNewContainer(fresh);
      if (!container) {
        console.warn(`[AddRunner] Could not resolve new container after Add for "${sectionKey}".`);
        break;
      }

      // NOTE: no per-item populate here — the global populateFields() will handle it later
      clicks += 1;
    }
  }
}


//===Autofill
let autofillData = null;
// ===== Core fill =====
/*function setValueWithNativeSetter(el, val){
  try{
    let proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
              : el instanceof HTMLInputElement ? HTMLInputElement.prototype
              : HTMLElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc?.set) desc.set.call(el, val);
    else el.value = val;
  }catch{ el.value = val; }
}*/
// --- unified: native set + React/MUI tracker nudge ---
function setValueWithNativeSetter(el, val){
  try{
    console.log('filling with native value in setter',val)
    const oldVal = el.value; // needed to nudge React's _valueTracker

    let proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
              : el instanceof HTMLInputElement ? HTMLInputElement.prototype
              : HTMLElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, 'value');
    if (desc?.set){ desc.set.call(el, val);console.log('nat1');}
    else{
       el.value = val;
       console.log('nat2');
    }

    // If React is managing this element, mark it dirty so onChange fires
    const tracker = el._valueTracker;
    if (tracker) tracker.setValue(oldVal);

  }catch{
    console.log('filling regulare value in setter',val)
    el.value = val;
  }
}

// --- tiny helper (mouse only) ---
function simulateMouse(el){
  const r = el.getBoundingClientRect();
  const x = Math.floor(r.left + r.width/2), y = Math.floor(r.top + Math.min(r.height/2, 12));
  const ev = (t)=>new MouseEvent(t,{bubbles:true,cancelable:true,clientX:x,clientY:y});
  el.dispatchEvent(ev('mousedown'));
  el.dispatchEvent(ev('mouseup'));
  //el.dispatchEvent(ev('click'));
}

// --- updated: fires input+change, plus light keyboard fallback ---
function fireInputEvents(el, val){ 
  // try to hit editors that listen to beforeinput/input
  try{ el.dispatchEvent(new InputEvent('beforeinput',{bubbles:true,cancelable:true,inputType:'insertFromPaste',data:String(val)})); }catch{}
  try{ el.dispatchEvent(new InputEvent('input',{bubbles:true,cancelable:true,inputType:'insertFromPaste',data:String(val)})); }catch{
    el.dispatchEvent(new Event('input',{bubbles:true,cancelable:true}));
  }

  // tiny keyboard nudge (some UIs set dirty state on key events)
  el.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));
  el.dispatchEvent(new KeyboardEvent('keyup',{key:'Enter',bubbles:true}));

  // finalizer most libs listen for
  el.dispatchEvent(new Event('change',{bubbles:true,cancelable:true}));
}


//step- New code for testing workday date to prevent clicking the wrong input(YYY) in same spin button
function clickLikeUser(el, { bias = 'center' } = {}) {
  if (!el) return false;
  const doc = el.ownerDocument || document;
  const win = doc.defaultView || window;

  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return false;

  // Pick a point inside the element. Left-bias helps when widgets have overlays.
  const x =
    bias === 'left'  ? (r.left + Math.min(10, r.width * 0.2)) :
    bias === 'right' ? (r.right - Math.min(10, r.width * 0.2)) :
                       (r.left + r.width / 2);

  const y = r.top + r.height / 2;

  // elementFromPoint is important: some widgets place a transparent overlay above the input.
  const target = doc.elementFromPoint(x, y) || el;

  const base = {
    bubbles: true,
    cancelable: true,
    composed: true,
    clientX: x, clientY: y,
    screenX: x, screenY: y,
    button: 0,
    buttons: 1,
    detail: 1
  };

  // Pointer events first (modern React/Workday uses these a lot)
  if (typeof win.PointerEvent === 'function') {
    target.dispatchEvent(new win.PointerEvent('pointerdown', { ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
  }
  target.dispatchEvent(new win.MouseEvent('mousedown', base));

  if (typeof win.PointerEvent === 'function') {
    target.dispatchEvent(new win.PointerEvent('pointerup', { ...base, pointerId: 1, pointerType: 'mouse', isPrimary: true }));
  }
  target.dispatchEvent(new win.MouseEvent('mouseup', base));
  target.dispatchEvent(new win.MouseEvent('click', base));

  // Programmatic events don't always move focus; do it explicitly.
  try { el.focus({ preventScroll: true }); } catch { el.focus(); }

  return true;
}
function isWorkdaySplitDatePart(el) {
  if (!el || el.tagName !== 'INPUT') return false;
  const role = (el.getAttribute('role') || '').toLowerCase();
  if (role !== 'spinbutton') return false;

  const id = (el.id || '').toLowerCase();
  // matches ids like: workExperience-4--startDate-dateSectionMonth-input
  return id.includes('datesectionmonth-input') || id.includes('datesectionyear-input');
}

function datePartBias(el) {
  const id = (el.id || '').toLowerCase();
  if (id.includes('datesectionmonth-input')) return 'left';
  if (id.includes('datesectionyear-input')) return 'right';
  return 'center';
}
//FOr workday host multiselect inputs(field of study,..)
// =========================
// Workday MultiSelect (Prompt) – Human Mimic
// Focus -> Click -> Type -> Click -> (Filtered Search Results) -> Pick -> Done
// =========================

function isWorkdayMultiSelectInput(el) {
  if (!el || el.tagName !== 'INPUT') return false;
  return (
    el.getAttribute('data-uxi-widget-type') === 'selectinput' &&
    !!el.closest('[data-automation-id="multiSelectContainer"]')
  );
}

function findWorkdayPromptPanel(doc = document) {
  return (
    doc.querySelector('[data-automation-id="responsiveMonikerPrompt"]') ||
    doc.querySelector('[data-automation-id*="MonikerPrompt"]') ||
    doc.querySelector('[role="dialog"]') ||
    doc.querySelector('[data-automation-id*="prompt"]')
  );
}

// --------- required: norm/isVisible/fuzzyScore/waitUntil/delay/setValueWithNativeSetter ---------
// (You already have these elsewhere in your file. Keep them as-is.)

// --- click like a real user (yours; keep) ---
function clickLikeUserReal(el, { bias = 'center' } = {}) {
  if (!el) return null;
  const doc = el.ownerDocument || document;
  const r = el.getBoundingClientRect();
  if (!r.width || !r.height) return null;

  let x = r.left + r.width * 0.5;
  let y = r.top  + r.height * 0.5;
  if (bias === 'left')  x = r.left + Math.min(18, r.width * 0.25);
  if (bias === 'right') x = r.right - Math.min(18, r.width * 0.25);

  const target = doc.elementFromPoint(x, y) || el;
  const common = { bubbles: true, cancelable: true, composed: true, clientX: x, clientY: y };

  target.dispatchEvent(new PointerEvent('pointerover', { ...common, pointerType: 'mouse' }));
  target.dispatchEvent(new MouseEvent('mouseover', { ...common }));
  target.dispatchEvent(new MouseEvent('mousemove', { ...common }));

  target.dispatchEvent(new PointerEvent('pointerdown', { ...common, pointerType: 'mouse', button: 0, buttons: 1 }));
  target.dispatchEvent(new MouseEvent('mousedown', { ...common, button: 0, buttons: 1 }));

  try { target.focus?.({ preventScroll: true }); } catch {}
  try { el.focus?.({ preventScroll: true }); } catch {}

  target.dispatchEvent(new PointerEvent('pointerup', { ...common, pointerType: 'mouse', button: 0, buttons: 0 }));
  target.dispatchEvent(new MouseEvent('mouseup', { ...common, button: 0, buttons: 0 }));
  target.dispatchEvent(new MouseEvent('click', { ...common, button: 0 }));

  return target;
}

function pressEnterLikeUser(el) {
  if (!el) return;
  const common = { bubbles: true, cancelable: true, composed: true, key: 'Enter', code: 'Enter', which: 13, keyCode: 13 };
  el.dispatchEvent(new KeyboardEvent('keydown',  common));
  try { el.dispatchEvent(new KeyboardEvent('keypress', common)); } catch {}
  el.dispatchEvent(new KeyboardEvent('keyup',    common));
}

function nudgeOpenResults(el) {
  if (!el) return;
  el.dispatchEvent(new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', bubbles:true }));
  el.dispatchEvent(new KeyboardEvent('keyup',   { key: 'ArrowDown', code: 'ArrowDown', bubbles:true }));
}

function clearInputHuman(el) {
  el.dispatchEvent(new KeyboardEvent('keydown', { key:'a', code:'KeyA', ctrlKey:true, bubbles:true }));
  el.dispatchEvent(new KeyboardEvent('keyup',   { key:'a', code:'KeyA', ctrlKey:true, bubbles:true }));
  el.dispatchEvent(new KeyboardEvent('keydown', { key:'Backspace', code:'Backspace', bubbles:true }));
  el.dispatchEvent(new KeyboardEvent('keyup',   { key:'Backspace', code:'Backspace', bubbles:true }));

  setValueWithNativeSetter(el, '');
  try { el.dispatchEvent(new InputEvent('beforeinput', { bubbles:true, inputType:'deleteContentBackward', data:'' })); } catch {}
  el.dispatchEvent(new Event('input', { bubbles:true, composed:true }));
}

function typeTextHuman(el, text) {
  const val = String(text ?? '');

  // simulate “type all”
  el.dispatchEvent(new KeyboardEvent('keydown', { key:'v', code:'KeyV', ctrlKey:true, bubbles:true }));
  el.dispatchEvent(new KeyboardEvent('keyup',   { key:'v', code:'KeyV', ctrlKey:true, bubbles:true }));

  setValueWithNativeSetter(el, val);

  try {
    el.dispatchEvent(new InputEvent('beforeinput', {
      bubbles:true,
      inputType:'insertFromPaste',
      data: val
    }));
  } catch {}

  el.dispatchEvent(new Event('input', { bubbles:true, composed:true }));

  // nudge WD filter
  el.dispatchEvent(new KeyboardEvent('keydown', { key:' ', code:'Space', bubbles:true }));
  el.dispatchEvent(new KeyboardEvent('keyup',   { key:' ', code:'Space', bubbles:true }));

  if ((el.value || '') !== val) {
    setValueWithNativeSetter(el, val);
    el.dispatchEvent(new Event('input', { bubbles:true, composed:true }));
  }
}

// =====================
// NEW: Filtered Search Results only (fixes your issue)
// =====================

// Find the container that holds the *filtered* "Search Results" list
function findSearchResultsContainer(panel) {
  if (!panel) return null;

  // Sometimes WD uses automation ids; keep loose
  const byAttr =
    panel.querySelector('[data-automation-id*="searchResults"]') ||
    panel.querySelector('[data-automation-id*="SearchResults"]');
  if (byAttr && isVisible(byAttr)) return byAttr;

  // Text-based anchor: locate the header that says "Search Results"
  const all = [...panel.querySelectorAll('*')].filter(isVisible);
  const header = all.find(n => {
    const t = norm(n.textContent);
    return t === 'search results' || t.startsWith('search results');
  });

  if (!header) return null;

  // Try a few structural guesses
  const block = header.closest('section,article,div') || header.parentElement;

  // Prefer: next sibling containing radios/options
  const sib = block?.nextElementSibling;
  if (sib && sib.querySelector('input[type="radio"],[role="radio"],[role="option"]') && isVisible(sib)) return sib;

  // Or: within same block (sometimes header + list in one container)
  if (block && block.querySelector('input[type="radio"],[role="radio"],[role="option"]') && isVisible(block)) return block;

  // Fallback
  return block;
}

// Collect only option rows inside the filtered Search Results container
function collectFilteredPromptOptions(panel) {
  const box = findSearchResultsContainer(panel);
  if (!box) return [];

  const candidates = [
    ...box.querySelectorAll(
      // WD often uses radio rows; keep broad but ensure row-like
      '[role="option"], li, div'
    )
  ];

  const options = [];
  for (const el of candidates) {
    if (!isVisible(el)) continue;

    // must look like a row with a radio
    const hasRadio = !!el.querySelector?.('input[type="radio"],[role="radio"]');
    if (!hasRadio) continue;

    const txt = norm(el.textContent);
    if (!txt) continue;

    // avoid grabbing big wrappers that contain multiple radio rows
    const nestedRow = el.querySelector?.('input[type="radio"],[role="radio"]')?.closest('li,div,[role="option"]');
    if (nestedRow && nestedRow !== el) continue;

    options.push({ el, txt });
  }

  // dedupe
  const seen = new Set();
  return options.filter(o => (seen.has(o.txt) ? false : (seen.add(o.txt), true)));
}

// Wait for filtered results to “settle” after typing (prevents grabbing stale/default list)
async function waitForFilteredResults(panel, want, timeout = 2500) {
  const w = norm(want);
  let lastSig = '';

  const ok = await waitUntil(() => {
    const opts = collectFilteredPromptOptions(panel);
    if (!opts.length) return false;

    const sig = opts.map(o => o.txt).join('|');
    const settled = sig && sig === lastSig;
    lastSig = sig;

    // ensure list looks relevant to the query
    const relevant = opts.some(o => {
      const t = o.txt;
      return t.includes(w) || w.includes(t) || fuzzyScore(t, w) >= 55;
    });

    return settled && relevant;
  }, timeout);

  return ok ? collectFilteredPromptOptions(panel) : [];
}

function bestVisibleOption(options, want) {
  const w = norm(want);
  let best = null;

  for (const o of options) {
    const t = o.txt;
    if (t === w) return { ...o, score: 100 };
    if (t.includes(w) || w.includes(t)) {
      const sc = 90;
      if (!best || sc > best.score) best = { ...o, score: sc };
      continue;
    }
    const sc = fuzzyScore(t, w);
    if (!best || sc > best.score) best = { ...o, score: sc };
  }
  return best;
}
function clickDirect(el) {
  if (!el) return false;

  const r = el.getBoundingClientRect?.();
  if (!r || r.width < 2 || r.height < 2) return false;

  const x = r.left + Math.min(16, r.width / 2);
  const y = r.top  + Math.min(10, r.height / 2);

  const common = { bubbles:true, cancelable:true, composed:true, clientX:x, clientY:y };

  el.dispatchEvent(new PointerEvent('pointerover', { ...common, pointerType:'mouse' }));
  el.dispatchEvent(new MouseEvent('mouseover', common));
  el.dispatchEvent(new PointerEvent('pointerdown', { ...common, pointerType:'mouse', button:0, buttons:1 }));
  el.dispatchEvent(new MouseEvent('mousedown', { ...common, button:0, buttons:1 }));

  try { el.focus?.({ preventScroll:true }); } catch {}

  el.dispatchEvent(new PointerEvent('pointerup', { ...common, pointerType:'mouse', button:0, buttons:0 }));
  el.dispatchEvent(new MouseEvent('mouseup', { ...common, button:0, buttons:0 }));
  el.dispatchEvent(new MouseEvent('click', { ...common, button:0 }));

  // Also call native click if available
  try { el.click?.(); } catch {}

  return true;
}

function findClickableInOptionRow(rowEl) {
  if (!rowEl) return null;

  const radio =
    rowEl.querySelector('input[type="radio"]') ||
    rowEl.querySelector('[role="radio"]') ||
    rowEl.querySelector('[aria-checked]');
  if (radio && isVisible(radio)) return radio;

  const inputId = rowEl.querySelector('input[type="radio"]')?.id;
  if (inputId) {
    const lab = rowEl.ownerDocument?.querySelector(`label[for="${CSS.escape(inputId)}"]`);
    if (lab && isVisible(lab)) return lab;
  }
  return rowEl;
}

function clickOptionRow(rowEl) {
  const target = findClickableInOptionRow(rowEl);
  if (!target) return false;

  // IMPORTANT: direct click the target (no elementFromPoint redirect)
  clickDirect(target);

  // WD radios sometimes need Space as well
  try { target.focus?.({ preventScroll:true }); } catch {}
  target.dispatchEvent(new KeyboardEvent('keydown', { key:' ', code:'Space', bubbles:true }));
  target.dispatchEvent(new KeyboardEvent('keyup',   { key:' ', code:'Space', bubbles:true }));

  return true;
}


function isOptionSelected(rowEl) {
  if (!rowEl) return false;
  const radio = rowEl.querySelector('input[type="radio"]');
  if (radio) return !!radio.checked;

  const roleRadio = rowEl.querySelector('[role="radio"]');
  if (roleRadio) return (roleRadio.getAttribute('aria-checked') || '').toLowerCase() === 'true';

  return false;
}

function findDoneButton(panel) {
  if (!panel) return null;

  const byAttr =
    panel.querySelector('[data-automation-id*="done"]') ||
    panel.querySelector('[data-automation-id*="Done"]');
  if (byAttr && isVisible(byAttr)) return byAttr;

  const buttons = [...panel.querySelectorAll('button,[role="button"]')].filter(isVisible);
  return buttons.find(b => norm(b.textContent) === 'done') || null;
}

// =====================
// MAIN: Human Mimic + Filtered Results selection
// =====================
async function fillWorkdayMultiSelectPrompt_HumanMimic(el, value, opts = {}) {
  const { timeout = 2500, minPickScore = 55 } = opts;

  const want = String(value ?? '').trim();
  if (!el || el.disabled || el.readOnly) return false;
  if (!want) return false;

  const doc = el.ownerDocument || document;

  const root =
    el.closest('[data-automation-id="multiSelectContainer"]') ||
    el.closest('[data-uxi-widget-type="multiselect"]') ||
    el.parentElement;

  const promptBtn = root?.querySelector?.('[data-automation-id="promptSearchButton"]') || null;

  // 1) Focus
  el.scrollIntoView({ behavior:'smooth', block:'center' });
  await delay(60);
  try { el.focus({ preventScroll:true }); } catch { el.focus(); }
  await delay(30);

  // 2) Click
  clickLikeUserReal(el, { bias:'left' });
  await delay(80);

  // 3) Type (paste-like “type all”)
  clearInputHuman(el);
  await delay(60);
  typeTextHuman(el, want);
  await delay(160);

  // 4) Click again
  clickLikeUserReal(el, { bias:'left' });
  await delay(120);

  // trigger results
  pressEnterLikeUser(el);
  await delay(100);
  nudgeOpenResults(el);
  await delay(180);

  // 5) Ensure prompt panel exists
  let panel = findWorkdayPromptPanel(doc);
  if (!panel || !isVisible(panel)) {
    if (promptBtn) {
      clickLikeUserReal(promptBtn);
      await delay(200);
    }
  }

  const okPanel = await waitUntil(() => {
    panel = findWorkdayPromptPanel(doc);
    return panel && isVisible(panel);
  }, timeout);

  if (!okPanel) return false;

  // ✅ ONLY pick from FILTERED Search Results
  const filteredOptions = await waitForFilteredResults(panel, want, timeout);
  if (!filteredOptions.length) return false;

  const best = bestVisibleOption(filteredOptions, want);
  const pickEl =
    (best && (best.score ?? 0) >= minPickScore) ? best.el : filteredOptions[0].el;

  clickOptionRow(pickEl);
  await delay(220);

  // verify + retry
  if (!isOptionSelected(pickEl)) {
    clickOptionRow(pickEl);
    await delay(220);
  }

  // Done
  const done = findDoneButton(panel);
  if (done) {
    clickLikeUserReal(done);
    await delay(240);
  } else {
    pressEnterLikeUser(el);
    await delay(240);
  }

  // Commit
  el.dispatchEvent(new Event('change', { bubbles:true }));
  el.blur();
  el.dispatchEvent(new Event('blur', { bubbles:true }));
  return true;
}

/*
type FillOpts = {
  humanName?: string
  mapped?: boolean
  timeout?: number
  exactFirst?: boolean
  semanticMin?: number
}; */

//step-11, To fill input fields 
// --- updated: just adds mouse + a couple key events; rest unchanged ---
async function fillInput(el, value, opts = {}){
  const {
    humanName = "",
    mapped = false
  } = opts;
  if(!el || el.disabled || el.readOnly) return;
  const tag = el.tagName?.toUpperCase?.() || '';
  const type = (el.type||'text').toLowerCase();
  let normVal = value;
  if (normVal === true || normVal === 'true') normVal = 'yes';
  if (normVal === false || normVal === 'false') normVal = 'no';


  el.scrollIntoView({behavior:'smooth', block:'center'});
  await delay(40);

  if(type==='file'){ console.log('skipping becuase of file');return; }
 
  if (isWorkdayCombo(el)) {
    console.log('Fill Input workdaycombo for select');
    //const ok = await fillWorkdayDropdown(el, value);
    const ok = await fillWorkdayByButton(el, normVal,opts);
    if (ok) el.setAttribute('data-autofilled','true');
    return;
  }
  // WORKDAY MULTISELECT INPUT (Field of Study, Skills, etc.)
  if (isWorkdayMultiSelectInput(el)) {
    const ok = await fillWorkdayMultiSelectPrompt_HumanMimic(el, normVal, opts);
    if (ok) el.setAttribute('data-autofilled', 'true');
    return;
  }
  if (tag === 'SELECT' || isComplexDropdown(el)) {
    console.log('1. fill Input select complex type');
    const ok = await fillSelectElement(el,normVal,{humanName});
    if (ok) el.setAttribute('data-autofilled', 'true');
    return;
  }
  // CONTENTEDITABLE
  if(el.isContentEditable || el.getAttribute('role')==='textbox'){
    console.log('filling content editable and text')
    simulateMouse(el);//not contains click event         // NEW
    el.focus();
    el.click();
    try{
      document.execCommand('selectAll',false,null);
      document.execCommand('insertText', false, String(normVal));
    }catch{
      el.textContent = String(normVal);
    }
    fireInputEvents(el, normVal); //contains change event
    el.dispatchEvent(new Event('change', { bubbles: true })); 
    el.blur(); 
    el.dispatchEvent(new Event('blur',{bubbles:true}));
    await delay(50);
    markAutofilled(el, opts.mapped ? 'mapped' : 'fallback');
    if (opts.mapped) await waitForUiUpdates?.(2000);
    return;
  }
  // WORKDAY SPLIT DATE (MM / YYYY) – avoid el.click(), use coordinate pointer events
  if (isWorkdaySplitDatePart(el)) {
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await delay(40);

    // 1) Click like a real user at coordinates inside THIS element
    clickLikeUser(el, { bias: datePartBias(el) });
    await delay(20);

    // 2) If focus still got stolen (often to the year input), retry once
    const ae = (el.ownerDocument || document).activeElement;
    if (ae !== el) {
      clickLikeUser(el, { bias: datePartBias(el) });
      await delay(20);
    }

    // 3) Set value + events (no need for el.click())
    setValueWithNativeSetter(el, String(normVal));
    fireInputEvents(el, normVal);

    // Optional: a blur here sometimes auto-advances; but do it after value is committed
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.blur();
    el.dispatchEvent(new Event('blur', { bubbles: true }));

    await delay(50);
    markAutofilled(el, 'choice');
    return;
  }


  // STANDARD INPUT
  console.log('filling standard inputs');
  simulateMouse(el);              // NEW
  el.focus();
  el.click();
  setValueWithNativeSetter(el, String(normVal)); //setting value
  fireInputEvents(el, normVal);
  el.blur(); 
  el.dispatchEvent(new Event('blur',{bubbles:true}));
  await delay(50);
  markAutofilled(el, 'choice');

}

// --- updated: checkbox/radio adds mouse + key fallback, minimal ---
async function checkElement(el, should){
  const type = (el.type||'').toLowerCase();
  if (type==='checkbox' || type==='radio'){
    if (el.checked !== !!should){
      simulateMouse(el);          // NEW
      el.focus();
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
      el.click?.();
      // tiny keyboard fallback
      el.dispatchEvent(new KeyboardEvent('keydown',{key:' ',bubbles:true})); // NEW
      el.dispatchEvent(new KeyboardEvent('keyup',{key:' ',bubbles:true}));   // NEW
      el.dispatchEvent(new Event('change',{bubbles:true}));
      //fireInputEvents(el,should);
    }
    await delay(50);
    markAutofilled(el, 'choice');
  }
}

// ---------- Helpers to materialize mappings for a known section ----------
function sectionToPrefix(sectionKey){
  return sectionKey === 'education' ? 'educations'
       : sectionKey === 'experience' ? 'experiences'
       : sectionKey; // languages/certifications if you later add address for them
}

// Strip leading "<prefix>[x]." or "educations[x]." to a relative key
function toRelativeKey(dataKey, sectionKey){
  const prefix = sectionToPrefix(sectionKey);
  return dataKey
    .replace('{prefix}', prefix)
    .replace(/^educations\[x]\./, '')
    .replace(/^experiences\[x]\./, '')
    .replace(new RegExp('^' + prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\[x]\\.'), '');
}

///New for ML models
// One record per logical field/question
// --- helper for messages from content script ---
function sendMessageAsync(msg) {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(msg, (response) => {
        if (chrome.runtime.lastError) {
          // e.g., background not ready / extension reloaded
          return reject(new Error(chrome.runtime.lastError.message));
        }
        resolve(response);
      });
    } catch (err) {
      reject(err);
    }
  });
}

const fieldFeedbackRegistry = new Map(); 
// key = final_question_text
// value = {
//   element,
//   section,
//   index,
//   question_text,
//   final_question_text,
//   suggested_answer,   // from Active or Gemma
//   source,             // 'active' | 'gemma' | 'rule' | null
//   mappingDataKey,     // from decision.dataKey (for fallback from candidate data)
//   groupKey,           // for checkbox/radio groups (optional)
// }
function buildFinalQuestionText(obj) {
  // obj: { humanName, sectionKind, sectionIndex, isResidenceAddress, dataKey? }

  const rawLabel = (obj.humanName || '').trim();
  const normLabel = normalizeFieldNameWithSpace(rawLabel) || 'unnamed_field';

  let section = null;
  let index = null;

  if (obj.sectionKind && typeof obj.sectionIndex === 'number') {
    // repeated section like education/experience
    section = obj.sectionKind;                 // 'education' | 'experience'
    index = obj.sectionIndex;                  // 0,1,2...
  } else if (obj.isResidenceAddress) {
    // explicitly residence address, NOT a repeated section
    section = 'residence';
    index = null;
  } else {
    // regular root fields (email, phone, etc.)
    section = 'root';
    index = null;
  }

  if (index !== null && index !== undefined) {
    return `${section}[${index}].${normLabel}`;
  }
  return `${section}.${normLabel}`;
}
function buildActiveLearningPayload(inputs, userId) {
  const questions = [];

  for (const obj of inputs) {
    const el = obj.element;
    if (!el) continue;

    const question_text = (obj.humanName || '').trim();
    if (!question_text) continue; // skip completely unlabeled

    const sectionKind = obj.sectionKind || (obj.isResidenceAddress ? 'residence' : 'root');
    const index = (obj.sectionKind && typeof obj.sectionIndex === 'number')
      ? obj.sectionIndex
      : null;

    const final_question_text = buildFinalQuestionText(obj);

    // Seed or update registry
    fieldFeedbackRegistry.set(final_question_text, {
      element: el,
      section: sectionKind,
      index,
      question_text,
      final_question_text,
      suggested_answer: null,
      source: null,
      mappingDataKey: obj.dataKey || null,
      groupKey: obj.groupId || null,
      // NEW:
      currentValue: null,        // last known string value
      lastWriter: null,          // 'extension' | 'user' | null
    });

    questions.push({
      user_id: userId,
      section: sectionKind,
      index,
      question_text,
      final_question_text,
    });
  }

  return questions;
}
// Example: you adapt URL/shape to your backend
async function callActiveLearningApi(batch) {
  if (!batch.length) return [];

  const resp = await sendMessageAsync({
    type: 'ACTIVE_LEARNING_SUGGEST',
    batch,
  });

  if (!resp || !resp.ok) {
    console.warn('ACTIVE_LEARNING_SUGGEST error:', resp?.error);
    return [];
  }

  // Expect: { suggestions: [{ final_question_text, suggestion }, ...] }
  //return resp.suggestions || [];
  //[{ final_question_text, suggestion }, ...] 
  return resp
}
function applyActiveLearningSuggestions(suggestions) {
  const unknownKeys = [];

  for (const s of suggestions) {
    const key = s.final_question_text;
    const suggestion = s.suggestion;
    const rec = fieldFeedbackRegistry.get(key);
    if (!rec) continue;

    rec.suggested_answer = suggestion;
    rec.source = 'active';

    if (!suggestion || suggestion.toLowerCase() === 'i do not know') {
      unknownKeys.push(key);
    }
  }

  return unknownKeys; // keys that need Gemma backup
}
function buildGemmaPayloadFromUnknown(unknownKeys) {
  const inputs = [];

  for (const key of unknownKeys) {
    const rec = fieldFeedbackRegistry.get(key);
    if (!rec) continue;

    inputs.push({
      input_el: rec.final_question_text, // merged ID
      section: rec.section,
      index: rec.index,
      label: rec.question_text,
    });
  }

  return inputs;
}

// Step-6: Calling Gemma

async function callGemmaApi(batch) {
  if (!batch.length) return [];
  const resp = await sendMessageAsync({
    type: 'GEMMA_SUGGEST',
    batch,
  });

  if (!resp || !resp.ok) {
    console.warn('GEMMA_SUGGEST error:', resp?.error);
    return [];
  }

  // Expect: { items: [{ input_el, section, index, label, value }, ...] }
  //return resp.items || [];
  return resp
}
function applyGemmaSuggestions(gemmaItems) {
  for (const it of gemmaItems) {
    const key = it.input_el;  // should equal final_question_text we built
    const rec = fieldFeedbackRegistry.get(key);
    if (!rec) continue;

    const v = it.value;
    if (!v || v.toLowerCase() === 'i do not know') {
      // leave rec.suggested_answer as-is (maybe null or 'i do not know')
      continue;
    }

    // Overwrite only if Active Learning didn't already propose a better value,
    // or you can define precedence here.
    if (!rec.suggested_answer || rec.suggested_answer.toLowerCase() === 'i do not know') {
      rec.suggested_answer = v;
      rec.source = 'gemma';
    }
  }
}
function computeDisplayValueForRecord(rec) {
  const el = rec.element;
  if (!el) return '';

  const tag = el.tagName;
  const t = (el.type || '').toLowerCase();

  // Text-like inputs
  if (tag === 'INPUT' || tag === 'TEXTAREA') {
    if (t !== 'checkbox' && t !== 'radio') {
      return el.value || '';
    }
  }

  // Select box
  if (tag === 'SELECT') {
    const opt = el.selectedOptions && el.selectedOptions[0];
    if (opt && opt.textContent) return opt.textContent.trim();
    return el.value || '';
  }

  // Checkbox / Radio group handling
  if (t === 'checkbox' || t === 'radio') {
    const groupKey = rec.groupKey;

    // If we have a groupKey, aggregate all fields in same group
    if (groupKey) {
      const checkedLabels = [];

      for (const other of fieldFeedbackRegistry.values()) {
        if (other.groupKey !== groupKey) continue;
        const oEl = other.element;
        if (!oEl) continue;
        const oTag = oEl.tagName;
        const oType = (oEl.type || '').toLowerCase();
        if (oTag !== 'INPUT' || (oType !== 'checkbox' && oType !== 'radio')) continue;
        if (!oEl.checked) continue;

        const labelText = findAssociatedLabel(oEl) || oEl.value || '';
        if (labelText) {
          checkedLabels.push(labelText.trim());
        }
      }

      // Radio: at most one; Checkbox: maybe many
      return checkedLabels.join(', ');
    }

    // No group key: treat as single checkbox/radio
    if (t === 'radio') {
      if (!el.name) {
        return el.checked ? (findAssociatedLabel(el) || el.value || '') : '';
      }
      const group = document.querySelectorAll(`input[type="radio"][name="${CSS.escape(el.name)}"]`);
      const checked = Array.from(group).find(x => x.checked);
      if (!checked) return '';
      return (findAssociatedLabel(checked) || checked.value || '').trim();
    }

    if (t === 'checkbox') {
      if (!el.checked) return '';
      const labelText = findAssociatedLabel(el) || el.value || '';
      return labelText.trim();
    }
  }

  // Contenteditable / role=textbox fallback
  if (el.isContentEditable || el.getAttribute('role') === 'textbox') {
    return el.textContent?.trim() || '';
  }

  return '';
}
function updateRecordValueFromExtension(final_question_text, val) {
  const rec = fieldFeedbackRegistry.get(final_question_text);
  if (!rec) return;
  rec.currentValue = String(val ?? '');
  rec.lastWriter = 'extension';
}

async function newPopulateFields(finalGrouped) {
  if (!Array.isArray(finalGrouped) || !finalGrouped.length) return;

  const WD = isWorkdayHost?.() || false;
  const processedGroups = new Set();
  const processedDateBatches = new Set();

  const toBoolLike = (v) =>
    normalizeToBooleanLike?.(v) ??
    (v === true ? 'yes' : v === false ? 'no' : String(v ?? '').trim().toLowerCase());

  const isButtonEl = (el) => {
    if (!el) return false;
    const tag = (el.tagName || '').toUpperCase();
    return tag === 'BUTTON' || tag === 'A' || el.getAttribute?.('role') === 'button';
  };

  const setAutofilled = (el) => {
    try {
      el.classList?.add('autofill-highlight');
      el.setAttribute?.('data-autofilled', 'true');
      setTimeout(() => el.classList?.remove('autofill-highlight'), 260);
    } catch {}
  };

  // detect date fields (keeps your old behavior + mapping.type === 'date' + _dateMeta)
  const isDateField = (obj, el) => {
    const t = ((el?.type || obj?.elementType || '') + '').toLowerCase();
    if (t === 'date') return true;
    if (obj?._dateMeta) return true;
    if (obj?.mapping?.type === 'date') return true;
    const hn = (obj?.humanName || '').toLowerCase();
    if (/\b(date|month|year)\b/.test(hn)) return true;
    return false;
  };

  for (let i = 0; i < finalGrouped.length; i++) {
    await delay(1000);
    const item = finalGrouped[i];
    console.log('In new populate the input going to fill',item);
    if (!item) continue;

    // =========================================================
    // KIND: nonGroup  (value lives on item.field.value)
    // =========================================================
    if (item.kind === 'nonGroup') {
      const obj = item.field;
      const el = obj?.element;
      if (!el) continue;
      //console.log('In new populate checking0');
      if (el.getAttribute?.('data-autofilled') === 'true') continue;
      if (el.disabled || el.readOnly) continue;
      //console.log('In new populate checking1');
      const inputName = obj?.humanName || '';

      // Workday: skip country
      if (WD && /\bcountry\b/i.test(inputName)) continue;

      let val = obj?.value; // ✅ change #1: value is inside field

      if (val === undefined || val === null || val === '') continue;

      // keep your old boolean -> yes/no behavior
      if (val === true) val = 'yes';
      if (val === false) val = 'no';

      const t = ((el.type || obj?.elementType || '') + '').toLowerCase();
      //console.log('In new populate checking2');
      // single checkbox special handling (non-group checkbox)
      if (t === 'checkbox') {
        const normVal = toBoolLike(val);

        // direct yes/no -> checked/unchecked
        if (normVal === 'yes' || normVal === 'no') {
          await checkElement(el, normVal === 'yes');
          setAutofilled(el);
          await delay?.(60);
          continue;
        }

        // fallback: if checkbox label is yes/no, align it
        const labelNorm = toBoolLike(findAssociatedLabel?.(el) || el.value || '');
        if (labelNorm === 'yes' || labelNorm === 'no') {
          await checkElement(el, normVal === labelNorm);
          setAutofilled(el);
          await delay?.(60);
          continue;
        }

        // generic truthy -> check
        await checkElement(el, !!val);
        setAutofilled(el);
        await delay?.(60);
        continue;
      }

      // never fill button elements as normal inputs
      //NOTE: For workday domain related to degree, it is not parsing the value due to button
      //if ((el.tagName || '').toUpperCase() === 'BUTTON') continue;
      /*
      // date handling (including split-date batching if you still have _dateMeta/groupId)
      if (isDateField(obj, el)) {
        console.log("In new populate fields, entered in to the Date input")
        if (obj?._dateMeta?.mode === 'split' && obj?.groupId) {
          const bkey = obj.groupId ||
            batchKeyForDate?.({ kind: obj.sectionKind, index: obj.sectionIndex }, obj);
          if (!processedDateBatches.has(bkey)) {
            console.log('In new autofillinit, entered in to process date batch with bkey',bkey);
            const peers = collectLocalSplitDatePeers?.(finalGrouped, i, obj) || [];
            if (!peers.length) {
              console.log('In new autofillinit,filldata starting with value:',val);
              await fillDate(el, obj, val, { currentlyWorkHere: !!obj?.mapping?.currently_work_here });
              setAutofilled(el);
            } else {
              for (const peer of peers) {
                console.log('In New autofill date',peer);
                await fillDate(peer.element, peer, val, {
                  currentlyWorkHere: !!peer?.mapping?.currently_work_here,
                });
                setAutofilled(peer.element);
              }
            }
            processedDateBatches.add(bkey);
          }

          await delay?.(60);
          continue;
        }

        await fillDate(el, obj, val, { currentlyWorkHere: !!obj?.mapping?.currently_work_here });
        setAutofilled(el);
        await delay?.(60);
        continue;
      } */
      // normal inputs
      if (t !== 'file') {
        await fillInput(el, val, { mapped: true ,humanName: inputName});
        setAutofilled(el);
      }
      await delay?.(60);
      continue;
    }

    // =========================================================
    // KIND: group (radio/checkbox OR ashby button options)
    // value is item.value = array of selected option objects
    // =========================================================
    if (item.kind === 'group') {
      const options = Array.isArray(item.options) ? item.options : [];
      if (!options.length) continue;

      const groupKey =
        item.groupId ||
        item.question ||
        (options[0]?.element && (options[0].element.name || options[0].element.id)) ||
        `group_${i}`;

      if (processedGroups.has(groupKey)) continue;

      const selectedArr = Array.isArray(item.value) ? item.value : [];
      const selectedEls = new Set(
        selectedArr.map((x) => x?.element).filter(Boolean)
      );

      const groupType = (item.elementType || options[0]?.elementType || '').toLowerCase();
      const isRadio = groupType === 'radio';
      const isCheckbox = groupType === 'checkbox';

      for (const opt of options) {
        const optEl = opt?.element;
        if (!optEl) continue;

        if (optEl.getAttribute?.('data-autofilled') === 'true') continue;
        if (optEl.disabled || optEl.readOnly) continue;

        const shouldSelect = selectedEls.has(optEl);

        // ✅ change #2: Ashby button entry support (plus generic button-like safety)
        const ashbyBtn = isAshbyButtonEntry(opt) || isButtonEl(optEl);
        if (ashbyBtn) {
          if (shouldSelect) optEl.click();
          setAutofilled(optEl);
          continue;
        }

        // normal checkbox/radio inputs
        if (isRadio) {
          await checkElement(optEl, shouldSelect);
        } else if (isCheckbox) {
          await checkElement(optEl, shouldSelect);
        } else {
          // fallback: treat as checkbox group
          await checkElement(optEl, shouldSelect);
        }

        setAutofilled(optEl);
      }

      processedGroups.add(groupKey);
      await delay?.(60);
      continue;
    }
  }
}


async function populateFields(inputs, data, userId){
  if(!data) return;
  const normalizedData = {};
  for(const key in data){
    normalizedData[normalizeFieldName(key)] = data[key];
  }
  autofillData = normalizedData;
  // 1) Build Layer1 payload + registry entries
  fieldFeedbackRegistry.clear();
  const activeBatch = buildActiveLearningPayload(inputs, userId);
  // 2) Call Active Learning (Layer1)
  let unknownKeys = [];
  try {
    const activeSuggestions = await callActiveLearningApi(activeBatch);
    unknownKeys = applyActiveLearningSuggestions(activeSuggestions);
  } catch (e) {
    console.warn('Active Learning API failed, skipping layer1', e);
  }
  // 3) Call Gemma (Layer2) for unknowns
  if (unknownKeys.length) {
    try {
      const gemmaBatch = buildGemmaPayloadFromUnknown(unknownKeys);
      const gemmaItems = await callGemmaApi(gemmaBatch);
      applyGemmaSuggestions(gemmaItems);
    } catch (e) {
      console.warn('Gemma API failed, skipping layer2', e);
    }
  }
  const processedGroups = new Set();
  const WD = isWorkdayHost();

  for(let i=0;i<inputs.length;i++){
    const obj = inputs[i];
    const el = obj.element;
    const groupId = obj.groupId;
    let inputName = obj.humanName;
    console.log('Inside populate fields, el, Id, name:',el,groupId,inputName);

    if(el.getAttribute('data-autofilled')==='true'){
      console.log('populate skipping autofilled element:',el);
      continue;
    }
    if(el.disabled || el.readOnly) continue;

    if (WD && /\bcountry\b/i.test(inputName)) {
      console.log('Skip Workday country');
      continue;
    }

    // ---- NEW: derive key + value from registry / fallback ----
    const final_question_text = buildFinalQuestionText(obj);
    const rec = fieldFeedbackRegistry.get(final_question_text);

    // 1) Preferred value from Active / Gemma
    let val = rec?.suggested_answer || undefined;
    if (val && typeof val === 'string' && val.toLowerCase() === 'i do not know') {
      val = undefined;
    }

    // 2) Fallback to candidate data based on mapping.dataKey (same strategy as before)
    let entry = obj.mapping || null;
    if (val === undefined && obj.dataKey) {
      val = getByPath(autofillData, obj.dataKey);
    }

    // 3) Fallback to name/id if still empty and not address-only
    if (val === undefined && (!entry?.type || entry.type !== 'address')) {
      val = autofillData[normalizeFieldName(el.name)] ?? autofillData[normalizeFieldName(el.id)];
    }

    if (val === undefined || val === null || val === '') {
      console.log('populate no value for', inputName);
      continue;
    }

    if(val===true) val='yes';
    if(val===false) val='no';

    const t = (el.type||'').toLowerCase();

    // ---- existing checkbox / radio / Ashby logic (unchanged, just using val) ----
    if (t === 'checkbox' && !groupId && !inputName) {
      const normVal = normalizeToBooleanLike(val);
      const elementLabelNorm = normalizeToBooleanLike(findAssociatedLabel(el) || el.value || '');
      if (elementLabelNorm === 'yes' || elementLabelNorm === 'no') {
        const shouldCheck = normVal === elementLabelNorm;
        await checkElement(el, shouldCheck);
        continue;
      }
      const isTrueVal = normVal === 'yes';
      if (isTrueVal) {
        await checkElement(el, true);
        continue;
      } else if (normVal === 'no') {
        await checkElement(el, false);
        continue;
      }
    }

    if((groupId || inputName) && (t==='radio' || t==='checkbox'|| isAshbyButtonEntry(obj))){
      console.log('entered into checkbox groupId');
      const groupKey = groupId || normalizeFieldNameWithSpace(inputName);
      if(processedGroups.has(groupKey)) continue;

      const normNameEq = (a,b)=> normalizeFieldNameWithSpace(a) === normalizeFieldNameWithSpace(b);
      const groupObjs = inputs.filter(x => {
        const sameGroup = x.element !== el && (x.groupId === groupId || (inputName && normNameEq(x.humanName, inputName)));
        if (!sameGroup) return false;
        const xt = (x.element.type || '').toLowerCase();
        const isChoice = (xt === 'radio' || xt === 'checkbox') || isAshbyButtonEntry(x);
        return isChoice;
      });
      groupObjs.push(obj);

      const checkboxMap = [];
      for (const g of groupObjs) {
        let label;
        if (isAshbyButtonEntry(g)) {
          label = normalizeFieldNameWithSpace(g.optionText);
        } else {
          const gEl = g.element;
          label = normalizeFieldNameWithSpace(findAssociatedLabel(gEl) || gEl.value || '');
        }
        checkboxMap.push({ label, element: g.element, isButton: isAshbyButtonEntry(g) });
      }

      const desiredValues = Array.isArray(val) ? val.map(v=>String(v)) : [String(val)];
      const wantedNorms = desiredValues.map(v => normalizeFieldNameWithSpace(v));

      const wantedBool = desiredValues.map(v=>normalizeToBooleanLike(v));
      const labelsBool = checkboxMap.map(x=>normalizeToBooleanLike(x.label));
      if (new Set(wantedBool).size === 1 && (labelsBool.includes('yes') || labelsBool.includes('no'))){
        for (const x of checkboxMap){
          const should = normalizeToBooleanLike(x.label) === wantedBool[0];
          if (x.isButton) {
            if (should) x.element.click();
          } else {
            await checkElement(x.element, should);
          }
        }
        processedGroups.add(groupKey);
        // right before "continue;" at the end of group branch
        const displayVal = computeDisplayValueForRecord(rec || {
          element: el,
          groupKey,
        });
        updateRecordValueFromExtension(final_question_text, displayVal);
        continue;
      }

      for (const wanted of wantedNorms){
        let final = checkboxMap.find(x=>x.label === wanted)
                || checkboxMap.find(x=>x.label.includes(wanted));

        if(!final){
          const tokens = new Set(wanted.split(/\s+/).filter(Boolean));
          let best = {item:null,score:-1};
          for (const x of checkboxMap){
            const ts = new Set(x.label.split(/\s+/).filter(Boolean));
            const overlap = [...tokens].filter(t=>ts.has(t)).length;
            if (overlap > best.score) best = {item:x, score:overlap};
          }
          final = best.item;
        }

        if(final){
          if (final.isButton) {
            final.element.click();
          } else {
            await checkElement(final.element, true);
          }
        }
      }

      if (t==='radio'){
        for (const x of checkboxMap){
          if (x.isButton) continue;
          const keep = x.element.getAttribute('data-autofilled') === 'true';
          if(!keep) await checkElement(x.element, false);
        }
      }
      processedGroups.add(groupKey);
      // right before "continue;" at the end of group branch
      const displayVal = computeDisplayValueForRecord(rec || {
        element: el,
        groupKey,
      });
      updateRecordValueFromExtension(final_question_text, displayVal);
      continue;
    }

    if (el.tagName === 'BUTTON') continue; 

    // === normal inputs ===
    el.classList.add('autofill-highlight');
    el.setAttribute('data-autofilled','true');

    if (entry && entry.type === 'date'){
      if (obj._dateMeta?.mode !== 'split' || !groupId){
        await fillDate(el, obj, val, { currentlyWorkHere: !!entry?.currently_work_here });
        el.setAttribute('data-autofilled','true');
      } else {
        const bkey = batchKeyForDate({ kind: obj.sectionKind, index: obj.sectionIndex }, obj);
        if (!processedDateBatches.has(bkey)) {
          const peers = collectLocalSplitDatePeers(inputs, i, obj);
          if (!peers.length){
            await fillDate(el, obj, val, { currentlyWorkHere: !!entry?.currently_work_here });
            el.setAttribute('data-autofilled','true');
          } else {
            for (const peer of peers){
              await fillDate(peer.element, peer, val, { currentlyWorkHere: !!entry?.currently_work_here });
              peer.element.setAttribute('data-autofilled','true');
            }
          }
          processedDateBatches.add(bkey);
        }
      }
      setTimeout(()=>el.classList.remove('autofill-highlight'), 260);
      if(groupId) processedGroups.add(groupId);
      await delay(60);
      updateRecordValueFromExtension(final_question_text, val);
      continue;
    }

    if(t!=='file'){
      await fillInput(el, val, { mapped:true });
    }
    updateRecordValueFromExtension(final_question_text, val);
    setTimeout(()=>el.classList.remove('autofill-highlight'), 260);
    if(groupId){
      processedGroups.add(groupId);
    }

    await delay(60);
  }
}
function attachFeedbackListeners() {
  for (const [key, rec] of fieldFeedbackRegistry.entries()) {
    const el = rec.element;
    if (!el || el.__jaFeedbackListenerAttached__) continue;

    const handler = () => {
      const val = computeDisplayValueForRecord(rec);
      rec.currentValue = val;
      rec.lastWriter = 'user';
    };

    el.addEventListener('input', handler);
    el.addEventListener('change', handler);

    el.__jaFeedbackListenerAttached__ = true;
  }
}
let feedbackAlreadySent = false; // simple guard per page

async function sendActiveLearningFeedback(userId) {
  if (feedbackAlreadySent) return;
  feedbackAlreadySent = true;

  const feedbackItems = [];

  for (const rec of fieldFeedbackRegistry.values()) {
    const el = rec.element;
    if (!el || !el.isConnected) continue;

    // 1) Prefer tracked currentValue
    let final_answer = rec.currentValue;

    // 2) If we never stored it or it’s undefined, recompute from DOM
    if (final_answer == null) {
      final_answer = computeDisplayValueForRecord(rec);
    }

    final_answer = String(final_answer ?? '');

    feedbackItems.push({
      user_id: userId,
      question_text: rec.question_text,
      final_question_text: rec.final_question_text,
      final_answer,
      suggested_answer: rec.suggested_answer ?? null,
    });
  }

  if (!feedbackItems.length) return;

  try {
    const resp = await sendMessageAsync({
      type: 'ACTIVE_LEARNING_FEEDBACK',
      userId,
      feedback: feedbackItems,
    });

    if (!resp || !resp.ok) {
      console.warn('Failed to send active learning feedback (backend responded with error):', resp?.error);
      // If you want to retry on next navigation, you *could* do:
      // feedbackAlreadySent = false;
    }
  } catch (e) {
    console.warn('Failed to send active learning feedback (message error):', e);
    // Optional: feedbackAlreadySent = false;
  }
}
function setupFormSubmitFeedback(userId) {
  const forms = document.querySelectorAll('form');
  forms.forEach(form => {
    if (form.__jaFeedbackHooked__) return;
    form.__jaFeedbackHooked__ = true;

    form.addEventListener('submit', () => {
      try {
        sendActiveLearningFeedback(userId);
      } catch (e) {
        console.warn('Error sending feedback on submit', e);
      }
    }, { capture: true });
  });
}
function setupNavigationFeedback(userId) {
  if (window.__jaFeedbackNavHooked__) return;
  window.__jaFeedbackNavHooked__ = true;

  window.addEventListener('beforeunload', () => {
    try {
      // best effort, fire-and-forget; cannot await here
      sendActiveLearningFeedback(userId);
    } catch (e) {
      console.warn('Error sending feedback on beforeunload', e);
    }
  });
}
//STEP 1-1: Finding section and index
function findBlockRoot(el) {
  if(!el) return null;
  return (
    el.closest('fieldset,[role="group"],form,section,article')
  )
}
//    el.closest('div') ||
    //document.body
function buildBlocks(inputs) {
  const blocks = [];
  let current = null;

  for (const obj of inputs) {
    const root = findBlockRoot(obj.element);

    if (!current || current.root !== root) {
      current = { root, fields: [] };
      blocks.push(current);
    }
    current.fields.push(obj);
  }

  return blocks;
}
function classifyBlock(block) {
  const text = normalize(
    block.root.textContent ||
    block.fields.map(f => f.humanName).join(' ')
  );

  for (const [kind, words] of Object.entries(TITLE_BUCKETS)) {
    if (words.some(w => text.includes(w))) {
      return kind; // education | experience | languages | certifications
    }
  }
  return null;
}
function assignSectionIndexesFromBlocks(blocks) {
  const counters = Object.create(null);

  for (const block of blocks) {
    const kind = classifyBlock(block);
    if (!kind) continue;

    counters[kind] ??= 0;
    const index = counters[kind]++;

    for (const obj of block.fields) {
      obj.sectionKind  = kind;
      obj.sectionIndex = index;
    }
  }
}

// We only treat inputs inside these as "repeated-section blocks"
const BLOCK_ROOT_SEL = 'fieldset,[role="group"],form,section,article';

function findBlockRootForInput(el) {
  if (!el) return null;
  // IMPORTANT: we do NOT fall back to <div> or document.body
  const root = el.closest(BLOCK_ROOT_SEL);
  return root || null;           // null => this input is not in a repeated block
}

function resolveBlockTitle(root) {
  if (!root) return '';

  const doc = root.ownerDocument || document;

  // 1) fieldset legend
  if (root.tagName === 'FIELDSET') {
    const legend = root.querySelector('legend');
    if (legend?.textContent) return legend.textContent.trim();
  }

  // 2) heading-like inside the root
  const headingInside = firstMatch(root, HEADING_SEL) || firstMatch(root, TITLE_HINT_SEL);
  if (headingInside && textOf(headingInside)) return textOf(headingInside);

  // 3) aria-label / aria-labelledby on the root
  const aria = textFromAria(root, doc);
  if (aria) return aria;

  // 4) previous sibling headings/labels
  let prev = root.previousElementSibling;
  while (prev) {
    const prevHeading = prev.matches(HEADING_SEL)
      ? prev
      : firstMatch(prev, HEADING_SEL);
    if (prevHeading && textOf(prevHeading)) return textOf(prevHeading);

    const prevLabelish = firstMatch(prev, TITLE_HINT_SEL);
    if (prevLabelish && textOf(prevLabelish)) return textOf(prevLabelish);

    const prevAria = textFromAria(prev, doc);
    if (prevAria) return prevAria;

    prev = prev.previousElementSibling;
  }

  return '';
}

function classifyBlockKind(root, blockInputs) {
  if (!root) return null;

  // 1) Prefer the block title (legend/heading/etc.)
  const rawTitle = resolveBlockTitle(root);
  const normTitle = normalize(rawTitle);

  if (normTitle) {
    for (const [key, keywords] of Object.entries(TITLE_BUCKETS)) {
      if (keywords.some(k => normTitle.includes(k))) {
        return key;  // 'education' | 'experience' | 'languages' | 'certifications'
      }
    }
  }

  // 2) Fallback: combine a few field labels
  const joinedLabels = normalize(
    blockInputs
      .slice(0, 6)
      .map(o => o.humanName || '')
      .join(' ')
  );

  if (joinedLabels) {
    for (const [key, keywords] of Object.entries(TITLE_BUCKETS)) {
      if (keywords.some(k => joinedLabels.includes(k))) {
        return key;
      }
    }
  }

  return null; // unknown / non-repeated section
}

/**
 * inputs: array of { element, groupId, humanName, ... }
 * Mutates each object:
 *    sectionKind: 'education' | 'experience' | 'languages' | 'certifications' | null
 *    sectionIndex: 0,1,2,... or null
 */

//STEP3- Finding forms and attaching section and index

function attachSectionKindAndIndex(inputs) {
  if (!Array.isArray(inputs) || !inputs.length) return;

  // 1) Ensure clean slate
  for (const obj of inputs) {
    obj.sectionKind = null;
    obj.sectionIndex = null;
  }

  // 2) Build blocks based on BLOCK_ROOT_SEL containers
  const blocks = [];
  let currentBlock = null;

  for (const obj of inputs) {
    const root = findBlockRootForInput(obj.element);

    // Inputs NOT in any allowed root: leave sectionKind/index = null
    if (!root) {
      continue;
    }

    // If this is the first root or we moved to a different root, start a new block
    if (!currentBlock || currentBlock.root !== root) {
      currentBlock = { root, inputs: [] };
      blocks.push(currentBlock);
    }

    currentBlock.inputs.push(obj);
  }

  if (!blocks.length) return; // nothing to classify

  // 3) Assign sectionKind per block + running index per kind
  const counters = {
    education: 0,
    experience: 0,
    languages: 0,
    certifications: 0
  };

  for (const block of blocks) {
    const kind = classifyBlockKind(block.root, block.inputs);

    // If we couldn't classify this block, keep its inputs as null
    if (!kind || !(kind in counters)) {
      for (const obj of block.inputs) {
        obj.sectionKind = null;
        obj.sectionIndex = null;
      }
      continue;
    }

    const idx = counters[kind]++;
    for (const obj of block.inputs) {
      obj.sectionKind = kind;
      obj.sectionIndex = idx;
    }
  }
}


//STEP O (AUTOFILLINIT)

export async function autofillInit(tokenOrData, arg2 = null) {
  window.__JA_busyAutofill = true;
  pauseDetections(2000); // quiet period while we interact
  const looksLikeOpts = arg2 && typeof arg2 === 'object' && ('reentry' in arg2);
  const opts = looksLikeOpts ? (arg2 || {}) : null;
  const dataFromPopup = looksLikeOpts ? null : arg2;
  const data = dataFromPopup ?? tokenOrData;
  const reentry = !!opts?.reentry;
  console.log('[autofillInit] data:', data, 'reentry:', reentry);
  if (!data) { 
    console.log('[autofill] No data provided to autofillInit'); 
    return; 
  }
  autofillData = data;
  const user_id = autofillData["user_id"];
  await waitForDomStable({ timeoutMs: 1000, quietMs: 180 });
  const inputsInitial = inputSelection();
  attachSectionKindAndIndex(inputsInitial);
  await processAddSectionsFromData(autofillData, inputsInitial);
  // Wait for any new sections/rows to appear
  await waitForDomStable({ timeoutMs: 1000, quietMs: 180 });
  const inputs = inputSelection();
  const grouped = groupConsecutiveByGroupId(inputs);
  console.log('Initial grouped:', grouped?.length, grouped);
  try {
    // 0) Start from grouped
    let current = grouped;
    // 1) FieldMappings (cheap/local)
    const payload0 = buildPayloadForMappingAndActiveLearning(current, undefined, "labels");
    const modelOutput0 = mapQuestionsToAnswers(payload0, autofillData);
    //console.log('Answers coming from fieldmappings:',modelOutput0);
    
    // mapping is local & deterministic; attach if it returned anything
    if (hasUsableModelOutput(modelOutput0)) {
      current = attachModelValuesToGrouped(current, modelOutput0);
    }

    let unanswered = collectUnanswered(current);

    // 2) Gemma (ONLY for unanswered)
    if (unanswered.length) {
      const payload1 = buildModelPayloadFromGrouped(unanswered);

      let modelOutput1 = null;
      try {
        //modelOutput1 = await callGemmaApi(payload1);
        console.log("Autofillinit func, chekcing modeloutput1 is attching values or not.")
        modelOutput1 = [
          {
            "input_number": "1",
            "question": "job title",
            "answer": "Software Engineer-1"
          },
          {
            "input_number": "2",
            "question": "company",
            "answer": "Cortracker"
          },
          {
            "input_number": "3",
            "question": "location",
            "answer": "Irving, Texas"
          },
          {
            "input_number": "4",
            "question": "i currently work here",
            "answer": true
          },
          {
            "input_number": "5",
            "question": "from month",
            "answer": "09"
          },
          {
            "input_number": "6",
            "question": "from year",
            "answer": "2025"
          },
          {
            "input_number": "7",
            "question": "to month",
            "answer": null
          },
          {
            "input_number": "8",
            "question": "to year",
            "answer": null
          },
          {
            "input_number": "9",
            "question": "role description",
            "answer": "DEvelop,develop."
          },
          {
            "input_number": "10",
            "question": "school or university",
            "answer": "Auburn University at Montgomery"
          },
          {
            "input_number": "11",
            "question": "degree",
            "answer": "Masters"
          },
          {
            "input_number": "12",
            "question": "field of study",
            "answer": "Computer Science"
          },
          {
            "input_number": "13",
            "question": "school or university",
            "answer": "VVIT"
          },
          {
            "input_number": "14",
            "question": "degree",
            "answer": "Bachelors"
          },
          {
            "input_number": "15",
            "question": "field of study",
            "answer": "Electrical Engineering"
          },
          {
            "input_number": "16",
            "question": "type to add skills",
            "answer": "Machine Learning, Python, C++, HTML, CSS, JavaScript, React.js, Next.js, Numpy, Linear algebra, 3D Modeling, DSA, Computer Networks, Pandas, DFA, NFA, Regex, Colab, Blender, Docker, PostgreSQL, TensorFlow, Teamwork, Github pages, UI, Fast API, Chrome extension and Google forms."
          },
          {
            "input_number": "17",
            "question": "resume cv",
            "answer": "/uploads/ResumeGen0.pdf"
          },
          {
            "input_number": "18",
            "question": "linked in",
            "answer": "https://www.linkedin.com/in/sai-siva-reddy-m-964504224/"
          }
        ]     
        console.log('ModelOutput1:',modelOutput1);
      } catch (e) {
        modelOutput1 = null; // fail closed (skip attach)
      }
      current = attachModelValuesToGrouped(current, modelOutput1);
      console.log("autofillinit func, after attaching values through modeloutput1 the grouped list was",current);
      unanswered = collectUnanswered(current);
      /*
      // ✅ attach only if Gemma returned something usable
      if (hasUsableModelOutput(modelOutput1)) {
        console.log("In autofillinit func, entered to attach modeloutput1 values",modelOutput1);
        current = attachModelValuesToGrouped(current, modelOutput1);
        console.log("autofillinit func, after attaching values through modeloutput1 the grouped list was",current);
        unanswered = collectUnanswered(current);
      }*/
    }

    // 3) Active Learning (ONLY for still unanswered)
    if (unanswered.length) {
      const payload2 = buildPayloadForMappingAndActiveLearning(unanswered, user_id, "items");
      let modelOutput2 = null;
      try {
        modelOutput2 = await callActiveLearningApi(payload2);
      } catch (e) {
        modelOutput2 = null; // fail closed (skip attach)
      }

      // ✅ attach only if AL returned something usable
      if (hasUsableModelOutput(modelOutput2)) {
        current = attachModelValuesToGrouped(current, modelOutput2);
        unanswered = collectUnanswered(current);
      }
    }
    // ✅ FINAL: same format as grouped, with values attached from all fallbacks
    const finalGrouped = current;
    console.log('finalGrouped:',finalGrouped.length,finalGrouped.slice(0,30));
    // Normal resume-upload logic runs on final inputs
    if (!(reentry && IS_SET1)) {
      try {
        await newResumeFirstFromFinalGrouped(finalGrouped, autofillData, 500);
      } catch (e) {
        console.log('No file Input found:', e);
      }
    } else {
      console.log('[resume] re-entry on SET1 (iCIMS): skipping resume upload');
    }
    await newPopulateFields(finalGrouped);

  } catch (e) {
    console.error('[JA] autofillInit crashed after grouping', e);
  } finally {
    window.__JA_busyAutofill = false;
  }
  return;
}

/*  // Normal resume-upload logic runs on final inputs
  if (!(reentry && IS_SET1)) {
    try {
      await resumeFirstFromInputs(inputs, autofillData, 500);
    } catch (e) {
      console.log('No file Input found:', e);
    }
  } else {
    console.log('[resume] re-entry on SET1 (iCIMS): skipping resume upload');
  }
  const user_id = autofillData.user_id;
  // === 4) ONE global populate pass (Active Learning + Gemma only here) ===
  await populateFields(inputs, data, user_id);
  // === 5) Feedback wiring ===
  attachFeedbackListeners();
  setupFormSubmitFeedback(user_id);
  setupNavigationFeedback(user_id);
  window.__JA_busyAutofill = false; 
  */
/*
console.log('[JA] about to build payload, grouped len:', grouped?.length, grouped);
    const payload0 = buildPayloadForMappingAndActiveLearning(grouped, undefined, "labels");
    const modelOutput0 = mapQuestionsToAnswers(payload0,autofillData);
    const enriched0 = attachModelValuesToGrouped(grouped,modelOutput0)
    const unanswered0 = collectUnanswered(enriched0);
    const payload1 = buildModelPayloadFromGrouped(unanswered0);
    //console.log("The Payload sending to gemma:",payload.length,payload);
    const modelOutput1 = await callGemmaApi(payload1)
    //const modelOutput = [{'question': 'First Name *', 'answer': 'Sai'}, {'question': 'Last Name *', 'answer': 'Maddula'}, {'question': 'United States of America Brazil Philippines united…tuna islands western sahara yemen zambia zimbabwe', 'answer': 'United States of America'}, {'question': 'Street Address *', 'answer': '1531 w lemon st'}, {'question': 'City *', 'answer': 'Tampa'}, {'question': 'Candidate state', 'answer': 'Florida'}, {'question': 'Zip Code *', 'answer': '33606'}, {'question': 'Phone *', 'answer': '3614881962'}, {'question': 'Email *', 'answer': 'maddulasaisivareddy@gmail.com'}, {'question': 'Have you previously worked for power home remodeling', 'answer': ['no']}, {'question': 'Attach resume', 'answer': '/uploads/ResumeGen0.pdf'}];
    const enriched1 = attachModelValuesToGrouped(unanswered0, modelOutput1);
    //console.log("enriched:",enriched.length,enriched);
    const unanswered1 = collectUnanswered(enriched1);
    //console.log('Unanswered:', unacountexistingnswered?.length, unanswered);
    const payload2 = buildPayloadForMappingAndActiveLearning(unanswered1, user_id,"items");
    const modelOutput2 = await callActiveLearningApi(payload2);
    //const modelOutput2 = [{'question':'united states of america brazil philippines united kingdom afghanistan ala aland islands albania algeria american samoa andorra angola anguilla antarctica antigua and barbuda argentina armenia aruba australia austria azerbaijan bahamas bahrain bangladesh barbados belarus belgium belize benin bermuda bhutan bolivia bosnia and herzegovina botswana bouvet island british virgin islands british indian ocean territory brunei darussalam bulgaria burkina faso burundi cambodia cameroon canada cape verde cayman islands central african republic chad chile china hong kong sar china macao sar china christmas island cocos keeling islands colombia comoros congo brazzaville congo kinshasa cook islands costa rica c te d ivoire croatia cuba cyprus czech republic denmark djibouti dominica dominican republic ecuador egypt el salvador equatorial guinea eritrea estonia ethiopia falkland islands malvinas faroe islands fiji finland france french guiana french polynesia french southern territories gabon gambia georgia germany ghana gibraltar greece greenland grenada guadeloupe guam guatemala guernsey guinea guinea bissau guyana haiti heard and mcdonald islands holy see vatican city state honduras hungary iceland india indonesia iran islamic republic of iraq ireland isle of man israel italy jamaica japan jersey jordan kazakhstan kenya kiribati korea north korea south kuwait kyrgyzstan lao pdr latvia lebanon lesotho liberia libya liechtenstein lithuania luxembourg macedonia republic of madagascar malawi malaysia maldives mali malta marshall islands martinique mauritania mauritius mayotte mexico micronesia federated states of moldova monaco mongolia montenegro montserrat morocco mozambique myanmar namibia nauru nepal netherlands netherlands antilles new caledonia new zealand nicaragua niger nigeria niue norfolk island northern mariana islands norway oman pakistan palau palestinian territory panama papua new guinea paraguay peru pitcairn poland portugal puerto rico qatar r union romania russian federation rwanda saint barth lemy saint helena saint kitts and nevis saint lucia saint martin french part saint pierre and miquelon saint vincent and grenadines samoa san marino sao tome and principe saudi arabia senegal serbia seychelles sierra leone singapore slovakia slovenia solomon islands somalia south africa south georgia and the south sandwich islands south sudan spain sri lanka sudan suriname svalbard and jan mayen islands swaziland sweden switzerland syrian arab republic syria taiwan republic of china tajikistan tanzania united republic of thailand timor leste togo tokelau tonga trinidad and tobago tunisia turkey turkmenistan turks and caicos islands tuvalu uganda ukraine united arab emirates minor outlying islands uruguay uzbekistan vanuatu venezuela bolivarian republic viet nam virgin islands us wallis and futuna islands western sahara yemen zambia zimbabwe', 'answer': "United States"}]
    const enriched2 = attachModelValuesToGrouped(unanswered1, modelOutput2);


 /* Problems: 1. Facing some issues with unanswered . it is considering some inputs which already had a value.
 2.  */